import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Clock,
  Scissors,
  DollarSign,
  Package,
  Users,
  Award,
  MessageCircle,
  Bell,
  ChevronRight,
  ChevronLeft,
  TrendingUp,
  TrendingDown,
  Plus,
  Search,
  CheckCircle2,
  AlertTriangle,
  X,
  Phone,
  Crown,
  Smartphone,
  MapPin,
  ExternalLink,
  ShieldCheck,
  Check,
  Star,
  Coffee,
  Beer,
  Sparkles,
  ArrowRight,
  Settings,
  Store,
  CreditCard,
  QrCode,
  LogOut,
  Lock,
  User,
  Heart,
  Instagram
} from 'lucide-react';

// ==========================================
// ÍCONES VETORIAIS CUSTOMIZADOS DE BARBEARIA
// ==========================================
export const BowtieIcon = ({ className = "w-6 h-6 text-[#C9A356]" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <polygon points="4 6 12 11 4 18 4 6" fill="currentColor" fillOpacity="0.15" />
    <polygon points="20 6 12 11 20 18 20 6" fill="currentColor" fillOpacity="0.15" />
    <circle cx="12" cy="11" r="2.2" fill="currentColor" />
  </svg>
);

export const BarberBeardIcon = ({ className = "w-6 h-6 text-[#C9A356]" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M5 8a7 7 0 0 1 14 0v2c0 4-3 9-7 11-4-2-7-7-7-11V8z" fill="currentColor" fillOpacity="0.12" />
    <path d="M8 12c1.5 2 6.5 2 8 0" />
    <path d="M7 9c2-1 3-1 5 0 2-1 3-1 5 0" strokeWidth="1.8" />
  </svg>
);

export const CrossedRazorsIcon = ({ className = "w-6 h-6 text-[#C9A356]" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <line x1="5" y1="5" x2="19" y2="19" />
    <line x1="19" y1="5" x2="5" y2="19" />
    <rect x="3" y="3" width="5" height="2" transform="rotate(45 5.5 4)" fill="currentColor" />
    <rect x="16" y="16" width="5" height="2" transform="rotate(45 18.5 17)" fill="currentColor" />
    <circle cx="12" cy="12" r="1.5" fill="currentColor" />
  </svg>
);

export const ClassicShearsIcon = ({ className = "w-6 h-6 text-[#C9A356]" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="6" cy="6" r="3" />
    <circle cx="6" cy="18" r="3" />
    <line x1="8.5" y1="7.5" x2="20" y2="19" />
    <line x1="8.5" y1="16.5" x2="20" y2="5" />
  </svg>
);

export const CombAndRazorIcon = ({ className = "w-6 h-6 text-[#C9A356]" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <line x1="4" y1="6" x2="20" y2="6" strokeWidth="2" />
    <line x1="5" y1="6" x2="5" y2="11" />
    <line x1="8" y1="6" x2="8" y2="11" />
    <line x1="11" y1="6" x2="11" y2="11" />
    <line x1="14" y1="6" x2="14" y2="11" />
    <line x1="17" y1="6" x2="17" y2="11" />
    <line x1="20" y1="6" x2="20" y2="11" />
    <path d="M4 17l16-4" strokeWidth="2" strokeLinecap="round" />
    <circle cx="4" cy="17" r="1.5" fill="currentColor" />
  </svg>
);

export const CuttingScissorsIcon = ({ className = "w-6 h-6 text-[#C9A356]" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="6" cy="6" r="2.5" />
    <circle cx="6" cy="18" r="2.5" />
    <line x1="8" y1="8" x2="18" y2="18" />
    <line x1="8" y1="16" x2="18" y2="6" />
  </svg>
);

export const OfficialLogo = ({ className = "w-24 h-24" }) => (
  <img
    src="Valverde.jpg"
    alt="Valverd's BarberShop Logo Oficial"
    className={`${className} object-contain rounded-lg filter drop-shadow-md hover:scale-105 transition-transform`}
    onError={(e) => {
      e.target.onerror = null;
      e.target.src = 'assets/Valverde.jpg';
    }}
  />
);

// ==========================================
// DADOS REAIS DE VALVERD'S BARBERSHOP
// ==========================================
// Tabela Oficial de Serviços e Preços extraída das imagens reais
export const SERVICES_MENU = [
  { id: 's1', name: 'Corte Masculino', price: 40, duration: 40, category: 'Cabelo', description: 'Técnica precisa na tesoura ou máquina, corte alinhado e finalização impecável.' },
  { id: 's2', name: 'Corte Infantil', price: 50, duration: 35, category: 'Cabelo', description: 'Atendimento com calma, respeito e paciência para as crianças saírem no estilo.' },
  { id: 's3', name: 'Barba + Cabelo (Combo Especial)', price: 65, duration: 60, category: 'Combo', description: 'A experiência completa: corte alinhado e barba desenhada na navalha.' },
  { id: 's4', name: 'Somente Barba', price: 35, duration: 30, category: 'Barba', description: 'Barboterapia com toalha quente, navalha afiada, hidratação e pós-barba.' },
  { id: 's5', name: 'Design de Sobrancelha', price: 20, duration: 15, category: 'Estética', description: 'Alinhamento preciso na navalha para realçar o olhar.' },
  { id: 's6', name: 'Hidratação Capilar Profunda', price: 30, duration: 25, category: 'Tratamento', description: 'Tratamento revitalizante para dar brilho e maciez aos fios.' }
];

// Equipe Real de Barbeiros (Instagram Oficial: @valverds.barber)
export const BARBERS = [
  {
    id: 'b1',
    name: 'Luis Valverde',
    handle: '@luisvalverdelv',
    role: 'Fundador & Mestre Barbeiro',
    email: 'luis@valverds.com',
    commissionRate: 60,
    rating: 5.0,
    reviews: 420,
    avatar: 'barbeiro_valverds.jpg',
    specialties: 'Cortes Clássicos, Fade e Barboterapia',
    bio: 'Criador da Valverd\'s BarberShop em 2022 com o compromisso de entregar corte alinhado e atendimento de respeito.'
  },
  {
    id: 'b2',
    name: 'Yago Barber',
    handle: '@yago_barber9',
    role: 'Especialista em Fade & Estilo',
    email: 'yago@valverds.com',
    commissionRate: 50,
    rating: 4.9,
    reviews: 231,
    avatar: 'corte_cliente.png',
    specialties: 'Degradê Navalhado, Freestyle e Barba',
    bio: 'Foco em técnicas modernas de acabamento e fidelização de clientes.'
  }
];

export const INITIAL_BEVERAGES = [
  { id: 'b1', name: 'Cerveja Heineken Long Neck (330ml)', price: 14, type: 'Cerveja', stock: 48, minStock: 24 },
  { id: 'b2', name: 'Cerveja IPA Artesanal (500ml)', price: 22, type: 'Cerveja Especial', stock: 24, minStock: 12 },
  { id: 'b3', name: 'Whisky Dose Buchanan\'s 12 Anos', price: 25, type: 'Destilado', stock: 15, minStock: 5 },
  { id: 'b4', name: 'Café Espresso Gourmet', price: 0, type: 'Cortesia da Casa', stock: 999, minStock: 50 },
  { id: 'b5', name: 'Água Mineral Gelada', price: 0, type: 'Cortesia da Casa', stock: 999, minStock: 50 },
  { id: 'b6', name: 'Coca-Cola Gelada (Lata)', price: 7, type: 'Refrigerante', stock: 36, minStock: 18 }
];

export const BARBERSHOP_INFO = {
  name: "Valverd's BarberShop",
  slogan: "Beard, hair and mustache",
  tagline: "Dê um tapa no seu estilo!",
  founded: "2022",
  city: "Resende / RJ",
  neighborhood: "Campos Elíseos",
  address: "Campos Elíseos – Resende / RJ",
  phone: "(21) 97010-0668",
  whatsappLink: "https://wa.me/5521970100668?text=Ol%C3%A1%2C%20gostaria%20de%20agendar%20um%20hor%C3%A1rio%20na%20Valverd%27s%20BarberShop",
  instagram: "@valverds.barber",
  instagramLink: "https://instagram.com/valverds.barber",
  hours: "09:00 – 19:00 (Segunda a Sábado)"
};

// 4 Pilares Reais da Barbearia (extraídos da arte oficial)
export const BRAND_PILLARS = [
  {
    icon: 'Crown',
    title: 'ATENDIMENTO DE RESPEITO',
    desc: 'Você merece o melhor desde o primeiro contato, com atenção calorosa e pontualidade.'
  },
  {
    icon: 'Scissors',
    title: 'CORTE ALINHADO E PRECISO',
    desc: 'Técnica refinada, atenção meticulosa a cada detalhe e acabamento impecável na lâmina.'
  },
  {
    icon: 'Star',
    title: 'RESULTADO QUE ELEVA SUA IMAGEM',
    desc: 'Mais que um corte, é sobre se sentir confiante, renovado e pronto para qualquer ocasião.'
  },
  {
    icon: 'Heart',
    title: 'RELACIONAMENTO QUE GERA LEALDADE',
    desc: 'Na nossa cadeira você não é apenas um cliente: você se torna parte da família Valverd\'s.'
  }
];

export default function App() {
  const [currentView, setCurrentView] = useState('site');
  const [activeNav, setActiveNav] = useState('home');
  const [adminTab, setAdminTab] = useState('agenda');

  const [currentUser, setCurrentUser] = useState({
    name: 'Luis Valverde',
    email: 'luis@valverds.com',
    role: 'dono',
    title: 'Fundador & Mestre Barbeiro'
  });

  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [beverages, setBeverages] = useState(INITIAL_BEVERAGES);

  // Modal Agende pelo app
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [bookingStep, setBookingStep] = useState(1);
  const [selectedService, setSelectedService] = useState(SERVICES_MENU[2]); // Combo Barba + Cabelo default
  const [selectedBarber, setSelectedBarber] = useState(BARBERS[0]);
  const [selectedTime, setSelectedTime] = useState('14:00');
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [bookingSuccess, setBookingSuccess] = useState(false);

  // Agendamentos em tempo real
  const [appointments, setAppointments] = useState([
    { id: 101, client: 'Gabriel Fontes', phone: '(21) 98822-1100', service: 'Barba + Cabelo', barber: 'Luis Valverde', time: '09:00', status: 'concluido', price: 65, paymentMethod: 'PIX' },
    { id: 102, client: 'Bruno Muniz', phone: '(21) 97733-2211', service: 'Corte Masculino', barber: 'Luis Valverde', time: '10:00', status: 'em_atendimento', price: 40, paymentMethod: '' },
    { id: 103, client: 'Lucas Lima', phone: '(21) 96644-3322', service: 'Corte Infantil', barber: 'Yago Barber', time: '10:30', status: 'agendado', price: 50, paymentMethod: '' },
    { id: 104, client: 'Rodrigo Medeiros', phone: '(21) 95555-4433', service: 'Somente Barba', barber: 'Luis Valverde', time: '11:15', status: 'confirmado', price: 35, paymentMethod: '' }
  ]);

  const [checkoutAppt, setCheckoutAppt] = useState(null);
  const [selectedPayment, setSelectedPayment] = useState('pix');
  const [consumedDrinkId, setConsumedDrinkId] = useState('');

  const scrollToSection = (id) => {
    setActiveNav(id);
    if (currentView !== 'site') setCurrentView('site');
    const element = document.getElementById(id);
    if (element) element.scrollIntoView({ behavior: 'smooth' });
  };

  const handleLogin = (e) => {
    e.preventDefault();
    setCurrentUser({
      name: loginEmail.includes('yago') ? 'Yago Barber' : 'Luis Valverde',
      email: loginEmail,
      role: 'dono',
      title: 'Gestão da Barbearia'
    });
    setCurrentView('admin');
  };

  const quickLoginAs = (role) => {
    if (role === 'luis') {
      setCurrentUser({ name: 'Luis Valverde', email: 'luis@valverds.com', role: 'dono', title: 'Fundador & Dono' });
    } else if (role === 'yago') {
      setCurrentUser({ name: 'Yago Barber', email: 'yago@valverds.com', role: 'barbeiro', title: 'Mestre Barbeiro' });
    } else {
      setCurrentUser({ name: 'Recepção Valverd\'s', email: 'recepcao@valverds.com', role: 'gerente', title: 'Recepção & Caixa' });
    }
    setCurrentView('admin');
  };

  const updateStock = (id, delta) => {
    setBeverages((prev) =>
      prev.map((item) => (item.id === id ? { ...item, stock: Math.max(0, item.stock + delta) } : item))
    );
  };

  const handleConfirmCheckout = () => {
    if (!checkoutAppt) return;
    if (consumedDrinkId) updateStock(consumedDrinkId, -1);
    setAppointments((prev) =>
      prev.map((item) =>
        item.id === checkoutAppt.id ? { ...item, status: 'concluido', paymentMethod: selectedPayment.toUpperCase() } : item
      )
    );
    setCheckoutAppt(null);
    setConsumedDrinkId('');
  };

  const handleCompleteBooking = (e) => {
    e.preventDefault();
    if (!clientName || !clientPhone) return;
    const newAppointment = {
      id: Date.now(),
      client: clientName,
      phone: clientPhone,
      service: selectedService.name,
      barber: selectedBarber.name,
      time: selectedTime,
      status: 'confirmado',
      price: selectedService.price
    };
    setAppointments((prev) => [newAppointment, ...prev]);
    setBookingSuccess(true);
  };

  const resetBookingForm = () => {
    setBookingSuccess(false);
    setBookingStep(1);
    setClientName('');
    setClientPhone('');
    setIsBookingModalOpen(false);
  };

  const totalRevenue = appointments
    .filter((a) => a.status === 'concluido')
    .reduce((acc, curr) => acc + curr.price, 0);

  return (
    <div className="min-h-screen bg-[#0B0B0B] text-[#1A1A1A] font-sans antialiased flex flex-col md:flex-row selection:bg-[#C9A356] selection:text-white">
      
      {/* ========================================================== */}
      {/* 1. SIDEBAR FIXA LATERAL ESQUERDA (DESKTOP)                 */}
      {/* ========================================================== */}
      <aside className="w-full md:w-[145px] md:min-w-[145px] bg-[#0B0B0B] md:fixed md:top-0 md:bottom-0 md:left-0 z-50 flex flex-col items-center justify-between border-b md:border-b-0 md:border-r border-[#211F1C] py-4 px-2 select-none shadow-2xl">
        
        {/* Logo Oficial Valverd's */}
        <div className="flex flex-col items-center text-center cursor-pointer mb-3" onClick={() => scrollToSection('home')}>
          <OfficialLogo className="w-24 h-24" />
        </div>

        {/* Links de Navegação */}
        <nav className="w-full flex md:flex-col items-center justify-around md:justify-center gap-1 md:gap-3.5 overflow-x-auto md:overflow-visible py-1">
          <button onClick={() => scrollToSection('home')} className={`flex flex-col items-center p-2 rounded w-full ${activeNav === 'home' && currentView === 'site' ? 'text-[#C9A356]' : 'text-[#E0DDD5] hover:text-[#C9A356]'}`}>
            <BowtieIcon className="w-6 h-6" />
            <span className="text-[10px] font-serif tracking-widest uppercase font-semibold mt-1">HOME</span>
          </button>
          <button onClick={() => scrollToSection('sobre-nos')} className={`flex flex-col items-center p-2 rounded w-full ${activeNav === 'sobre-nos' && currentView === 'site' ? 'text-[#C9A356]' : 'text-[#E0DDD5] hover:text-[#C9A356]'}`}>
            <BarberBeardIcon className="w-6 h-6" />
            <span className="text-[10px] font-serif tracking-widest uppercase font-semibold mt-1 text-center">SOBRE NÓS</span>
          </button>
          <button onClick={() => scrollToSection('valores')} className={`flex flex-col items-center p-2 rounded w-full ${activeNav === 'valores' && currentView === 'site' ? 'text-[#C9A356]' : 'text-[#E0DDD5] hover:text-[#C9A356]'}`}>
            <ClassicShearsIcon className="w-6 h-6" />
            <span className="text-[10px] font-serif tracking-widest uppercase font-semibold mt-1">VALORES</span>
          </button>
          <button onClick={() => scrollToSection('pilares')} className={`flex flex-col items-center p-2 rounded w-full ${activeNav === 'pilares' && currentView === 'site' ? 'text-[#C9A356]' : 'text-[#E0DDD5] hover:text-[#C9A356]'}`}>
            <CrossedRazorsIcon className="w-6 h-6" />
            <span className="text-[10px] font-serif tracking-widest uppercase font-semibold mt-1">PILARES</span>
          </button>
          <button onClick={() => scrollToSection('bebidas')} className={`flex flex-col items-center p-2 rounded w-full ${activeNav === 'bebidas' && currentView === 'site' ? 'text-[#C9A356]' : 'text-[#E0DDD5] hover:text-[#C9A356]'}`}>
            <CombAndRazorIcon className="w-6 h-6" />
            <span className="text-[10px] font-serif tracking-widest uppercase font-semibold mt-1">BEBIDAS</span>
          </button>
          <button onClick={() => scrollToSection('localizacao')} className={`flex flex-col items-center p-2 rounded w-full ${activeNav === 'localizacao' && currentView === 'site' ? 'text-[#C9A356]' : 'text-[#E0DDD5] hover:text-[#C9A356]'}`}>
            <MapPin className="w-5 h-5 text-[#C9A356]" />
            <span className="text-[9px] font-serif tracking-wider uppercase font-semibold mt-1 text-center">RESENDE/RJ</span>
          </button>
        </nav>

        {/* Base da Sidebar: Gestão / Login */}
        <div className="w-full pt-3 border-t border-[#211F1C] flex flex-col items-center">
          {currentView === 'admin' ? (
            <div className="w-full flex flex-col items-center text-center">
              <span className="text-[9px] uppercase tracking-wider text-[#C9A356] font-bold truncate max-w-full px-1">
                {currentUser?.name}
              </span>
              <button onClick={() => setCurrentView('site')} className="mt-1 w-full py-1 text-[9px] font-serif uppercase tracking-wider text-[#E0DDD5] hover:text-white bg-[#1A1A1A] rounded">
                Ver Site
              </button>
              <button onClick={() => { setCurrentUser(null); setCurrentView('login'); }} className="mt-1 text-[8px] text-[#E05656] hover:underline flex items-center gap-1">
                <LogOut className="w-2.5 h-2.5" /> Sair
              </button>
            </div>
          ) : (
            <button
              onClick={() => setCurrentView(currentUser ? 'admin' : 'login')}
              className="w-full flex flex-col items-center text-center p-1.5 rounded hover:bg-[#161512] transition-colors text-[#9E9B93] hover:text-[#C9A356]"
              title="Acesso à Área de Gestão"
            >
              <Lock className="w-4 h-4 text-[#C9A356] mb-1" />
              <span className="text-[8px] uppercase tracking-wider font-semibold">
                {currentUser ? 'PAINEL GESTÃO' : 'ÁREA RESTRITA'}
              </span>
            </button>
          )}
        </div>
      </aside>

      {/* ========================================================== */}
      {/* 2. ÁREA DE CONTEÚDO PRINCIPAL (DIREITA)                    */}
      {/* ========================================================== */}
      <main className="flex-1 md:ml-[145px] bg-[#FFFFFF] min-h-screen text-[#1A1A1A]">
        
        {/* VIEW A: SITE PÚBLICO */}
        {currentView === 'site' && (
          <>
            {/* HERO SECTION COM A FOTO REAL E SLOGAN */}
            <section
              id="home"
              className="relative min-h-[92vh] flex flex-col items-center justify-center text-center px-4 py-16 bg-cover bg-center overflow-hidden"
              style={{
                backgroundImage: `linear-gradient(rgba(11, 11, 11, 0.85), rgba(11, 11, 11, 0.92)), url('barbeiro_valverds.jpg')`
              }}
            >
              <div className="max-w-4xl mx-auto flex flex-col items-center z-10 text-white animate-fade-in">
                
                {/* Logo Circular Oficial */}
                <div className="w-44 h-44 sm:w-52 sm:h-52 rounded-full p-2 bg-[#0B0B0B]/80 border-2 border-[#C9A356]/60 shadow-2xl flex items-center justify-center backdrop-blur-md mb-6">
                  <OfficialLogo className="w-full h-full" />
                </div>

                <div className="inline-flex items-center gap-2 border border-[#C9A356]/40 px-4 py-1 rounded-full mb-3 bg-[#0B0B0B]/60 backdrop-blur-sm">
                  <Sparkles className="w-3.5 h-3.5 text-[#C9A356]" />
                  <span className="text-[11px] font-serif uppercase tracking-[0.25em] text-[#E0DDD5]">
                    CAMPOS ELÍSEOS • RESENDE / RJ
                  </span>
                  <Sparkles className="w-3.5 h-3.5 text-[#C9A356]" />
                </div>

                <div className="text-xl sm:text-2xl font-serif italic text-[#C9A356] tracking-[0.15em] mb-1">
                  "Dê um tapa no seu estilo!"
                </div>

                <h1 className="font-serif text-3xl sm:text-5xl md:text-6xl font-bold tracking-wider uppercase text-white mb-2 drop-shadow-md">
                  VALVERD'S
                </h1>

                <div className="text-sm md:text-base font-serif uppercase text-[#E0DDD5] tracking-[0.25em] mb-3">
                  BarberShop — Desde 2022
                </div>

                <p className="text-xs sm:text-sm font-sans text-[#A8A49D] max-w-lg mb-8 leading-relaxed">
                  Cortes masculinos de respeito, barboterapia de alta precisão e um ambiente pensado para o homem moderno relaxar e se sentir em casa.
                </p>

                <div className="flex flex-col sm:flex-row gap-4 items-center">
                  <button
                    onClick={() => setIsBookingModalOpen(true)}
                    className="px-8 py-3.5 bg-[#C9A356] hover:bg-[#B59044] text-[#0B0B0B] font-serif text-xs font-bold uppercase tracking-[0.2em] rounded shadow-lg transition-all transform hover:-translate-y-0.5 flex items-center gap-2"
                  >
                    <Scissors className="w-4 h-4" />
                    Agende Seu Horário
                  </button>

                  <a
                    href={BARBERSHOP_INFO.whatsappLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-8 py-3.5 bg-transparent hover:bg-white/10 text-white border border-white/30 font-serif text-xs font-semibold uppercase tracking-[0.2em] rounded transition-all flex items-center gap-2"
                  >
                    <Phone className="w-4 h-4 text-[#C9A356]" />
                    WhatsApp Oficial
                  </a>
                </div>
              </div>

              {/* Barra de Status */}
              <div className="absolute bottom-4 inset-x-4 flex justify-center">
                <div className="text-[10px] tracking-[0.2em] text-[#9E9B93] uppercase font-serif flex items-center gap-4 text-center flex-wrap justify-center">
                  <span>CAMPOS ELÍSEOS – RESENDE/RJ</span>
                  <span>•</span>
                  <span>HORÁRIO: {BARBERSHOP_INFO.hours}</span>
                  <span>•</span>
                  <span>{BARBERSHOP_INFO.phone}</span>
                </div>
              </div>
            </section>

            {/* SEÇÃO SOBRE NÓS COM A FOTO REAL DO BARBEIRO LUIS VALVERDE */}
            <section id="sobre-nos" className="py-24 px-6 md:px-16 max-w-6xl mx-auto">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
                
                {/* Fotografia Real do Barbeiro Luis Valverde */}
                <div className="relative group">
                  <div className="absolute -inset-2 border-2 border-[#C9A356]/40 rounded-xl transform -rotate-1 group-hover:rotate-0 transition-transform duration-300"></div>
                  <div className="relative rounded-xl overflow-hidden shadow-2xl bg-[#161512] aspect-[1/1] sm:aspect-[4/5]">
                    <img
                      src="barbeiro_valverds.jpg"
                      alt="Luis Valverde - Mestre Barbeiro"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-6 text-white">
                      <span className="text-[11px] font-serif uppercase tracking-[0.25em] text-[#C9A356] font-bold">
                        Fundador & Mestre Barbeiro
                      </span>
                      <h3 className="font-serif text-xl font-bold">Luis Valverde (@luisvalverdelv)</h3>
                      <p className="text-xs text-[#E0DDD5] mt-0.5">Valverd's BarberShop • Resende / RJ</p>
                    </div>
                  </div>
                </div>

                {/* Conteúdo Editorial */}
                <div className="flex flex-col items-center text-center lg:items-start lg:text-left">
                  <div className="w-full flex justify-center lg:justify-start mb-4">
                    <div className="p-3 rounded-full bg-[#FAF8F5] border border-[#C9A356]/30 shadow-sm">
                      <BarberBeardIcon className="w-10 h-10 text-[#C9A356]" />
                    </div>
                  </div>

                  <h2 className="font-serif text-3xl sm:text-4xl font-bold tracking-[0.25em] uppercase text-[#1A1A1A] mb-4">
                    S O B R E - N Ó S
                  </h2>

                  <p className="text-sm font-serif italic text-[#C9A356] mb-4">
                    "Cada corte representa confiança, dedicação e compromisso com o melhor resultado."
                  </p>

                  <div className="space-y-4 text-[#4A4742] leading-relaxed text-sm font-sans">
                    <p>
                      A <strong>Valverd's BarberShop</strong> nasceu em 2022 em <strong>Campos Elíseos, Resende/RJ</strong>, com o propósito de elevar a experiência do homem moderno ao mais alto nível de sofisticação e conforto.
                    </p>
                    <p>
                      Comandada por <strong>Luis Valverde</strong> e <strong>Yago Barber</strong>, a barbearia une a tradição da navalha afiada com técnicas contemporâneas de fade, visagismo e barboterapia. Aqui, cada detalhe importa: do atendimento cortês ao café espresso e cerveja artesanal servidos com excelência.
                    </p>
                  </div>

                  <div className="mt-8 pt-6 border-t border-[#E5E2DC] w-full grid grid-cols-3 gap-4 text-center lg:text-left">
                    <div>
                      <div className="text-[10px] font-serif uppercase tracking-wider text-[#8C887F]">Localização</div>
                      <div className="font-serif font-bold text-sm text-[#1A1A1A]">Resende / RJ</div>
                    </div>
                    <div>
                      <div className="text-[10px] font-serif uppercase tracking-wider text-[#8C887F]">Avaliação</div>
                      <div className="font-serif font-bold text-sm text-[#C9A356]">5.0 ★★★★★</div>
                    </div>
                    <div>
                      <div className="text-[10px] font-serif uppercase tracking-wider text-[#8C887F]">Desde</div>
                      <div className="font-serif font-bold text-sm text-[#1A1A1A]">2022</div>
                    </div>
                  </div>

                </div>
              </div>
            </section>

            {/* SEÇÃO VALORES REAIS (TABELA DE PREÇOS OFICIAL) */}
            <section id="valores" className="py-24 px-6 md:px-12 bg-[#12110E] text-white">
              <div className="max-w-6xl mx-auto">
                
                <div className="text-center mb-16">
                  <div className="flex justify-center mb-3">
                    <ClassicShearsIcon className="w-8 h-8 text-[#C9A356]" />
                  </div>
                  <div className="text-[11px] font-serif tracking-[0.3em] uppercase text-[#C9A356] font-bold">
                    TABELA DE SERVIÇOS OFICIAL
                  </div>
                  <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-[0.2em] uppercase text-white mt-2">
                    CONFIRA NOSSOS VALORES
                  </h2>
                  <div className="w-16 h-0.5 bg-[#C9A356] mx-auto mt-4"></div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {/* Card 1: Corte Masculino */}
                  <div className="bg-[#1A1815] border border-[#2A261F] p-6 rounded-xl hover:border-[#C9A356] transition-all flex flex-col justify-between group shadow-xl">
                    <div>
                      <div className="text-[10px] font-serif tracking-widest uppercase text-[#C9A356] mb-2 font-semibold">Cabelo</div>
                      <h3 className="font-serif text-lg font-bold text-white uppercase">Corte Masculino</h3>
                      <p className="text-xs text-[#9E9B93] mt-2 leading-relaxed">
                        Corte clássico ou fade degradê, tesoura e máquina com acabamento e styling.
                      </p>
                    </div>
                    <div className="mt-6 pt-4 border-t border-[#2A261F] flex items-center justify-between">
                      <div className="font-serif text-2xl font-black text-[#C9A356]">R$ 40</div>
                      <button
                        onClick={() => { setSelectedService(SERVICES_MENU[0]); setIsBookingModalOpen(true); }}
                        className="px-3.5 py-1.5 bg-[#C9A356] hover:bg-[#B59044] text-black font-serif text-[10px] font-bold uppercase tracking-wider rounded"
                      >
                        Agendar
                      </button>
                    </div>
                  </div>

                  {/* Card 2: Corte Infantil */}
                  <div className="bg-[#1A1815] border border-[#2A261F] p-6 rounded-xl hover:border-[#C9A356] transition-all flex flex-col justify-between group shadow-xl">
                    <div>
                      <div className="text-[10px] font-serif tracking-widest uppercase text-[#C9A356] mb-2 font-semibold">Infantil</div>
                      <h3 className="font-serif text-lg font-bold text-white uppercase">Corte Infantil</h3>
                      <p className="text-xs text-[#9E9B93] mt-2 leading-relaxed">
                        Atendimento atencioso e paciente com corte estilizado e produtos suaves.
                      </p>
                    </div>
                    <div className="mt-6 pt-4 border-t border-[#2A261F] flex items-center justify-between">
                      <div className="font-serif text-2xl font-black text-[#C9A356]">R$ 50</div>
                      <button
                        onClick={() => { setSelectedService(SERVICES_MENU[1]); setIsBookingModalOpen(true); }}
                        className="px-3.5 py-1.5 bg-[#C9A356] hover:bg-[#B59044] text-black font-serif text-[10px] font-bold uppercase tracking-wider rounded"
                      >
                        Agendar
                      </button>
                    </div>
                  </div>

                  {/* Card 3: Barba + Cabelo (Destaque) */}
                  <div className="bg-[#201D17] border-2 border-[#C9A356] p-6 rounded-xl shadow-2xl flex flex-col justify-between relative transform lg:-translate-y-2">
                    <div className="absolute -top-3 right-4 bg-[#C9A356] text-black text-[9px] font-serif font-black uppercase tracking-wider px-2.5 py-0.5 rounded">
                      MAIS PEDIDO
                    </div>
                    <div>
                      <div className="text-[10px] font-serif tracking-widest uppercase text-[#C9A356] mb-2 font-semibold">Combo Completo</div>
                      <h3 className="font-serif text-lg font-bold text-white uppercase">Barba + Cabelo</h3>
                      <p className="text-xs text-[#D1CECA] mt-2 leading-relaxed">
                        Experiência total de barboterapia com toalha quente e corte alinhado impecável.
                      </p>
                    </div>
                    <div className="mt-6 pt-4 border-t border-[#3A362E] flex items-center justify-between">
                      <div className="font-serif text-2xl font-black text-[#C9A356]">R$ 65</div>
                      <button
                        onClick={() => { setSelectedService(SERVICES_MENU[2]); setIsBookingModalOpen(true); }}
                        className="px-4 py-1.5 bg-[#C9A356] hover:bg-[#B59044] text-black font-serif text-[10px] font-bold uppercase tracking-wider rounded shadow"
                      >
                        Agendar
                      </button>
                    </div>
                  </div>

                  {/* Card 4: Somente Barba */}
                  <div className="bg-[#1A1815] border border-[#2A261F] p-6 rounded-xl hover:border-[#C9A356] transition-all flex flex-col justify-between group shadow-xl">
                    <div>
                      <div className="text-[10px] font-serif tracking-widest uppercase text-[#C9A356] mb-2 font-semibold">Barba</div>
                      <h3 className="font-serif text-lg font-bold text-white uppercase">Somente Barba</h3>
                      <p className="text-xs text-[#9E9B93] mt-2 leading-relaxed">
                        Desenho, alinhamento na navalha afiada, hidratação profunda e toalha quente.
                      </p>
                    </div>
                    <div className="mt-6 pt-4 border-t border-[#2A261F] flex items-center justify-between">
                      <div className="font-serif text-2xl font-black text-[#C9A356]">R$ 35</div>
                      <button
                        onClick={() => { setSelectedService(SERVICES_MENU[3]); setIsBookingModalOpen(true); }}
                        className="px-3.5 py-1.5 bg-[#C9A356] hover:bg-[#B59044] text-black font-serif text-[10px] font-bold uppercase tracking-wider rounded"
                      >
                        Agendar
                      </button>
                    </div>
                  </div>
                </div>

                <div className="mt-12 text-center">
                  <p className="text-xs text-[#8C887F] font-serif uppercase tracking-wider mb-3">
                    Outros serviços: Design de Sobrancelha (R$ 20) • Hidratação Capilar (R$ 30)
                  </p>
                  <button
                    onClick={() => setIsBookingModalOpen(true)}
                    className="inline-flex items-center gap-2 px-8 py-3 bg-[#C9A356] hover:bg-[#B59044] text-black font-serif text-xs font-bold uppercase tracking-widest rounded shadow-xl"
                  >
                    Agendar pelo Aplicativo
                  </button>
                </div>

              </div>
            </section>

            {/* SEÇÃO PILARES DA VALVERD'S (ARTE REAL DO INSTAGRAM) */}
            <section id="pilares" className="py-24 px-6 md:px-16 bg-[#FAFAF8] border-b border-[#E5E2DC]">
              <div className="max-w-6xl mx-auto">
                
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                  
                  {/* Foto Real do Atendimento */}
                  <div className="lg:col-span-5 relative">
                    <div className="rounded-xl overflow-hidden shadow-2xl border border-[#E5E2DC] aspect-[4/5] bg-black">
                      <img
                        src="corte_cliente.png"
                        alt="Atendimento com corte alinhado"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>

                  {/* Os 4 Pilares da Barbearia */}
                  <div className="lg:col-span-7">
                    <div className="text-[11px] font-serif tracking-[0.25em] uppercase text-[#C9A356] font-bold mb-2">
                      QUALIDADE SEMPRE • CORTE ALINHADO
                    </div>
                    <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl font-bold tracking-[0.15em] uppercase text-[#1A1A1A] mb-6">
                      CLIENTES QUE PASSAM, SAEM SATISFEITOS!
                    </h2>

                    <div className="space-y-5">
                      {BRAND_PILLARS.map((p, idx) => (
                        <div key={idx} className="bg-white p-4 rounded-lg border border-[#E5E2DC] shadow-sm flex items-start gap-4">
                          <div className="p-2.5 rounded bg-[#FAF8F5] text-[#C9A356] shrink-0 mt-0.5">
                            {idx === 0 && <Crown className="w-5 h-5" />}
                            {idx === 1 && <Scissors className="w-5 h-5" />}
                            {idx === 2 && <Star className="w-5 h-5" />}
                            {idx === 3 && <Heart className="w-5 h-5" />}
                          </div>
                          <div>
                            <h4 className="font-serif text-xs font-bold uppercase tracking-wider text-[#1A1A1A]">
                              {p.title}
                            </h4>
                            <p className="text-xs text-[#5C5850] mt-1 leading-relaxed font-sans">
                              {p.desc}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>

              </div>
            </section>

            {/* SEÇÃO BEBIDAS */}
            <section id="bebidas" className="py-24 px-6 md:px-16 max-w-6xl mx-auto">
              <div className="text-center mb-16">
                <div className="flex justify-center mb-3">
                  <CombAndRazorIcon className="w-8 h-8 text-[#C9A356]" />
                </div>
                <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl font-bold tracking-[0.25em] uppercase text-[#1A1A1A]">
                  B E B I D A S &nbsp; & &nbsp; B A R
                </h2>
                <p className="text-xs uppercase tracking-[0.2em] text-[#8C887F] font-serif mt-2">
                  Cerveja gelada, café espresso cortesia e ambiente de descontração
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {beverages.map((bev) => (
                  <div key={bev.id} className="bg-white p-4 rounded-lg border border-[#E5E2DC] flex justify-between items-center shadow-sm">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded bg-[#FAF8F5] text-[#C9A356]">
                        {bev.price === 0 ? <Coffee className="w-5 h-5" /> : <Beer className="w-5 h-5" />}
                      </div>
                      <div>
                        <div className="font-serif text-sm font-semibold text-[#1A1A1A]">{bev.name}</div>
                        <div className="text-[11px] text-[#8C887F]">{bev.type}</div>
                      </div>
                    </div>
                    <div className="font-serif font-bold text-sm text-[#1A1A1A]">
                      {bev.price === 0 ? (
                        <span className="text-green-700 bg-green-50 px-2 py-0.5 rounded text-[10px] uppercase">Cortesia</span>
                      ) : (
                        `R$ ${bev.price.toFixed(2).replace('.', ',')}`
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* SEÇÃO LOCALIZAÇÃO REAL: RESENDE/RJ */}
            <section id="localizacao" className="py-24 px-6 md:px-16 bg-[#FAFAF8] border-t border-[#E5E2DC]">
              <div className="max-w-4xl mx-auto text-center">
                <div className="flex justify-center mb-3">
                  <MapPin className="w-8 h-8 text-[#C9A356]" />
                </div>
                <div className="text-[11px] font-serif tracking-[0.25em] uppercase text-[#C9A356] font-bold">
                  VENHA NOS VISITAR
                </div>
                <h2 className="font-serif text-3xl sm:text-4xl font-bold tracking-[0.2em] uppercase text-[#1A1A1A] mt-2 mb-6">
                  ONDE ESTAMOS
                </h2>

                <div className="bg-white p-8 rounded-xl border border-[#E5E2DC] shadow-xl text-left space-y-4">
                  <div className="flex items-start gap-4">
                    <MapPin className="w-6 h-6 text-[#C9A356] shrink-0 mt-1" />
                    <div>
                      <h4 className="font-serif text-base font-bold text-[#1A1A1A]">Endereço</h4>
                      <p className="text-sm text-[#4A4742] mt-0.5">{BARBERSHOP_INFO.address}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <Clock className="w-6 h-6 text-[#C9A356] shrink-0 mt-1" />
                    <div>
                      <h4 className="font-serif text-base font-bold text-[#1A1A1A]">Horário de Atendimento</h4>
                      <p className="text-sm text-[#4A4742] mt-0.5">{BARBERSHOP_INFO.hours}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <Phone className="w-6 h-6 text-[#C9A356] shrink-0 mt-1" />
                    <div>
                      <h4 className="font-serif text-base font-bold text-[#1A1A1A]">WhatsApp Oficial</h4>
                      <p className="text-sm text-[#4A4742] mt-0.5">{BARBERSHOP_INFO.phone}</p>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-[#E5E2DC] flex flex-col sm:flex-row gap-3">
                    <a
                      href={BARBERSHOP_INFO.whatsappLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 py-3 bg-[#0B0B0B] hover:bg-[#1A1A1A] text-[#C9A356] font-serif text-xs font-bold uppercase tracking-wider rounded text-center transition-colors"
                    >
                      Agendar pelo WhatsApp
                    </a>
                    <a
                      href={BARBERSHOP_INFO.instagramLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-6 py-3 border border-[#E5E2DC] hover:border-[#C9A356] text-[#1A1A1A] hover:text-[#C9A356] font-serif text-xs font-bold uppercase tracking-wider rounded text-center transition-colors flex items-center justify-center gap-2"
                    >
                      <Instagram className="w-4 h-4" /> @valverds.barber
                    </a>
                  </div>
                </div>
              </div>
            </section>

            {/* FOOTER */}
            <footer id="contato" className="bg-[#0B0B0B] text-white py-16 px-6 md:px-16 border-t border-[#211F1C]">
              <div className="max-w-6xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-6">
                <div className="flex items-center gap-4">
                  <OfficialLogo className="w-16 h-16" />
                  <div>
                    <div className="font-serif text-sm font-bold uppercase tracking-wider text-white">
                      Valverd's BarberShop
                    </div>
                    <div className="text-xs text-[#9E9B93]">Campos Elíseos – Resende / RJ • Desde 2022</div>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-xs font-serif uppercase tracking-wider">
                  <button
                    onClick={() => setCurrentView('login')}
                    className="px-4 py-2 bg-[#201E19] hover:bg-[#C9A356] hover:text-black text-[#C9A356] rounded font-bold transition-all flex items-center gap-2"
                  >
                    <Lock className="w-3.5 h-3.5" /> Área Restrita de Gestão
                  </button>
                </div>
              </div>
            </footer>
          </>
        )}

        {/* VIEW B: TELA DE LOGIN */}
        {currentView === 'login' && (
          <div className="min-h-screen bg-[#12110E] flex flex-col justify-center items-center p-6 text-white relative">
            <button onClick={() => setCurrentView('site')} className="absolute top-6 left-6 text-xs text-[#9E9B93] hover:text-[#C9A356] font-serif uppercase tracking-widest">
              ← Voltar ao Site Público
            </button>
            <div className="max-w-md w-full bg-[#161512] border border-[#2A261F] rounded-xl shadow-2xl p-8">
              <div className="flex flex-col items-center mb-6 text-center">
                <OfficialLogo className="w-28 h-28 mb-3" />
                <div className="text-[10px] font-serif tracking-widest text-[#C9A356] uppercase font-bold">
                  CAMPOS ELÍSEOS – RESENDE/RJ
                </div>
                <h2 className="font-serif text-2xl font-bold uppercase tracking-wider text-white mt-1">
                  Área de Gestão
                </h2>
              </div>

              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-serif uppercase tracking-wider text-[#C5C0B5] mb-1">E-mail de Acesso:</label>
                  <input type="email" required value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} placeholder="luis@valverds.com" className="w-full px-3.5 py-2.5 bg-[#0B0B0B] border border-[#2A261F] rounded text-white text-xs focus:outline-none focus:border-[#C9A356]" />
                </div>
                <div>
                  <label className="block text-xs font-serif uppercase tracking-wider text-[#C5C0B5] mb-1">Senha:</label>
                  <input type="password" required value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} placeholder="••••••••" className="w-full px-3.5 py-2.5 bg-[#0B0B0B] border border-[#2A261F] rounded text-white text-xs focus:outline-none focus:border-[#C9A356]" />
                </div>
                <button type="submit" className="w-full py-3 bg-[#C9A356] hover:bg-[#B59044] text-black font-serif text-xs font-bold uppercase tracking-widest rounded shadow-lg">
                  Entrar no Sistema
                </button>
              </form>

              <div className="mt-8 pt-6 border-t border-[#2A261F]">
                <div className="text-[10px] font-serif uppercase tracking-wider text-[#8C887F] text-center mb-3">
                  Acesso Rápido de 1 Clique:
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button onClick={() => quickLoginAs('luis')} className="py-2.5 bg-[#201E19] hover:bg-[#2A261F] border border-[#3A362E] text-white text-xs font-serif uppercase tracking-wider rounded text-center">
                    👑 Luis Valverde
                  </button>
                  <button onClick={() => quickLoginAs('yago')} className="py-2.5 bg-[#201E19] hover:bg-[#2A261F] border border-[#3A362E] text-white text-xs font-serif uppercase tracking-wider rounded text-center">
                    ✂️ Yago Barber
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* VIEW C: PAINEL DE GESTÃO REAL */}
        {currentView === 'admin' && (
          <div className="p-6 md:p-10 bg-[#FAF8F5] min-h-screen">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-6 border-b border-[#E5E2DC] gap-4">
              <div className="flex items-center gap-4">
                <OfficialLogo className="w-14 h-14" />
                <div>
                  <div className="inline-flex items-center gap-2 text-xs font-serif uppercase tracking-widest text-[#C9A356] font-bold">
                    <ShieldCheck className="w-4 h-4" /> {currentUser?.title}
                  </div>
                  <h1 className="font-serif text-2xl md:text-3xl font-bold text-[#1A1A1A] mt-0.5">
                    {currentUser?.name}
                  </h1>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button onClick={() => setIsBookingModalOpen(true)} className="px-4 py-2 bg-[#C9A356] text-black font-serif text-xs font-bold uppercase rounded shadow">
                  + Novo Atendimento
                </button>
                <button onClick={() => setCurrentView('site')} className="px-4 py-2 bg-[#0B0B0B] text-white font-serif text-xs font-semibold uppercase rounded">
                  Ver Site
                </button>
                <button onClick={() => { setCurrentUser(null); setCurrentView('login'); }} className="p-2 border border-[#E5E2DC] text-red-600 rounded">
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Sub-abas de Gestão */}
            <div className="flex border-b border-[#E5E2DC] mt-6 gap-6 text-xs font-serif uppercase tracking-wider font-bold">
              <button onClick={() => setAdminTab('agenda')} className={`pb-3 border-b-2 ${adminTab === 'agenda' ? 'border-[#C9A356] text-[#1A1A1A]' : 'border-transparent text-[#8C887F]'}`}>
                📅 Agenda de Atendimentos
              </button>
              <button onClick={() => setAdminTab('financeiro')} className={`pb-3 border-b-2 ${adminTab === 'financeiro' ? 'border-[#C9A356] text-[#1A1A1A]' : 'border-transparent text-[#8C887F]'}`}>
                💰 Caixa & Faturamento
              </button>
              <button onClick={() => setAdminTab('estoque')} className={`pb-3 border-b-2 ${adminTab === 'estoque' ? 'border-[#C9A356] text-[#1A1A1A]' : 'border-transparent text-[#8C887F]'}`}>
                📦 Bebidas & Estoque
              </button>
              <button onClick={() => setAdminTab('equipe')} className={`pb-3 border-b-2 ${adminTab === 'equipe' ? 'border-[#C9A356] text-[#1A1A1A]' : 'border-transparent text-[#8C887F]'}`}>
                👥 Barbeiros
              </button>
            </div>

            {/* ABA AGENDA */}
            {adminTab === 'agenda' && (
              <div className="space-y-6 mt-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-white p-4 rounded border border-[#E5E2DC]">
                    <div className="text-[11px] font-serif uppercase text-[#8C887F]">Faturamento Concluído</div>
                    <div className="font-serif text-2xl font-bold text-[#1A1A1A]">R$ {totalRevenue.toFixed(2).replace('.', ',')}</div>
                  </div>
                  <div className="bg-white p-4 rounded border border-[#E5E2DC]">
                    <div className="text-[11px] font-serif uppercase text-[#8C887F]">Atendimentos Hoje</div>
                    <div className="font-serif text-2xl font-bold text-[#1A1A1A]">{appointments.length} Clientes</div>
                  </div>
                  <div className="bg-white p-4 rounded border border-[#E5E2DC]">
                    <div className="text-[11px] font-serif uppercase text-[#8C887F]">Barbeiros Ativos</div>
                    <div className="font-serif text-2xl font-bold text-[#1A1A1A]">Luis & Yago</div>
                  </div>
                  <div className="bg-white p-4 rounded border border-[#E5E2DC]">
                    <div className="text-[11px] font-serif uppercase text-[#8C887F]">Horário de Funcionamento</div>
                    <div className="font-serif text-sm font-bold text-[#C9A356] mt-1">09:00 às 19:00</div>
                  </div>
                </div>

                <div className="bg-white rounded-lg border border-[#E5E2DC] overflow-hidden shadow-sm">
                  <div className="p-4 border-b border-[#E5E2DC] font-serif text-sm font-bold uppercase">
                    Fluxo de Clientes — Valverd's BarberShop
                  </div>
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#FAF8F5] border-b border-[#E5E2DC] text-[#8C887F] uppercase font-serif">
                        <th className="p-3">Horário</th>
                        <th className="p-3">Cliente</th>
                        <th className="p-3">Serviço</th>
                        <th className="p-3">Barbeiro</th>
                        <th className="p-3">Status</th>
                        <th className="p-3">Valor</th>
                        <th className="p-3 text-right">Ação</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#EFECE6]">
                      {appointments.map((a) => (
                        <tr key={a.id} className="hover:bg-[#FDFBF7]">
                          <td className="p-3 font-bold font-serif">{a.time}</td>
                          <td className="p-3 font-semibold">{a.client}</td>
                          <td className="p-3">{a.service}</td>
                          <td className="p-3">{a.barber}</td>
                          <td className="p-3">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${a.status === 'concluido' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
                              {a.status}
                            </span>
                          </td>
                          <td className="p-3 font-bold">R$ {a.price.toFixed(2).replace('.', ',')}</td>
                          <td className="p-3 text-right">
                            {a.status !== 'concluido' ? (
                              <button onClick={() => setCheckoutAppt(a)} className="px-3 py-1 bg-[#0B0B0B] hover:bg-[#C9A356] hover:text-black text-white font-serif text-[10px] font-bold uppercase rounded">
                                Fechar Comanda
                              </button>
                            ) : (
                              <span className="text-[#2E7D32] font-bold">✓ Concluído</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* ABA FINANCEIRO */}
            {adminTab === 'financeiro' && (
              <div className="space-y-6 mt-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white p-6 rounded-lg border border-[#E5E2DC]">
                    <div className="text-xs font-serif uppercase text-[#8C887F]">Receita do Dia</div>
                    <div className="font-serif text-3xl font-bold text-[#1A1A1A] mt-2">R$ {totalRevenue.toFixed(2).replace('.', ',')}</div>
                  </div>
                  <div className="bg-white p-6 rounded-lg border border-[#E5E2DC]">
                    <div className="text-xs font-serif uppercase text-[#8C887F]">Repasse de Barbeiros</div>
                    <div className="font-serif text-3xl font-bold text-[#C9A356] mt-2">R$ {(totalRevenue * 0.55).toFixed(2).replace('.', ',')}</div>
                  </div>
                  <div className="bg-white p-6 rounded-lg border border-[#E5E2DC]">
                    <div className="text-xs font-serif uppercase text-[#8C887F]">Lucro Líquido da Barbearia</div>
                    <div className="font-serif text-3xl font-bold text-[#2E7D32] mt-2">R$ {(totalRevenue * 0.45).toFixed(2).replace('.', ',')}</div>
                  </div>
                </div>
              </div>
            )}

            {/* ABA ESTOQUE */}
            {adminTab === 'estoque' && (
              <div className="mt-6 bg-white rounded-lg border border-[#E5E2DC] overflow-hidden">
                <div className="p-4 border-b border-[#E5E2DC] font-serif text-sm font-bold uppercase">
                  Estoque de Bebidas — Geladeira Valverd's
                </div>
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-[#FAF8F5] border-b border-[#E5E2DC] text-[#8C887F] uppercase font-serif">
                      <th className="p-3">Item</th>
                      <th className="p-3">Preço</th>
                      <th className="p-3">Estoque</th>
                      <th className="p-3 text-right">Ajuste</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#EFECE6]">
                    {beverages.map((bev) => (
                      <tr key={bev.id}>
                        <td className="p-3 font-bold">{bev.name}</td>
                        <td className="p-3">{bev.price === 0 ? 'Cortesia' : `R$ ${bev.price.toFixed(2).replace('.', ',')}`}</td>
                        <td className="p-3 font-bold">{bev.stock} un.</td>
                        <td className="p-3 text-right space-x-1">
                          <button onClick={() => updateStock(bev.id, -1)} className="w-6 h-6 bg-gray-200 rounded font-bold">-</button>
                          <button onClick={() => updateStock(bev.id, 1)} className="w-6 h-6 bg-gray-200 rounded font-bold">+</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* ABA EQUIPE */}
            {adminTab === 'equipe' && (
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                {BARBERS.map((b) => (
                  <div key={b.id} className="bg-white p-6 rounded-xl border border-[#E5E2DC] flex items-center gap-5 shadow-sm">
                    <img src={b.avatar} alt={b.name} className="w-24 h-24 rounded-full object-cover border-2 border-[#C9A356]" />
                    <div className="space-y-1">
                      <h4 className="font-serif font-bold text-lg text-[#1A1A1A]">{b.name}</h4>
                      <div className="text-xs text-[#C9A356] font-semibold">{b.role} ({b.handle})</div>
                      <p className="text-xs text-[#5C5850]">{b.specialties}</p>
                      <div className="pt-2 text-xs font-bold text-[#1A1A1A]">
                        Avaliação: <span className="text-[#C9A356]">★ {b.rating}</span> ({b.reviews} avaliações)
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

          </div>
        )}

      </main>

      {/* BOTÃO FLUTUANTE */}
      {currentView === 'site' && (
        <button
          onClick={() => setIsBookingModalOpen(true)}
          className="fixed bottom-6 right-6 z-50 bg-[#1A1A1A] hover:bg-[#0B0B0B] text-[#C9A356] hover:text-white px-5 py-3.5 rounded-md shadow-2xl border border-[#C9A356]/40 flex items-center gap-3 font-serif text-xs font-bold uppercase tracking-wider"
        >
          <span>Agende pelo app</span>
        </button>
      )}

      {/* MODAL DE AGENDAMENTO */}
      {isBookingModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#161512] text-white border border-[#2A261F] rounded-xl max-w-lg w-full overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-[#2A261F] flex justify-between items-center bg-[#0B0B0B]">
              <div className="flex items-center gap-3">
                <OfficialLogo className="w-7 h-7" />
                <span className="font-serif text-xs uppercase tracking-widest font-bold">Agende na Valverd's BarberShop</span>
              </div>
              <button onClick={resetBookingForm} className="text-gray-400 hover:text-white">✕</button>
            </div>
            <div className="p-6">
              {bookingSuccess ? (
                <div className="text-center py-6 space-y-4">
                  <div className="w-16 h-16 bg-green-900/40 text-green-400 rounded-full flex items-center justify-center mx-auto text-2xl font-bold">✓</div>
                  <h3 className="font-serif text-xl font-bold uppercase">Agendamento Confirmado!</h3>
                  <p className="text-xs text-gray-300">
                    Seu horário para <strong>{selectedService.name}</strong> com <strong>{selectedBarber.name}</strong> em Campos Elíseos – Resende/RJ foi reservado às <strong>{selectedTime}</strong>.
                  </p>
                  <button onClick={resetBookingForm} className="w-full py-2.5 bg-[#C9A356] text-black font-serif text-xs font-bold uppercase rounded">Concluir</button>
                </div>
              ) : (
                <>
                  {bookingStep === 1 && (
                    <div className="space-y-4">
                      <h4 className="font-serif text-xs uppercase text-[#C9A356] font-bold">Selecione o Serviço:</h4>
                      <div className="space-y-2">
                        {SERVICES_MENU.map((s) => (
                          <div key={s.id} onClick={() => setSelectedService(s)} className={`p-3 rounded border cursor-pointer flex justify-between items-center ${selectedService.id === s.id ? 'border-[#C9A356] bg-[#201E19]' : 'border-[#2A261F]'}`}>
                            <div>
                              <div className="text-xs font-bold">{s.name}</div>
                              <div className="text-[10px] text-gray-400">{s.duration} min</div>
                            </div>
                            <div className="text-xs font-bold text-[#C9A356]">R$ {s.price.toFixed(2).replace('.', ',')}</div>
                          </div>
                        ))}
                      </div>
                      <button onClick={() => setBookingStep(2)} className="w-full py-2.5 bg-[#C9A356] text-black font-serif text-xs font-bold uppercase rounded">Avançar para Barbeiro</button>
                    </div>
                  )}

                  {bookingStep === 2 && (
                    <div className="space-y-4">
                      <h4 className="font-serif text-xs uppercase text-[#C9A356] font-bold">Escolha seu Barbeiro:</h4>
                      <div className="grid grid-cols-2 gap-3">
                        {BARBERS.map((b) => (
                          <div key={b.id} onClick={() => setSelectedBarber(b)} className={`p-3 rounded border cursor-pointer text-center ${selectedBarber.id === b.id ? 'border-[#C9A356] bg-[#201E19]' : 'border-[#2A261F]'}`}>
                            <img src={b.avatar} className="w-14 h-14 rounded-full mx-auto mb-1 object-cover border border-[#C9A356]" />
                            <div className="text-xs font-bold">{b.name}</div>
                            <div className="text-[10px] text-[#C9A356]">{b.handle}</div>
                          </div>
                        ))}
                      </div>

                      <h4 className="font-serif text-xs uppercase text-[#C9A356] font-bold pt-2">Horários Disponíveis Hoje:</h4>
                      <div className="grid grid-cols-4 gap-2">
                        {['09:30', '10:30', '14:00', '15:00', '16:30', '17:30', '18:15'].map((slot) => (
                          <button key={slot} type="button" onClick={() => setSelectedTime(slot)} className={`py-1.5 rounded text-xs font-bold ${selectedTime === slot ? 'bg-[#C9A356] text-black' : 'bg-[#201E19] text-gray-300'}`}>
                            {slot}
                          </button>
                        ))}
                      </div>

                      <div className="flex gap-2 mt-4">
                        <button onClick={() => setBookingStep(1)} className="w-1/3 py-2 bg-gray-800 text-xs rounded">Voltar</button>
                        <button onClick={() => setBookingStep(3)} className="flex-1 py-2 bg-[#C9A356] text-black font-serif text-xs font-bold uppercase rounded">Confirmar Dados</button>
                      </div>
                    </div>
                  )}

                  {bookingStep === 3 && (
                    <form onSubmit={handleCompleteBooking} className="space-y-3 text-xs">
                      <div className="bg-[#201E19] p-3 rounded text-xs space-y-1">
                        <div>Serviço: <strong>{selectedService.name}</strong></div>
                        <div>Barbeiro: <strong>{selectedBarber.name}</strong></div>
                        <div>Horário: <strong className="text-[#C9A356]">{selectedTime}</strong></div>
                        <div className="pt-1 border-t border-gray-700">Valor: <strong className="text-[#C9A356] text-sm font-bold">R$ {selectedService.price.toFixed(2).replace('.', ',')}</strong></div>
                      </div>
                      <div>
                        <label className="block mb-1 text-gray-300">Seu Nome Completo:</label>
                        <input type="text" required value={clientName} onChange={(e) => setClientName(e.target.value)} className="w-full p-2 bg-black border border-gray-700 rounded text-white" placeholder="Ex: Felipe Santana" />
                      </div>
                      <div>
                        <label className="block mb-1 text-gray-300">WhatsApp para Confirmação:</label>
                        <input type="tel" required value={clientPhone} onChange={(e) => setClientPhone(e.target.value)} className="w-full p-2 bg-black border border-gray-700 rounded text-white" placeholder="(21) 98765-4321" />
                      </div>
                      <div className="flex gap-2">
                        <button type="button" onClick={() => setBookingStep(2)} className="w-1/3 py-2 bg-gray-800 text-xs rounded">Voltar</button>
                        <button type="submit" className="flex-1 py-2.5 bg-[#C9A356] text-black font-serif font-bold uppercase rounded">Confirmar Agendamento</button>
                      </div>
                    </form>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODAL CHECKOUT */}
      {checkoutAppt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-white text-black rounded-xl max-w-md w-full overflow-hidden shadow-2xl">
            <div className="p-4 bg-black text-white flex justify-between items-center font-serif text-xs font-bold uppercase">
              <span>Fechar Comanda — {checkoutAppt.client}</span>
              <button onClick={() => setCheckoutAppt(null)}>✕</button>
            </div>
            <div className="p-6 space-y-4 text-xs">
              <div>
                <label className="block mb-1 text-gray-600 font-bold uppercase">Consumo de Bebida:</label>
                <select value={consumedDrinkId} onChange={(e) => setConsumedDrinkId(e.target.value)} className="w-full p-2 border rounded">
                  <option value="">Nenhuma bebida</option>
                  {beverages.filter((b) => b.price > 0).map((b) => (
                    <option key={b.id} value={b.id}>{b.name} (+ R$ {b.price.toFixed(2)})</option>
                  ))}
                </select>
              </div>
              <div className="bg-gray-50 p-3 rounded flex justify-between font-bold text-sm">
                <span>Total da Comanda:</span>
                <span className="text-[#C9A356]">
                  R$ {(checkoutAppt.price + (consumedDrinkId ? beverages.find((b) => b.id === consumedDrinkId)?.price || 0 : 0)).toFixed(2).replace('.', ',')}
                </span>
              </div>
              <div className="flex gap-2">
                <button onClick={() => setCheckoutAppt(null)} className="w-1/3 py-2 border rounded">Cancelar</button>
                <button onClick={handleConfirmCheckout} className="flex-1 py-2 bg-[#C9A356] font-bold text-black rounded uppercase">Confirmar Pagamento</button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
