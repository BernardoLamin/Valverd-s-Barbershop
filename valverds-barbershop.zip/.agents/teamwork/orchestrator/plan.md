# Master Plan: Valverd's BarberShop Officialization & Luxury Polish

## High-Level Objective
Execute all requirements R1-R4 with highest engineering rigor, authentic implementations, zero console errors, full responsive luxury styling, dark/clean themes, 24h + custom scheduling grid, real-time executive DRE, and Neon PostgreSQL integration.

## Tracks
1. **Survey Track (Phase 0)**:
   - Spawn 3 parallel Explorers:
     - Explorer 1 (UI/UX & Themes): Evaluate styling, typography, photo assets, carousel, and dark/clean mode architecture in index.html and CSS.
     - Explorer 2 (Scheduling & Client Privacy): Evaluate current booking flow, 00:00-23:30 slots, custom time parsing, and privacy logic.
     - Explorer 3 (Management, DRE & Neon DB): Evaluate Dono/Barbeiro/Recepção dashboards, DRE math, wa.me links, database/schema.sql, and .env synchronization.
2. **Decomposition & PROJECT.md Formulation**:
   - Merge findings into Feature Inventory and Milestones in `PROJECT.md`.
   - Setup Interface Contracts and Code Layout.
3. **E2E Testing Track**:
   - Test runner and test harness for opaque-box validation (Tiers 1-4).
   - Generates `TEST_READY.md`.
4. **Implementation Track**:
   - Milestone 1: R1 Luxury Visual Polish & Photo Carousel
   - Milestone 2: R2 Dark Mode & Clean Mode System (localStorage persisted)
   - Milestone 3: R3 Complete 24h Schedule Grid & Dynamic Custom Time Slots
   - Milestone 4: R4 Executive Management, DRE Calculations & Neon DB Schema/.env
5. **Final Milestone (Verification & Hardening)**:
   - Phase 1: 100% E2E test pass across all tiers.
   - Phase 2: Adversarial coverage hardening with Challenger & Forensic Auditor.
   - Victory claim and completion report to Sentinel.
