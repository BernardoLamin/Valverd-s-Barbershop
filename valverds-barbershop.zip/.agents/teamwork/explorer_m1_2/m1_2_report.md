# Relatório Técnico M1-2: Harmonização do Carrossel de Fotos & Ativos Reais

**Responsável**: Explorer M1-2  
**Milestone**: M1 (Design Visual de Barbearia de Luxo & Polimento do Carrossel)  
**Arquivo Alvo**: `index.html`  
**Data**: 2026-09-27  

---

## 1. Resumo Executivo & Objetivos

O presente relatório detalha a investigação e especificação técnica para a oficialização e elevação estética do **Carrossel de Fotos do Espaço Real** em `index.html`. Em consonância com o requisito §R1 de `ORIGINAL_REQUEST.md` (Design Visual de Barbearia de Luxo no padrão de "alta relojoaria") e o plano `PROJECT.md`, este módulo elimina aspectos rudimentares do protótipo atual (caracteres de texto bruto `‹` e `›`, ausência de autoplay e falta de indicadores de posição) e implementa:

1. **Autoplay Inteligente**: Transição automática a cada 5 segundos com pausa imediata em `hover` (desktop) e toque (`touch` em dispositivos móveis), além de inativação automática fora da visualização pública (`currentView !== 'site'`).
2. **Badge Contador de Alta Precisão**: Indicador numérico em estilo cronômetro de luxo (`01 / 09`) posicionado no canto superior direito do carrossel, complementado por um indicador de status de visualização no canto superior esquerdo (`Espaço Real Valverd's` / `Pausado`).
3. **Navegação Vetorial Refinada**: Substituição dos caracteres brutos `‹` e `›` por ícones vetoriais Lucide (`Icons.ChevronLeft` e `Icons.ChevronRight`), integrados em botões circulares translúcidos com borda dourada (`#C9A356`), micro-interações de escala e acessibilidade (`aria-label`).
4. **Indicadores de Navegação (Dots)**: Barrinhas e pontos dourados (`pills`) abaixo do carrossel para feedback visual imediato e navegação direta com um clique.
5. **Harmonização das 9 Fotos Locais**: Verificação exata da existência local, resolução (960x1280) e proporção perfeita de 3:4 de todas as 9 imagens de `GALLERY_SLIDES`.
6. **Sincronização com Cards de Ambiente**: Destaque dinâmico com anel dourado (`ring-1 ring-[#C9A356]`) nos 4 cards de ambientes quando o slide correspondente estiver ativo.

---

## 2. Auditoria e Validação dos Ativos de Imagem (9 Slides Reais)

Todas as imagens referenciadas em `GALLERY_SLIDES` (linhas 341-351 de `index.html`) foram inspecionadas localmente através do script `inspect_images.ps1`. Todos os arquivos existem no diretório raiz do projeto com proporção nativa idêntica de **3:4 (960 x 1280)**, garantindo enquadramento sem distorções no contêiner `aspect-[3/4]` do Tailwind.

| # | Arquivo Local | Resolução | Proporção | Tamanho | Legenda Oficial no Carrossel |
|---|---------------|-----------|-----------|---------|------------------------------|
| **01** | `foto_letreiro_neon.jpg` | 960 x 1280 | 3:4 (0.75) | 230.1 KB | Letreiro Neon Oficial Valverd's BarberShop no Jardim Vertical |
| **02** | `foto_lounge_espera.jpg` | 960 x 1280 | 3:4 (0.75) | 88.8 KB | Recepção e Sala de Espera — Conforto com Sofá Premium e Decoração Temática |
| **03** | `foto_atendimento_salao.jpg` | 960 x 1280 | 3:4 (0.75) | 147.0 KB | Atendimento Personalizado e Equipamentos de Alta Precisão |
| **04** | `foto_estacao_cafe.jpg` | 960 x 1280 | 3:4 (0.75) | 220.5 KB | Espaço Café & Bar de Boas-Vindas — Cortesia Exclusiva para Clientes |
| **05** | `foto_corte_fade.jpg` | 960 x 1280 | 3:4 (0.75) | 110.7 KB | Cortes com Degradê Limpo e Acabamento Impecável |
| **06** | `foto_corte_navalha_barba.jpg` | 960 x 1280 | 3:4 (0.75) | 87.8 KB | Alinhamento na Navalha e Cuidado Especial com a Barba |
| **07** | `foto_produtos_reais.jpg` | 960 x 1280 | 3:4 (0.75) | 157.5 KB | Linha Completa de Pomadas e Finalizadores Profissionais no Balcão |
| **08** | `foto_corte_kids.jpg` | 960 x 1280 | 3:4 (0.75) | 81.1 KB | Atendimento Infantil Especializado — Estilo para Todas as Idades |
| **09** | `foto_cafe_maquina.jpg` | 960 x 1280 | 3:4 (0.75) | 82.0 KB | Café Dolce Gusto Feito na Hora para sua Melhor Experiência |

**Conclusão dos Ativos**: O array `GALLERY_SLIDES` já utiliza exclusivamente fotos reais locais com metadados 100% consistentes. Não há dependências de URLs externas nem imagens quebradas.

---

## 3. Análise da Biblioteca de Ícones Vetoriais (`IconsBase`)

Foi realizada uma checagem minuciosa das linhas 270 a 285 de `index.html`. Foi constatado que os ícones `ChevronLeft` e `ChevronRight` **já estão implementados no objeto `IconsBase`**:

```javascript
ChevronRight: ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="9 18 15 12 9 6" />
  </svg>
),
ChevronLeft: ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="15 18 9 12 15 6" />
  </svg>
)
```

Como o objeto `Icons` possui um `Proxy` de fallback seguro contra erros de runtime (`React Minified error #130`), a utilização de `<Icons.ChevronLeft className="w-5 h-5" />` e `<Icons.ChevronRight className="w-5 h-5" />` é imediatamente segura, sem necessidade de carregar scripts adicionais.

---

## 4. Especificação de Estado e Efeito (Hooks)

### Localização no Código:
Dentro da função `ValverdsApp()`, nas proximidades da **linha 906**.

### Estado Atual (Linhas 906-909):
```javascript
const [currentSlide, setCurrentSlide] = useState(0);
const currentWeek = WEEKS_DATA[selectedWeekIndex] || WEEKS_DATA[1];
const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % GALLERY_SLIDES.length);
const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + GALLERY_SLIDES.length) % GALLERY_SLIDES.length);
```

### Novo Estado e Hook de Efeito Proposto:
```javascript
const [currentSlide, setCurrentSlide] = useState(0);
const [isCarouselHovered, setIsCarouselHovered] = useState(false);
const currentWeek = WEEKS_DATA[selectedWeekIndex] || WEEKS_DATA[1];
const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % GALLERY_SLIDES.length);
const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + GALLERY_SLIDES.length) % GALLERY_SLIDES.length);

// Autoplay com intervalo de 5s, pausa em hover/touch e auto-reset na navegação manual
useEffect(() => {
  if (isCarouselHovered || currentView !== 'site') return;
  const slideTimer = setInterval(() => {
    setCurrentSlide((prev) => (prev + 1) % GALLERY_SLIDES.length);
  }, 5000);
  return () => clearInterval(slideTimer);
}, [isCarouselHovered, currentView, currentSlide]);
```

### Racional Arquitetural do Efeito:
- **`currentView !== 'site'`**: Quando o usuário navega para a área de Agendamento, Painel do Barbeiro, Recepção ou Dono, o temporizador é cancelado, poupando processamento e ciclos da CPU/GPU.
- **`isCarouselHovered`**: Quando o ponteiro do mouse entra no carrossel (ou durante o toque em smartphone/tablet), o autoplay pausa imediatamente para permitir a apreciação atenta da fotografia e leitura da legenda.
- **Inclusão de `currentSlide` nas dependências**: Garante que o intervalo de 5 segundos seja reiniciado sempre que o usuário mudar de slide manualmente através das setas, miniaturas ou dots, impedindo que ocorra uma transição prematura logo após um clique manual.

---

## 5. Especificação de Markup JSX (Linhas 1568-1612)

### A. Carrossel Principal e Controles (Linhas 1568-1579)

**Código Atual**:
```jsx
<div className="lg:col-span-7">
  <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-[#282319] aspect-[3/4] max-h-[640px] w-full max-w-lg mx-auto bg-black">
    <img src={GALLERY_SLIDES[currentSlide].url} alt={GALLERY_SLIDES[currentSlide].caption} className="w-full h-full object-cover transition-all duration-700" />
    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/95 via-black/50 to-transparent p-6 text-white flex justify-between items-end">
      <p className="text-xs sm:text-sm font-serif">{GALLERY_SLIDES[currentSlide].caption}</p>
      <div className="flex gap-2">
        <button onClick={prevSlide} className="w-9 h-9 rounded-full bg-black/60 hover:bg-[#C9A356] hover:text-black text-white flex items-center justify-center transition-all">‹</button>
        <button onClick={nextSlide} className="w-9 h-9 rounded-full bg-black/60 hover:bg-[#C9A356] hover:text-black text-white flex items-center justify-center transition-all">›</button>
      </div>
    </div>
  </div>
</div>
```

**Novo Código Proposto para o Worker**:
```jsx
<div className="lg:col-span-7">
  {/* CARROSSEL PRINCIPAL COM HOVER PAUSE & BADGES DE LUXO */}
  <div
    onMouseEnter={() => setIsCarouselHovered(true)}
    onMouseLeave={() => setIsCarouselHovered(false)}
    onTouchStart={() => setIsCarouselHovered(true)}
    onTouchEnd={() => setIsCarouselHovered(false)}
    className="group relative rounded-3xl overflow-hidden shadow-2xl border border-[#282319] hover:border-[#C9A356]/40 aspect-[3/4] max-h-[640px] w-full max-w-lg mx-auto bg-black transition-all duration-500"
  >
    {/* BADGE DE IDENTIFICAÇÃO E STATUS DO AUTOPLAY (SUPERIOR ESQUERDO) */}
    <div className="absolute top-4 left-4 z-20 bg-black/75 backdrop-blur-md border border-[#C9A356]/30 px-3.5 py-1.5 rounded-full text-[11px] font-serif uppercase tracking-widest text-[#E6D5B8] flex items-center gap-2 shadow-lg select-none">
      <span className={`w-2 h-2 rounded-full transition-colors ${isCarouselHovered ? 'bg-amber-400' : 'bg-[#C9A356] animate-pulse'}`}></span>
      <span>{isCarouselHovered ? 'Pausado' : "Espaço Real Valverd's"}</span>
    </div>

    {/* BADGE CONTADOR DE SLIDES ELEGANTE (SUPERIOR DIREITO) - EX: 01 / 09 */}
    <div className="absolute top-4 right-4 z-20 bg-black/80 backdrop-blur-md border border-[#C9A356]/50 px-3.5 py-1.5 rounded-full text-xs font-serif tracking-widest text-[#C9A356] font-bold shadow-xl flex items-center gap-1.5 select-none">
      <span className="text-[#F5E0AA]">{String(currentSlide + 1).padStart(2, '0')}</span>
      <span className="text-[#C9A356]/40">/</span>
      <span className="text-[#A8A397]">{String(GALLERY_SLIDES.length).padStart(2, '0')}</span>
    </div>

    {/* IMAGEM DO SLIDE COM TRANSIÇÃO SUAVE */}
    <img
      key={currentSlide}
      src={GALLERY_SLIDES[currentSlide].url}
      alt={GALLERY_SLIDES[currentSlide].caption}
      className="w-full h-full object-cover transition-all duration-700 group-hover:scale-[1.02]"
    />

    {/* OVERLAY INFERIOR: LEGENDA EDITORIAL + SETAS VETORIAIS (CHEVRON) */}
    <div className="absolute inset-x-0 bottom-0 z-20 bg-gradient-to-t from-black/95 via-black/60 to-transparent p-6 text-white flex justify-between items-end gap-4">
      <div className="flex-1 pr-2">
        <p className="text-xs sm:text-sm font-serif text-[#F3EFE6] leading-relaxed drop-shadow-sm">
          {GALLERY_SLIDES[currentSlide].caption}
        </p>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={prevSlide}
          aria-label="Foto anterior"
          className="w-10 h-10 rounded-full bg-black/70 hover:bg-[#C9A356] text-[#E6D5B8] hover:text-black border border-[#C9A356]/40 hover:border-[#C9A356] flex items-center justify-center transition-all duration-300 backdrop-blur-sm shadow-lg hover:scale-105 active:scale-95 cursor-pointer"
        >
          <Icons.ChevronLeft className="w-5 h-5" />
        </button>
        <button
          onClick={nextSlide}
          aria-label="Próxima foto"
          className="w-10 h-10 rounded-full bg-black/70 hover:bg-[#C9A356] text-[#E6D5B8] hover:text-black border border-[#C9A356]/40 hover:border-[#C9A356] flex items-center justify-center transition-all duration-300 backdrop-blur-sm shadow-lg hover:scale-105 active:scale-95 cursor-pointer"
        >
          <Icons.ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  </div>

  {/* NAVEGAÇÃO POR PONTOS / BARRINHAS DOURADAS (DOTS) */}
  <div className="flex items-center justify-center gap-2 mt-5 select-none" role="tablist" aria-label="Navegação dos slides da galeria">
    {GALLERY_SLIDES.map((slide, idx) => (
      <button
        key={slide.id || idx}
        onClick={() => setCurrentSlide(idx)}
        role="tab"
        aria-selected={idx === currentSlide}
        aria-label={`Ir para foto ${idx + 1}: ${slide.caption}`}
        className={`transition-all duration-300 rounded-full h-2 cursor-pointer ${
          idx === currentSlide
            ? 'w-8 bg-[#C9A356] shadow-[0_0_10px_rgba(201,163,86,0.7)]'
            : 'w-2 bg-[#3A352C] hover:bg-[#C9A356]/60 hover:w-3.5'
        }`}
      />
    ))}
  </div>
</div>
```

---

### B. Cards de Ambientes com Sincronização Dinâmica (Linhas 1582-1612)

Os 4 cards abaixo do carrossel servem como atalhos para os principais ambientes do salão. Propõe-se aplicar neles a classe condicional que acende a borda dourada (`ring-1 ring-[#C9A356] border-[#C9A356]`) quando o slide exibido for o do card correspondente:

```jsx
{/* 4 CARDS REAIS DE AMBIENTES DO SALÃO COM DESTAQUE ATIVO */}
<div className="max-w-6xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-4 mt-10">
  <div
    onClick={() => setCurrentSlide(1)}
    className={`cursor-pointer group bg-[#161512] rounded-2xl p-3 border transition-all duration-300 ${
      currentSlide === 1 ? 'border-[#C9A356] ring-1 ring-[#C9A356]/60' : 'border-[#282319] hover:border-[#C9A356]/60'
    }`}
  >
    <div className="aspect-[3/4] rounded-xl overflow-hidden mb-2.5 bg-black">
      <img src="foto_lounge_espera.jpg" alt="Lounge e Sofá" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
    </div>
    <div className={`text-xs font-serif font-bold transition-colors ${currentSlide === 1 ? 'text-[#C9A356]' : 'text-white group-hover:text-[#C9A356]'}`}>
      Recepção & Sofá
    </div>
    <div className="text-[11px] text-gray-400">Espera confortável</div>
  </div>

  <div
    onClick={() => setCurrentSlide(3)}
    className={`cursor-pointer group bg-[#161512] rounded-2xl p-3 border transition-all duration-300 ${
      currentSlide === 3 ? 'border-[#C9A356] ring-1 ring-[#C9A356]/60' : 'border-[#282319] hover:border-[#C9A356]/60'
    }`}
  >
    <div className="aspect-[3/4] rounded-xl overflow-hidden mb-2.5 bg-black">
      <img src="foto_estacao_cafe.jpg" alt="Estação Café" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
    </div>
    <div className={`text-xs font-serif font-bold transition-colors ${currentSlide === 3 ? 'text-[#C9A356]' : 'text-white group-hover:text-[#C9A356]'}`}>
      Estação Café & Doces
    </div>
    <div className="text-[11px] text-[#C9A356]">Cortesia exclusiva</div>
  </div>

  <div
    onClick={() => setCurrentSlide(0)}
    className={`cursor-pointer group bg-[#161512] rounded-2xl p-3 border transition-all duration-300 ${
      currentSlide === 0 ? 'border-[#C9A356] ring-1 ring-[#C9A356]/60' : 'border-[#282319] hover:border-[#C9A356]/60'
    }`}
  >
    <div className="aspect-[3/4] rounded-xl overflow-hidden mb-2.5 bg-black">
      <img src="foto_letreiro_neon.jpg" alt="Mural Neon" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
    </div>
    <div className={`text-xs font-serif font-bold transition-colors ${currentSlide === 0 ? 'text-[#C9A356]' : 'text-white group-hover:text-[#C9A356]'}`}>
      Mural Neon & Verde
    </div>
    <div className="text-[11px] text-gray-400">Para fotos do corte</div>
  </div>

  <div
    onClick={() => setCurrentSlide(2)}
    className={`cursor-pointer group bg-[#161512] rounded-2xl p-3 border transition-all duration-300 ${
      currentSlide === 2 ? 'border-[#C9A356] ring-1 ring-[#C9A356]/60' : 'border-[#282319] hover:border-[#C9A356]/60'
    }`}
  >
    <div className="aspect-[3/4] rounded-xl overflow-hidden mb-2.5 bg-black">
      <img src="foto_atendimento_salao.jpg" alt="Bancada de Corte" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
    </div>
    <div className={`text-xs font-serif font-bold transition-colors ${currentSlide === 2 ? 'text-[#C9A356]' : 'text-white group-hover:text-[#C9A356]'}`}>
      Bancada de Corte
    </div>
    <div className="text-[11px] text-gray-400">Precisão na tesoura</div>
  </div>
</div>
```

*Nota*: No Card 3, corrigiu-se a imagem para `foto_letreiro_neon.jpg` (que corresponde exatamente ao slide `0`), tornando a pré-visualização perfeitamente coerente.

---

## 6. Resumo das Linhas a Serem Editadas pelo Worker

| Bloco | Linhas Originais | Ação do Worker |
|-------|------------------|----------------|
| **1. Hook de Estado & Efeito** | 906 a 910 | Adicionar estado `isCarouselHovered` e `useEffect` do slideTimer de 5000ms. |
| **2. Container do Carrossel** | 1568 a 1579 | Inserir manipuladores de evento (`onMouseEnter`, `onMouseLeave`, `onTouchStart`, `onTouchEnd`), badges de status e contador (`01 / 09`), botões vetoriais (`Icons.ChevronLeft`, `Icons.ChevronRight`), e navegação por dots. |
| **3. Cards de Ambientes** | 1582 a 1612 | Adicionar estilo condicional de card ativo (`currentSlide === X ? 'border-[#C9A356] ring-1 ring-[#C9A356]/60' : ...`) e harmonizar foto do Card 3 para `foto_letreiro_neon.jpg`. |

---

## 7. Critérios de Aceite e Método de Verificação

Para validar a implementação após a aplicação pelo Worker:
1. **Verificação Estática**:
   - `index.html` não deve conter os caracteres de texto bruto `‹` ou `›`.
   - `Icons.ChevronLeft` e `Icons.ChevronRight` devem estar presentes na seção `#espaco`.
   - O badge contador `"01 / 09"` deve estar presente e formatado com `padStart(2, '0')`.
2. **Verificação Dinâmica (Navegador)**:
   - O carrossel deve avançar automaticamente a cada 5 segundos quando o cursor não estiver sobre a imagem.
   - Posicionar o mouse sobre o carrossel deve pausar imediatamente o temporizador e alterar o indicador de status para "Pausado".
   - Clicar nas setas vetoriais ou nos dots deve transicionar para o slide correto e reiniciar a contagem dos 5 segundos.
   - O console do navegador deve permanecer livre de erros React (zero erro de chave ou renderização).
