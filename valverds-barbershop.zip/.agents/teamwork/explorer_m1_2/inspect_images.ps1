Add-Type -AssemblyName System.Drawing
$files = @(
  'foto_letreiro_neon.jpg',
  'foto_lounge_espera.jpg',
  'foto_atendimento_salao.jpg',
  'foto_estacao_cafe.jpg',
  'foto_corte_fade.jpg',
  'foto_corte_navalha_barba.jpg',
  'foto_produtos_reais.jpg',
  'foto_corte_kids.jpg',
  'foto_cafe_maquina.jpg',
  'foto_letreiro_frontal.jpg',
  'foto_corte_taper.jpg',
  'foto_corte_tesoura.jpg'
)
$root = "C:\Users\blaminma\Downloads\valverds-barbershop"
foreach ($name in $files) {
  $fullPath = Join-Path $root $name
  if (Test-Path $fullPath) {
    $img = [System.Drawing.Image]::FromFile($fullPath)
    $fi = Get-Item $fullPath
    [PSCustomObject]@{
      Name = $name
      Width = $img.Width
      Height = $img.Height
      AspectRatio = [Math]::Round($img.Width / $img.Height, 2)
      SizeKB = [Math]::Round($fi.Length / 1KB, 1)
    }
    $img.Dispose()
  } else {
    [PSCustomObject]@{
      Name = $name
      Width = 0
      Height = 0
      AspectRatio = 0
      SizeKB = 0
    }
  }
}
