$lines = [System.IO.File]::ReadAllLines("C:\Users\blaminma\Downloads\valverds-barbershop\index.html")
$used = [System.Collections.Generic.HashSet[string]]::new()
$defined = [System.Collections.Generic.HashSet[string]]::new()

$inIconsBase = $false
foreach ($line in $lines) {
    if ($line -match "const IconsBase = \{") { $inIconsBase = $true }
    if ($inIconsBase -and $line -match "^\s*([A-Za-z0-9_]+):\s*\(") {
        [void]$defined.Add($matches[1])
    }
    if ($inIconsBase -and $line -match "^\s*\};") { $inIconsBase = $false }

    $regexMatches = [regex]::Matches($line, '<Icons\.([A-Za-z0-9_]+)')
    foreach ($m in $regexMatches) {
        [void]$used.Add($m.Groups[1].Value)
    }
}

Write-Output "=== DEFINED IN IconsBase ($($defined.Count)) ==="
$defined | Sort-Object | ForEach-Object { Write-Output "  $_" }

Write-Output "`n=== USED AS <Icons.Name> ($($used.Count)) ==="
$missing = @()
foreach ($u in ($used | Sort-Object)) {
    if (-not $defined.Contains($u)) {
        Write-Output "  MISSING FROM IconsBase: $u"
        $missing += $u
    } else {
        Write-Output "  OK: $u"
    }
}

Write-Output "`nTotal Missing: $($missing.Count)"
