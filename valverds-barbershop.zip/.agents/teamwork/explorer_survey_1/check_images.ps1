$content = Get-Content -Path "C:\Users\blaminma\Downloads\valverds-barbershop\index.html" -Raw
$matches = [regex]::Matches($content, '["''`]([a-zA-Z0-9_\-\.]+\.(?:png|jpg|jpeg|webp|svg|JPEG|JPG|PNG))["''`]')

$images = [System.Collections.Generic.HashSet[string]]::new()
foreach ($m in $matches) {
    [void]$images.Add($m.Groups[1].Value)
}

Write-Output "Found $($images.Count) image references in index.html:"
$missing = @()
foreach ($img in ($images | Sort-Object)) {
    $pathRoot = "C:\Users\blaminma\Downloads\valverds-barbershop\$img"
    $pathAssets = "C:\Users\blaminma\Downloads\valverds-barbershop\assets\$img"
    $exists = (Test-Path $pathRoot) -or (Test-Path $pathAssets)
    if ($exists) {
        Write-Output "  [EXISTS] $img"
    } else {
        Write-Output "  [MISSING] $img"
        $missing += $img
    }
}
Write-Output "`nTotal Missing Images: $($missing.Count)"
