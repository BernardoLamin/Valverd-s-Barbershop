$lines = [System.IO.File]::ReadAllLines("C:\Users\blaminma\Downloads\valverds-barbershop\index.html")
$bgCounts = @{}
$textCounts = @{}
$borderCounts = @{}

foreach ($line in $lines) {
    [regex]::Matches($line, 'bg-\[#([0-9a-fA-F]{6})\]') | ForEach-Object {
        $hex = "#$($_.Groups[1].Value.ToUpper())"
        $bgCounts[$hex] = ($bgCounts[$hex] -as [int]) + 1
    }
    [regex]::Matches($line, 'text-\[#([0-9a-fA-F]{6})\]') | ForEach-Object {
        $hex = "#$($_.Groups[1].Value.ToUpper())"
        $textCounts[$hex] = ($textCounts[$hex] -as [int]) + 1
    }
    [regex]::Matches($line, 'border-\[#([0-9a-fA-F]{6})\]') | ForEach-Object {
        $hex = "#$($_.Groups[1].Value.ToUpper())"
        $borderCounts[$hex] = ($borderCounts[$hex] -as [int]) + 1
    }
}

Write-Output "=== TOP BACKGROUNDS ==="
$bgCounts.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 10 | ForEach-Object { "$($_.Key): $($_.Value)" }

Write-Output "`n=== TOP TEXT COLORS ==="
$textCounts.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 10 | ForEach-Object { "$($_.Key): $($_.Value)" }

Write-Output "`n=== TOP BORDERS ==="
$borderCounts.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 10 | ForEach-Object { "$($_.Key): $($_.Value)" }
