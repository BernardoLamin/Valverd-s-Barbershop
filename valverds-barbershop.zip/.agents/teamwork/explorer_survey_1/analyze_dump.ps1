$dump = Get-Content -Path ".agents\teamwork\explorer_survey_1\edge_dump.html" -Raw
Write-Output "File Length: $($dump.Length)"
if ($dump.Contains('VALVERD''S')) {
    Write-Output "Contains VALVERD'S: TRUE"
} else {
    Write-Output "Contains VALVERD'S: FALSE"
}
if ($dump.Contains('id="root"')) {
    $idx = $dump.IndexOf('id="root"')
    Write-Output "Snippet around root:"
    Write-Output $dump.Substring($idx, [Math]::Min(300, $dump.Length - $idx))
}
