$lines = [System.IO.File]::ReadAllLines("C:\Users\blaminma\Downloads\valverds-barbershop\index.html")
$i = 0
$suspicious = @()

foreach ($line in $lines) {
    $i++
    # Check for unescaped double quotes inside className="..." or similar
    if ($line -match 'className="[^"]*"[^">]*"') {
        $suspicious += "$i : $line"
    }
    # Check for unclosed brackets or templates
    if ($line -match '\$\{[^\}]*$' -or $line -match '\{[^\}]*`[^\}]*$') {
        $suspicious += "$i : $line"
    }
}

Write-Output "Found $($suspicious.Count) suspicious lines:"
$suspicious | ForEach-Object { Write-Output $_ }
