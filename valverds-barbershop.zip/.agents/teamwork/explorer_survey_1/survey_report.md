# Relatório de Auditoria & Survey — R1 (Design Visual de Luxo) & R2 (Dark Mode / Clean Mode)
**Projeto:** Valverd's BarberShop — Sistema Web de Gestão & Agendamento  
**Data:** 2026-09-27  
**Investigador:** Survey Explorer 1  
**Foco:** R1 (Luxury Visual Design) e R2 (Dark Mode & Clean Mode Theme System)  
**Arquivo Analisado:** `index.html` (4.842 linhas, 310 KB), `src/App.jsx`, `assets/`, imagens locais  

---

## 1. Sumário Executivo

A plataforma **Valverd's BarberShop** possui uma base visual sólida inspirada na alfaiataria e barbearia clássica, com fotos reais de alta qualidade do espaço em Resende/RJ (fundada em 2022) e identidade vintage elegante.

Entretanto, uma auditoria profunda revelou que:
1. **O Requisito R2 (Dark Mode / Clean Mode) está 100% ausente no código atual:** Não existe estado de tema, não há alternador de tema nos cabeçalhos, não há persistência em `localStorage`, nem regras de estilo para o Clean Mode (`#F8F9FA` / `#FFFFFF`). Todos os elementos utilizam cores escuras hardcoded (`bg-[#0B0B0B]`, `bg-[#161512]`, etc.).
2. **Defeito crítico identificado na Área do Cliente:** Na linha 967, a função `switchRole('cliente')` executa `setClientTab('agendamentos')`, mas a aba `'agendamentos'` não existe (as abas válidas são `'agendar'`, `'meu_corte'`, `'calendario_geral'`, `'produtos_bar'`, `'fidelidade'`). Ao clicar no perfil "Cliente" no `DemoRoleSwitcher`, o portal do cliente renderiza completamente em branco.
3. **Requisito R1 (Design Visual de Luxo):** A tipografia Cinzel e Plus Jakarta Sans está configurada, os assets de fotos reais estão todos presentes (18 imagens locais verificadas), mas o carrossel de fotos é estático (sem autoplay, sem contador de slides, sem dots), faltam ícones vetoriais de Sol/Lua no `IconsBase`, e a navegação mobile no site público apresenta risco de corte de itens por falta de scroll horizontal suave.

---

## 2. Auditoria Detalhada de R1: Design Visual de Barbearia de Luxo

### 2.1. Tipografia (Cinzel, Playfair Display & Plus Jakarta Sans)
- **Importação Google Fonts:**
  - `Cinzel` (400, 500, 600, 700, 800, 900) — Classic Roman / Vintage Barber
  - `Playfair Display` (500, 600, 700, 800, 900) — Editorial
  - `Plus Jakarta Sans` (300, 400, 500, 600, 700, 800) — Modern Executive UI
- **Mapeamento no Tailwind (`tailwind.config`):**
  - `serif`: `['Cinzel', 'Playfair Display', 'Georgia', 'serif']`
  - `sans`: `['Plus Jakarta Sans', '-apple-system', 'sans-serif']`
  - `display`: `['Playfair Display', 'Cinzel', 'serif']`
- **Uso no Código:**
  - Títulos principais, botões e valores monetários usam `font-serif tracking-wider uppercase`.
  - Corpo de texto, parágrafos explicativos e inputs usam `font-sans antialiased`.
  - `font-display` não é utilizada em nenhuma linha do projeto (0 ocorrências).
- **Gaps e Oportunidades de Refinamento:**
  - Variação tipográfica em subtítulos: adotar `font-serif italic text-[#C9A356]` em títulos de seções para elevar a sensação de revista/editorial de alto padrão.
  - Tabelas gerenciais (DRE e Escalas): alguns rótulos usam `text-[10px]` sem tracking apropriado, gerando aparência comprimida. Adicionar `tracking-wider`.

---

### 2.2. Paleta de Cores & Acabamento Metálico

| Propósito | Dark Luxury (Atual) | Clean Mode (Requisito R2) | Estado Atual |
| :--- | :--- | :--- | :--- |
| **Fundo Principal (Canvas)** | `#0B0B0B` (34 usos) | `#F8F9FA` | Hardcoded Dark |
| **Superfícies de Elevação** | `#12110E`, `#161512` (44 usos) | `#FFFFFF` (White Card) | Hardcoded Dark |
| **Cartões e Itens** | `#161410`, `#181612`, `#1F1C16` (~120 usos) | `#FFFFFF` c/ sombras suaves | Hardcoded Dark |
| **Acentos Dourados** | `#C9A356` (169 textos, 92 fundos) | `#C9A356` / `#B59044` | Excelente (ouro nobre) |
| **Bordas** | `#2A261F`, `#282319`, `#2E281F` (~160 usos) | `#E5E7EB` / `#E2E8F0` | Hardcoded Dark |
| **Texto de Título** | `text-white`, `text-[#E0DDD5]` | `#111827` (Grafite Quase Preto) | Hardcoded White |
| **Texto Secundário** | `text-gray-300`, `text-gray-400`, `text-[#9E9B93]` | `#4B5563` / `#6B7280` | Hardcoded Dark |
| **Meta Theme Color** | `#0B0B0B` (fixo no `<head>`) | `#0B0B0B` vs `#F8F9FA` | Estático |

- **Brilho Dourado (`.gold-shimmer`):** Definido no CSS (`linear-gradient(135deg, #C9A356 0%, #F5E0AA 50%, #B59044 100%)`). Aplicável em títulos de destaque e badges VIP.

---

### 2.3. Layout & Responsividade

- **Travamento de Largura Máxima:**
  - Classe `.app-container` definida em CSS:
    ```css
    .app-container {
      width: 100%;
      max-width: 1440px;
      margin-left: auto;
      margin-right: auto;
      padding-left: 1rem;
      padding-right: 1rem;
    }
    ```
  - Utilizada nas visões de Recepção, Dono, Barbeiro e Cliente (linhas 1958, 2003, 2102, 3158, 3186, 3225).
  - No Site Público, o `<main>` usa `max-w-6xl` (1152px) e `max-w-4xl`, garantindo leitura ideal sem linhas excessivamente longas.
- **Transbordo Horizontal (`overflow-x: hidden`):**
  - Presente em `html, body` (linha 73) e `#root` (linha 86).
  - Tabela de ocupação por cadeiras (`TIME_SLOTS_COMPARE`, linha 2310) está envolvida por `<div className="overflow-x-auto">`.
- **Gaps de Responsividade Encontrados:**
  - **Site Público Mobile (`<aside>` em telas `< 768px`):** Na linha 1379, `<nav className="w-full flex md:flex-col items-center justify-around ...">` coloca 9 botões com ícones e textos horizontais. Em celulares pequenos (375px), o espaço de ~41px por botão causa sobreposição ou quebra de texto dos rótulos (`PRODUTOS`, `RESENDE`). **Recomendação:** aplicar `overflow-x-auto no-scrollbar` no `<nav>` mobile com `whitespace-nowrap`.

---

### 2.4. Auditoria de Imagens & Assets Locais

Todos os 18 arquivos de imagens referenciados no código foram verificados diretamente no disco e **estão 100% disponíveis:**

1. `logo_valverds_clean.png` (212 KB) — Logomarca oficial transparente com traços pretos e dourado nobre. Perfeita para fundos claros e escuros.
2. `barbeiro_valverds.jpg` (431 KB) — Foto real de Luis Valverde no salão com letreiro neon e folhagem verde.
3. `foto_atendimento_salao.jpg` (150 KB) — Foto real do salão climatizado e atendimento.
4. `foto_barbeiro_yago.jpg` (89 KB) — Foto do barbeiro Yago.
5. `luis_valverde.jpg` (244 KB) — Retrato de Luis Valverde.
6. `foto_letreiro_frontal.jpg` (415 KB) — Fachada do salão com logo neon no jardim vertical.
7. `foto_letreiro_neon.jpg` (235 KB) — Detalhe do neon aceso.
8. `foto_lounge_espera.jpg` (90 KB) — Sala de espera com sofá e quadro temático.
9. `foto_estacao_cafe.jpg` (225 KB) — Estação gourmet de café e doces.
10. `foto_cafe_maquina.jpg` (83 KB) — Máquina Dolce Gusto e xícaras.
11. `foto_corte_fade.jpg` (113 KB) — Degradê real com acabamento na navalha.
12. `foto_corte_taper.jpg` (929 KB) — Taper fade moderno.
13. `foto_corte_tesoura.jpg` (129 KB) — Trabalho manual na tesoura e textura.
14. `foto_corte_navalha_barba.jpg` (89 KB) — Alinhamento de barba e toalha quente.
15. `foto_corte_kids.jpg` (83 KB) — Corte infantil.
16. `foto_maquina_jrl.jpg` (93 KB) — Máquinas profissionais JRL Diamante.
17. `foto_produtos_reais.jpg` (161 KB) — Balcão de pomadas e finalizadores.
18. `espaco_interior_1.png` (125 KB) — Imagem de fundo do Hero.

Fallback `assets/Valverde.jpg` (1.11 MB) verificado e existente.

---

### 2.5. Carrossel de Fotos (Seção `#espaco`)
- **Implementação atual:**
  - Controlado por `currentSlide` (`useState(0)`).
  - Slides: `GALLERY_SLIDES` (9 fotos reais catalogadas).
  - Navegação: Botões manuais com caracteres de texto `‹` e `›`.
  - 4 cards de miniaturas abaixo (`Lounge`, `Café`, `Mural Neon`, `Bancada`).
- **Gaps em Relação ao Padrão de Luxo:**
  1. Ausência de autoplay suave (com pausa ao passar o mouse).
  2. Ausência de indicador de slides (ex: dots sutis ou contador `01 / 09`).
  3. Botões de navegação usam setas ASCII comuns (`‹`, `›`) em vez de ícones vetoriais refinados (`ChevronLeft`, `ChevronRight`).
  4. Transição de imagem imediata sem efeito de cross-fade / opacidade suave.

---

### 2.6. Micro-Interações & Acabamentos
- **Atuais:**
  - Botões dourados possuem `hover:scale-105 transition-all shadow-xl`.
  - Logo possui `hover:scale-105 transition-transform duration-300`.
  - Cards de portfólio possuem zoom na imagem `group-hover:scale-105 duration-500`.
- **Gaps de Acabamento:**
  - Modais de agendamento e cadastro não possuem transição de entrada suave (`animate-fade-in` ou backdrop blur com scale suave).
  - Ausência do botão interativo de alternância Dark/Clean com animação de deslize e ícones Sol/Lua.

---

## 3. Auditoria Detalhada de R2: Sistema Dark Mode & Clean Mode

### 3.1. Diagnóstico do Estado Atual
- **Busca por `valverds_theme`, `theme`, `darkMode`, `cleanMode`:**
  - 0 ocorrências de alternador de tema.
  - 0 ocorrências de persistência em `localStorage` para o tema.
  - 0 suporte a Clean Mode nas classes CSS e nos componentes React.
- **Constatação:** O requisito R2 não foi implementado até o momento. O sistema opera exclusivamente em Dark Mode com cores fixas.

---

### 3.2. Especificação Arquitetural do R2

Para cumprir 100% dos requisitos do R2 sem necessidade de refatorar individualmente as 4.842 linhas de código (o que geraria alto risco de quebra de sintaxe), a solução ideal consiste em:

#### A. Estado & Persistência no React (`ValverdsApp`)
```javascript
const [theme, setTheme] = useState(() => {
  try {
    return localStorage.getItem('valverds_theme') || 'dark';
  } catch (e) {
    return 'dark';
  }
});

useEffect(() => {
  try {
    localStorage.setItem('valverds_theme', theme);
  } catch (e) {}
  
  const root = document.documentElement;
  const metaTheme = document.querySelector('meta[name="theme-color"]');
  if (theme === 'clean') {
    root.classList.add('clean-mode');
    root.classList.remove('dark');
    if (metaTheme) metaTheme.setAttribute('content', '#F8F9FA');
  } else {
    root.classList.remove('clean-mode');
    root.classList.add('dark');
    if (metaTheme) metaTheme.setAttribute('content', '#0B0B0B');
  }
}, [theme]);
```

#### B. Componente Universal `ThemeToggle`
Um componente reutilizável elegante com ícone vetorial de Sol e Lua, detalhes dourados, tooltip explicativo e micro-interação ao clique:
```jsx
const ThemeToggle = ({ className = "" }) => (
  <button
    onClick={() => setTheme(prev => prev === 'dark' ? 'clean' : 'dark')}
    className={`px-3 py-1.5 rounded-full border transition-all flex items-center gap-2 text-xs font-serif font-bold shadow-sm ${
      theme === 'clean'
        ? 'bg-white text-gray-800 border-gray-300 hover:border-[#C9A356] hover:bg-gray-50'
        : 'bg-[#181612] text-[#C9A356] border-[#3A3326] hover:border-[#C9A356] hover:bg-[#25221B]'
    } ${className}`}
    title={theme === 'dark' ? "Alternar para Clean Mode (Fundo Claro)" : "Alternar para Dark Luxury (Modo Escuro)"}
  >
    {theme === 'dark' ? (
      <>
        <Icons.Moon className="w-3.5 h-3.5 text-[#C9A356]" />
        <span className="hidden sm:inline">Dark Luxury</span>
      </>
    ) : (
      <>
        <Icons.Sun className="w-3.5 h-3.5 text-[#C9A356]" />
        <span className="hidden sm:inline">Clean Mode</span>
      </>
    )}
  </button>
);
```

#### C. Presença Obrigatória do `ThemeToggle` nos Cabeçalhos das 5 Visões:
1. **Site Público:** Na barra superior mobile e na sidebar lateral desktop (junto aos botões de ação e abaixo do logo).
2. **Visão Dono:** No topo da tela gerencial ao lado do `DemoRoleSwitcher` e do botão "Site Público".
3. **Visão Barbeiro:** No topo do portal do barbeiro ao lado do `DemoRoleSwitcher`.
4. **Visão Recepção:** No topo da recepção ao lado do status do caixa e `DemoRoleSwitcher`.
5. **Visão Cliente:** No cabeçalho da Área do Cliente VIP ao lado do `DemoRoleSwitcher` e botão "Voltar ao Site".

#### D. Folha de Estilos de Alta Precisão para o Clean Mode
Adicionar ao `<style>` do `index.html`:
```css
/* ========================================================================= */
/* CLEAN MODE THEME (REQUISITO R2)                                           */
/* ========================================================================= */
html.clean-mode,
html.clean-mode body,
html.clean-mode #root {
  background-color: #F8F9FA !important;
  color: #111827 !important;
}

/* Fundo geral das seções e containers */
html.clean-mode .bg-\[\#0B0B0B\],
html.clean-mode .bg-\[\#0D0C0A\],
html.clean-mode .bg-\[\#0E0D0A\],
html.clean-mode .bg-\[\#050505\] {
  background-color: #F8F9FA !important;
}

/* Cartões brancos com sombras suaves */
html.clean-mode .bg-\[\#12110E\],
html.clean-mode .bg-\[\#161512\],
html.clean-mode .bg-\[\#161410\],
html.clean-mode .bg-\[\#181612\],
html.clean-mode .bg-\[\#1A1814\],
html.clean-mode .bg-\[\#1C1A14\],
html.clean-mode .bg-\[\#1D1B16\],
html.clean-mode .bg-\[\#1F1C16\],
html.clean-mode .bg-\[\#25221B\],
html.clean-mode .bg-\[\#1B1914\],
html.clean-mode .bg-\[\#191713\] {
  background-color: #FFFFFF !important;
  box-shadow: 0 4px 20px -2px rgba(0, 0, 0, 0.05), 0 2px 6px -1px rgba(0, 0, 0, 0.03) !important;
}

/* Headers e Sidebars no Clean Mode */
html.clean-mode header,
html.clean-mode aside {
  background-color: #FFFFFF !important;
  border-color: #E5E7EB !important;
}

/* Bordas sutis no Clean Mode */
html.clean-mode .border-\[\#2A261F\],
html.clean-mode .border-\[\#282319\],
html.clean-mode .border-\[\#2E281F\],
html.clean-mode .border-\[\#262118\],
html.clean-mode .border-\[\#2A2419\],
html.clean-mode .border-\[\#3A3326\],
html.clean-mode .border-\[\#211F1C\],
html.clean-mode .border-\[\#2D271F\],
html.clean-mode .border-\[\#2D271E\],
html.clean-mode .border-\[\#252018\],
html.clean-mode .border-\[\#1C1B18\],
html.clean-mode .border-\[\#1C1A14\],
html.clean-mode .border-\[\#28241E\],
html.clean-mode .border-\[\#3D362B\],
html.clean-mode .border-\[\#211E18\] {
  border-color: #E5E7EB !important;
}

/* Tipografia de alto contraste */
html.clean-mode .text-white,
html.clean-mode .text-\[\#E0DDD5\],
html.clean-mode .text-\[\#D6D2CA\] {
  color: #111827 !important;
}

html.clean-mode .text-gray-300,
html.clean-mode .text-gray-400,
html.clean-mode .text-\[\#A8A397\],
html.clean-mode .text-\[\#9E9B93\],
html.clean-mode .text-\[\#8C887F\],
html.clean-mode .text-\[\#B5B0A4\] {
  color: #4B5563 !important;
}

/* Inputs e Modais no Clean Mode */
html.clean-mode input,
html.clean-mode select,
html.clean-mode textarea {
  background-color: #FFFFFF !important;
  color: #111827 !important;
  border-color: #D1D5DB !important;
}

/* Hero Section adaptado para contraste perfeito */
html.clean-mode #home {
  background-image: linear-gradient(rgba(248, 249, 250, 0.90), rgba(248, 249, 250, 0.96)), url('espaco_interior_1.png') !important;
}
html.clean-mode #home h1 {
  color: #111827 !important;
}
html.clean-mode #home p {
  color: #374151 !important;
}
```

---

## 4. Diagnóstico de Erros no Console, React #130 & Defeitos de Execução

### 4.1. Verificação do Erro React #130
- O erro #130 ocorre quando um componente passado para renderização do React é `undefined` ou `null`.
- **Proteção existente:** O objeto `Icons` em `index.html` já conta com um `Proxy`:
  ```javascript
  const Icons = new Proxy(IconsBase, {
    get(target, prop) {
      if (prop in target) return target[prop];
      return ({ className = "w-4 h-4" }) => (
        <span className={`inline-block ${className}`}></span>
      );
    }
  });
  ```
  Essa proteção impede que chamadas como `<Icons.Inexistente />` quebrem a árvore do React.
- **Auditoria de Ícones:** Todos os 24 ícones invocados como `<Icons.Nome>` estão perfeitamente implementados em `IconsBase` (Award, Calendar, Camera, Check, ChevronLeft, ChevronRight, Clipboard, Clock, Coffee, CreditCard, Crown, Edit, Home, Info, Lock, MapPin, MessageCircle, Package, Plus, Scissors, Trash, TrendingUp, User, Users, Wine, X).
- **Atenção:** Os ícones `Sun` e `Moon` (necessários para o alternador de Dark/Clean Mode) **não** estão em `IconsBase` e devem ser adicionados explicitamente com SVGs de alta definição.

### 4.2. DEFEITO CRÍTICO ENCONTRADO: Bug na Navegação do Perfil Cliente
- **Localização:** Linha 967 de `index.html`.
- **Código atual:**
  ```javascript
  } else if (roleKey === 'cliente') {
    setCurrentUser({
      name: clientProfile.name,
      email: clientProfile.email,
      role: 'cliente',
      barberKey: 'cliente',
      title: clientProfile.tier,
      avatar: 'logo_valverds_clean.png'
    });
    setCurrentView('client');
    setClientTab('agendamentos'); // <-- BUG: esta aba NÃO existe!
  }
  ```
- **Impacto:** As abas existentes na Área do Cliente (declaradas na linha 629 e renderizadas nas linhas 3228 a 3760) são:
  - `'agendar'` (Agendar Horário)
  - `'meu_corte'` (Meu Agendamento)
  - `'calendario_geral'` (Calendário Geral)
  - `'produtos_bar'` (Bar & Produtos)
  - `'fidelidade'` (Cartão Fidelidade)
  Ao trocar para o perfil Cliente via `DemoRoleSwitcher`, o valor `clientTab` fica `'agendamentos'`, resultando em uma tela de conteúdo completamente vazia/em branco para o usuário!
- **Correção mandatória:** Alterar a linha 967 para `setClientTab('agendar');` (ou `'meu_corte'`).

### 4.3. Risco de Temporal Dead Zone (TDZ)
- A constante `const currentWeek` é declarada na linha 907, mas o método `handleClientSubmitBooking` (linhas 780-820) referencia `currentWeek` na linha 793. Embora o clique ocorra em runtime após a montagem, é uma boa prática mover a declaração de `currentWeek` para cima (logo após os estados, por volta da linha 630).

---

## 5. Matriz de Recomendações Executivas para Implementação

| ID | Item | Arquivo / Linha | Ação Recomendada | Prioridade |
| :--- | :--- | :--- | :--- | :--- |
| **REC-01** | **Suporte a Dark Mode / Clean Mode** | `index.html` (Head, State, CSS) | Implementar estado `theme`, persistência em `localStorage`, meta tag dinâmica e folha de estilos `html.clean-mode`. | **Crítica (R2)** |
| **REC-02** | **ThemeToggle em Todos os Cabeçalhos** | `index.html` (5 visões) | Inserir o alternador de tema nos cabeçalhos de Site Público, Dono, Barbeiro, Recepção e Cliente. | **Crítica (R2)** |
| **REC-03** | **Correção do Bug da Aba do Cliente** | `index.html` (Linha 967) | Alterar `setClientTab('agendamentos')` para `setClientTab('agendar')`. | **Crítica (Bug Fix)** |
| **REC-04** | **Adição de Ícones Sun & Moon** | `index.html` (IconsBase ~linha 280) | Adicionar os SVGs vetoriais dos ícones `Sun` e `Moon` ao objeto `IconsBase`. | **Alta (R2)** |
| **REC-05** | **Aprimoramento do Carrossel de Fotos** | `index.html` (Linhas 1568-1580) | Adicionar autoplay sutil com hover-pause, contador `01 / 09`, indicador de dots e ícones `Icons.ChevronLeft` / `Icons.ChevronRight`. | **Alta (R1)** |
| **REC-06** | **Scroll Horizontal no Menu Mobile** | `index.html` (Linha 1379) | Adicionar `overflow-x-auto no-scrollbar` no `<nav>` da sidebar mobile do site público para evitar corte de rótulos. | **Média (R1)** |
| **REC-07** | **Lapidação de Micro-Interações** | `index.html` (CSS / Modais) | Adicionar transição suave para modais e toalha de confirmação com `backdrop-blur-md` e animação de fade-in suave. | **Média (R1)** |
