$lines = [System.IO.File]::ReadAllLines("C:\Users\blaminma\Downloads\valverds-barbershop\index.html")
$components = [System.Collections.Generic.HashSet[string]]::new()

foreach ($line in $lines) {
    [regex]::Matches($line, '<([A-Z][a-zA-Z0-9_]*)') | ForEach-Object {
        [void]$components.Add($_.Groups[1].Value)
    }
}

Write-Output "=== REACT COMPONENTS FOUND IN JSX ==="
$components | Sort-Object | ForEach-Object { Write-Output "  $_" }
