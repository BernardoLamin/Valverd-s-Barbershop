param([string]$filePath, [string]$pattern, [int]$count = 20)
$lines = [System.IO.File]::ReadAllLines($filePath)
$i = 0
$found = 0
foreach ($line in $lines) {
    $i++
    if ($line -match $pattern) {
        Write-Output "$($i): $($line.Trim())"
        $found++
        if ($found -ge $count) { break }
    }
}
Write-Output "Total matches found in $filePath : $found"
