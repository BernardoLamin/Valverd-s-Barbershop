# Project: Valverd's BarberShop Officialization & Luxury Polish

## Architecture
- **Client Interface**: Standalone Single-Page Application (SPA) in `index.html` (React 18 + Tailwind CSS + Lucide Icons Base).
- **Styling Architecture**: Luxury Dark theme (`#0B0B0B`, gold `#C9A356`, dark cards `#161410`) and Clean Mode (`#F8F9FA`, white cards `#FFFFFF`, borders `#E5E7EB`) controlled via `html.clean-mode` CSS root class and `valverds_theme` in `localStorage`.
- **Role System**: 5 distinct roles/views:
  1. `Site`: Public luxury landing page with photo gallery, service menu, barbers, and booking triggers.
  2. `Cliente`: Client area with 5-step booking flow, My Haircuts, Salon Calendar (privacy-protected), Bar products, and Loyalty card.
  3. `Barbeiro`: Barber dashboard with appointment counts, direct WhatsApp wa.me links, daily shift configuration, and schedule blocks.
  4. `Recepcao`: Multi-chair board, barber team management, stock inventory (+/-), and checkouts.
  5. `Dono`: Executive management macro view, real-time DRE with separate service and bar revenue, precise commissions (Luis 60%, Yago 50%), supply costs, and net margin.
- **Database Architecture**: Neon PostgreSQL (PostgreSQL 18.6 on AWS `sa-east-1`).
  - Tables: `barbers`, `services`, `products`, `clients`, `appointments`, `appointment_items`, `financial_records`, `daily_settings`.
  - Credentials in `.env`. Synchronization and connectivity via PowerShell/HTTPS REST/SQL API.

## Feature Inventory
| # | Feature | Description | Milestone | Status | Source |
|---|---------|-------------|-----------|--------|--------|
| 1 | Luxury Typography & Styling | Cinzel & Plus Jakarta Sans typography, gold metallic touches (#C9A356), max-w-[1440px], overflow-x hidden, mobile nav fix | M1 | DONE | ORIGINAL_REQUEST §R1 |
| 2 | Photo Carousel Polish | Autoplay with hover pause, slide counter (01/09), vector arrows, 18 real photo assets verified | M1 | DONE | ORIGINAL_REQUEST §R1 |
| 3 | Client Tab Bug Fix | Fix line 967 `setClientTab('agendamentos')` -> `setClientTab('agendar')` to eliminate white screen bug | M1 | DONE | Survey Explorer 1 & 2 |
| 4 | Dark Mode & Clean Mode Core | `valverds_theme` state in React, localStorage persistence, CSS rules for `html.clean-mode` (#F8F9FA bg, #FFFFFF cards, #111827 text) | M2 | PLANNED | ORIGINAL_REQUEST §R2 |
| 5 | Header Theme Toggle | 1-click Sun/Moon toggle in header across all 5 views (Site, Cliente, Barbeiro, Recepção, Dono) | M2 | PLANNED | ORIGINAL_REQUEST §R2 |
| 6 | Theme Icons in IconsBase | Implement `Sun` and `Moon` SVG icons in `IconsBase` | M2 | PLANNED | Survey Explorer 1 |
| 7 | 48-Slot Universal Schedule Grid | Generate all 48 blocks of 30 min from 00:00 to 23:30 (`ALL_48_TIME_SLOTS`) replacing 13/14 static 45-min slots | M3 | PLANNED | ORIGINAL_REQUEST §R3 |
| 8 | Dynamic Custom Time Slots | Allow adding custom times (e.g., 08:15, 19:40) in client booking, barber schedule, and chair comparison table | M3 | PLANNED | ORIGINAL_REQUEST §R3 |
| 9 | 5-Step Guided Booking Flow | Stepper 1-5 (Barber -> Services & Bar -> Day -> Time -> Client Info) with full bar items and confirmation toast | M3 | PLANNED | ORIGINAL_REQUEST §R3 |
| 10 | Client Schedule Privacy | Privacy-protected salon calendar showing slot availability counts without exposing client names | M3 | PLANNED | ORIGINAL_REQUEST §R3 |
| 11 | DRE Mathematical Accuracy | Separate Service revenue from Bar revenue; calculate barber commissions strictly on services (Luis 60%, Yago 50%); supply costs; net profit & margin % | M4 | PLANNED | ORIGINAL_REQUEST §R4 |
| 12 | Multi-Day DRE & Counter Sales Persistence | Remove hardcoded Monday 'Seg' lock; persist `counterSales` to `localStorage` | M4 | PLANNED | Survey Explorer 3 |
| 13 | Barber & Reception Management Polish | wa.me links, booked vs free counters with 48 slots, multi-chair day navigation, product creation with cost price | M4 | PLANNED | ORIGINAL_REQUEST §R4 |
| 14 | Neon PostgreSQL Integration | `.env` file with official credentials, updated `database/schema.sql` (bar category, appointment_items) and `seed.sql` (Luis/Yago), migration & connection script | M4 | PLANNED | ORIGINAL_REQUEST §R4 |
| 15 | E2E Opaque-Box Test Suite | Automated verification across Tiers 1-4 validating R1-R4 acceptance criteria | E2E Track | DONE | Project Pattern |
| 16 | Adversarial Hardening (Tier 5) | White-box code inspection and edge-case stress verification | Final Milestone | PLANNED | Project Pattern |

## Milestones
| # | Name | Scope | Dependencies | Status |
|---|------|-------|-------------|--------|
| E2E | E2E Testing Suite | Requirements-driven opaque-box test runner & Tiers 1-4 tests (`TEST_READY.md`) | none | DONE |
| M1 | Luxury Visual Polish & Carousel | Typography, photo carousel autoplay/dots/arrows, mobile nav fix, line 967 bug fix | none | DONE |
| M2 | Dark/Clean Mode Theme System | Theme state, localStorage sync, CSS clean-mode classes, 1-click header toggle, Sun/Moon icons | M1 | IN_PROGRESS |
| M3 | 24h Schedule Grid & Booking Flow | 48 30-min slots (00:00-23:30), custom times (08:15, 19:40), 5-step stepper, client privacy | M2 | PLANNED |
| M4 | Executive Management, DRE & Neon DB | DRE math (service/bar split, commissions 60%/50%), multi-chair, .env, schema.sql, seed.sql, Neon migration script | M3 | PLANNED |
| M_FINAL | 100% E2E Pass & Hardening | Phase 1: 100% E2E Pass; Phase 2: Tier 5 adversarial testing & forensic audit | M4, E2E | PLANNED |

## Key Milestone Outputs
- **E2E Testing Suite**: `TEST_INFRA.md`, `TEST_READY.md`, `tests/run_e2e_tests.ps1`, 32 tests covering Tiers 1-4.
- **M1 (Luxury Polish & Carousel)**: `index.html` updated with 2-tier mobile header, sticky desktop 1440px container, carousel 5s autoplay/dots/chevrons/badges, line 967 bug fix `setClientTab('agendar')`, vector `Icons.X`, and keyframe animations. Verified by 6/6 automated tests, 33/33 Chromium stress tests, 2x Reviewers, 2x Challengers, and Forensic Auditor.

## Interface Contracts
### Theme System Contract (M2)
- LocalStorage key: `'valverds_theme'` with values `'dark'` | `'clean'`.
- HTML Root Class: `document.documentElement.classList.toggle('clean-mode', theme === 'clean')`.
- Clean Mode Palette: Background `#F8F9FA`, Card Surfaces `#FFFFFF`, Text Primary `#111827`, Text Muted `#4B5563`, Borders `#E5E7EB`, Gold Accents `#C9A356`.
- Header Toggle: Accessible in all views with `Sun` (when dark) and `Moon` (when clean) icons.

### Schedule System Contract (M3)
- `ALL_48_TIME_SLOTS`: Array of 48 strings `['00:00', '00:30', ..., '23:30']`.
- Custom Slots: Merged dynamically into schedule matrices: `Array.from(new Set([...baseSlots, ...customSlots])).sort()`.
- Booking Step Contract: Stepper 1 -> 2 -> 3 -> 4 -> 5 with explicit state validation before step advancement.

### Financial & DRE Contract (M4)
- Revenue Gross = `revenueServices + revenueBar + revenueBalcao`.
- `revenueServices`: Sum of services completed (strictly service items).
- `revenueBar`: Sum of bar items attached to appointments + counter bar sales.
- Commissions: Luis Valverde = 60% of service items; Yago Barber = 50% of service items. Bar items = 0% barber commission.
- Product Costs = Sum of item cost prices (or 45% default if cost undefined).
- Net Profit = Gross Revenue - Commissions - Product Costs - Fixed Costs. Margin % = (Net Profit / Gross Revenue) * 100.

## Code Layout
- `index.html`: Main SPA application file containing React components, state, CSS rules, and templates.
- `database/schema.sql`: Official PostgreSQL schema for Neon.
- `database/seed.sql`: Initial seed data with Luis Valverde and Yago Barber, services, and inventory.
- `.env`: Environment variables with Neon connection strings and auth URLs.
- `database/neon_test.ps1`: Automated PowerShell script to verify Neon PostgreSQL HTTP & TCP connectivity.
- `tests/`: E2E test scripts and validation runners.
