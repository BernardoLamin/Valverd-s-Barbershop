# Original User Request

## Initial Request — 2026-09-27T18:45:37Z

Oficialização completa e polimento de nível de alta relojoaria da plataforma Valverd's BarberShop, elevando a identidade visual ao padrão de barbearia de luxo internacional, integrando o banco Neon PostgreSQL oficial, suporte a Dark Mode / Clean Mode e refinando a gestão executiva com grade flexível de horários (00:00 às 23:30) e DRE real.

Working directory: `C:\Users\blaminma\Downloads\valverds-barbershop`
Integrity mode: development

## Conexão & Credenciais Oficiais (Neon PostgreSQL)
```env
DATABASE_URL="postgresql://neondb_owner:npg_ge8qFDxnNP9i@ep-cold-sea-b6kzh799.c-2.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require"
DATABASE_URL_POOLED="postgresql://neondb_owner:npg_ge8qFDxnNP9i@ep-cold-sea-b6kzh799-pooler.c-2.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require"
NEON_AUTH_BASE_URL="https://ep-cold-sea-b6kzh799.neonauth.c-2.sa-east-1.aws.neon.tech/neondb/auth"
```

## Requirements

### R1. Design Visual de Barbearia de Luxo (Oficialização de Elite)
Retirar qualquer aspecto visual "cru" ou de protótipo. O site público e as áreas autenticadas devem apresentar padrão estético internacional de alfaiataria/barbearia premium: tipografia Cinzel e Plus Jakarta Sans lapidada, acabamentos dourados metálicos sutis, fotografias reais do espaço perfeitamente harmonizadas, carrossel de fotos, micro-interações elegantes nos botões e espaçamentos consistentes.

### R2. Suporte Completo a Dark Mode & Clean Mode (Alternância com 1 Clique)
Disponibilizar um alternador de tema elegante e intuitivo presente no cabeçalho de todas as visões (Site, Cliente, Barbeiro, Recepção e Dono), permitindo alternar instantaneamente entre o **Dark Luxury** (preto profundo `#0B0B0B` com detalhes dourados) e o **Clean Mode** (fundo claro editorial `#F8F9FA`, cartões brancos `#FFFFFF` com sombras suaves e tipografia escura de alto contraste), persistindo a preferência do usuário no `localStorage`.

### R3. Grade Completa de Horários (00:00 até 23:30) & Horários Customizados
Ampliar a seleção e parametrização de horários para cobrir todos os 48 blocos de 30 em 30 minutos (de 00:00 até 23:30), permitindo ainda a adição dinâmica de horários personalizados (ex: 08:15, 19:40). Esse suporte deve funcionar tanto no agendamento do cliente quanto no controle de escalas e bloqueios de agenda do barbeiro e do proprietário.

### R4. Gestão Executiva Refinada, DRE e Integração com Banco Neon
Consolidar a estrutura de gestão da barbearia:
- **Dono**: Visão Macro com DRE em tempo real (Receita Bruta com separação de Serviços e Bar, deduções de comissões por barbeiro [Luis 60%, Yago 50%], custo de insumos e Lucro Líquido Real com margem percentual).
- **Barbeiro**: Minha Agenda com contagem de agendados vs livres, WhatsApp direto de contato com o cliente (`wa.me`) e ajuste de jornada diária (entrada, saída e folga por dia da semana).
- **Recepção**: Visão multi-cadeiras, cadastro completo de barbeiros e controle de estoque com ajustes rápidos (`+` e `-`).
- **Banco de Dados**: Estruturar e sincronizar os dados com o banco relacional Neon PostgreSQL (`database/schema.sql` e `.env`).

## Acceptance Criteria

### Estética & Responsividade
- [ ] O layout possui acabamento final de produto oficial, sem nenhuma ponta solta ou aparência de protótipo.
- [ ] O alternador de Dark Mode / Clean Mode opera suavemente sem recarregar a tela e mantém a escolha salva no `localStorage`.
- [ ] A responsividade está 100% travada em todas as telas (celular, tablet e monitor widescreen) com `max-w-[1440px]` e sem transbordo horizontal (`overflow-x: hidden`).

### Horários & Agendamento
- [ ] A grade de horários disponibiliza a lista completa de 00:00 a 23:30 (intervalos de 30 min) além de aceitar horários customizados.
- [ ] O cliente agenda em 5 passos simples (Barbeiro -> Serviços + Bar -> Dia -> Horário -> Nome e WhatsApp) com feedback e toast de confirmação.
- [ ] O calendário geral do cliente respeita estrita privacidade, mostrando contagem de vagas sem expor nomes de outros clientes.

### Gestão & DRE
- [ ] O DRE calcula e exibe com precisão matemática: Receita Bruta, Comissões Equipe, Custo de Insumos e Lucro Líquido Real.
- [ ] O arquivo `index.html` roda sem erros no console (zero React error #130 ou referências nulas).
- [ ] Configuração do Neon PostgreSQL e script de conexão documentados e integrados ao projeto.
