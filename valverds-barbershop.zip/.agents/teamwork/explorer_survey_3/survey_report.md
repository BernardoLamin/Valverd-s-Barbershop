# Relatório de Levantamento e Auditoria Técnica — R4
## Gestão Executiva, DRE, Visões de Barbeiro/Recepção e Integração Neon PostgreSQL
**Valverd's BarberShop — "Beard, hair and mustache"**
*Investigador: Survey Explorer 3*  
*Data de Execução: 27/09/2026*  
*Status: Concluído*

---

## 1. Sumário Executivo

A auditoria técnica da dimensão **R4** cobriu quatro eixos essenciais do sistema:
1. **Painel do Dono & Motor de Cálculo do DRE**: Fórmulas matemáticas, separação de receitas (Serviços vs. Bar), apuração de comissões por profissional (Luis Valverde 60%, Yago Barber 50%), apropriação de custos de insumos/produtos e cálculo da margem líquida real.
2. **Portal do Barbeiro**: Minha Agenda, contadores de agendados vs. livres, gerador de link direto WhatsApp (`wa.me`), controle de jornada e gestão de folgas/doenças (`minha_escala`).
3. **Visão da Recepção**: Monitoramento multi-cadeiras, quadro executivo de barbeiros (CRUD) e controle de estoque com botões rápidos (`+` e `-`).
4. **Infraestrutura de Banco de Dados & Neon PostgreSQL**: Conectividade de rede (TCP 5432 / SSL / HTTP SQL API), análise do esquema DDL (`database/schema.sql`), arquivo `.env`, scripts de teste de conexão e lacunas de sincronização.

### Diagnóstico Resumido:
- **Conectividade Neon PostgreSQL**: O cluster oficial Neon (`ep-cold-sea-b6kzh799.c-2.sa-east-1.aws.neon.tech`) está **100% ativo e responsivo** em São Paulo (AWS sa-east-1) rodando **PostgreSQL 18.6**. O handshake SSL na porta 5432 e a API HTTP SQL (`/sql`) via HTTPS foram validados e retornaram sucesso.
- **Estado do Banco de Dados**: A base Neon está **completamente vazia** (`count(*) = 0` na `information_schema.tables`). Não havia arquivo `.env` na raiz do projeto e nenhum script de conexão ou migração configurado.
- **DRE & Fórmulas**: A estrutura contábil está presente, mas possui **3 vieses matemáticos críticos**:
  1. O DRE está travado na segunda-feira (`day === 'Seg'`), ignorando agendamentos de outros dias.
  2. Bebidas e produtos consumidos em atendimentos são computados na Receita de Cortes (`revenueServices`), distorcendo a separação Serviços vs. Bar.
  3. No agendamento do cliente, o preço total contamina `a.price`, fazendo com que os barbeiros recebam comissão indevida (50% a 60%) sobre o valor de cervejas e itens de bar.
- **Portal do Barbeiro & Escalas**: O link `wa.me` e a alternância de folgas funcionam com persistência, mas a grade de horários disponível para agendamento (`allBaseSlots`) está limitada a 13 horários fixos de 45 min entre 09:00 e 18:15, desrespeitando o requisito R3 (48 blocos de 00:00 a 23:30 e horários customizados).
- **Multi-Cadeiras & Recepção**: A visão de cadeiras lado a lado exibe os barbeiros cadastrados, porém está restrita visualmente a um único dia sem seletor de data. O cadastro de novo produto no estoque omite o campo de custo unitário (`cost`), forçando a estimativa por fallback (45% da venda) no DRE.

---

## 2. Visão do Dono & Motor de Cálculo do DRE

### 2.1 Análise das Fórmulas Matemáticas Atuais
No arquivo principal `index.html` (linhas 971 a 1018), as métricas do DRE são computadas através dos seguintes seletores React:

```javascript
// Linhas 971-973: Filtro dos agendamentos de hoje
const todaysAppointments = useMemo(() => {
  return appointments.filter(a => a.day === 'Seg' && (a.weekId === 0 || a.weekId === undefined));
}, [appointments]);

const completedToday = todaysAppointments.filter(a => a.status === 'concluido');

// Linhas 980-982: Receita
const revenueServices = completedToday.reduce((acc, a) => acc + (a.total || a.price), 0);
const revenueBalcao = counterSales.reduce((acc, s) => acc + s.total, 0);
const totalRevenueToday = revenueServices + revenueBalcao;

// Linhas 993-999: Comissões
const totalTeamCommissionsToday = useMemo(() => {
  return completedToday.reduce((acc, a) => {
    const barberObj = barbers.find(b => b.name === a.barber || b.barberKey === a.barber || b.id === a.barber);
    const rate = barberObj ? (barberObj.commissionRate / 100) : 0.50;
    return acc + (a.price * rate);
  }, 0);
}, [completedToday, barbers]);

// Linhas 1002-1016: Custos de Insumos e Produtos Vendidos
const totalSuppliesCostToday = useMemo(() => {
  let apptProductsCost = 0;
  completedToday.forEach(appt => {
    if (Array.isArray(appt.items)) {
      appt.items.slice(1).forEach(item => {
        apptProductsCost += getProductCost(item.name);
      });
    }
  });
  let balcaoProductsCost = 0;
  counterSales.forEach(sale => {
    balcaoProductsCost += getProductCost(sale.item) * (sale.qty || 1);
  });
  return apptProductsCost + balcaoProductsCost;
}, [completedToday, counterSales, products]);

// Linhas 1018: Lucro Líquido Real
const netProfitToday = totalRevenueToday - totalTeamCommissionsToday - totalSuppliesCostToday;

// Linha 2767: Margem Líquida Percentual
const marginPercent = totalRevenueToday > 0 ? ((netProfitToday / totalRevenueToday) * 100).toFixed(1) : '0';
```

### 2.2 Inconsistências & Falhas Matemáticas Detectadas

| Item | Regra de Negócio Exigida | Implementação Atual | Impacto no DRE |
| :--- | :--- | :--- | :--- |
| **Escopo Temporal** | DRE em tempo real acompanhando o dia/semana selecionado | Travado em `a.day === 'Seg'` e `weekId === 0` | Agendamentos concluídos em Ter, Qua, Qui, Sex ou Sáb resultam em DRE zerado |
| **Separação Serviços vs. Bar** | Receita Bruta separada rigorosamente entre Serviços e Bar | `revenueServices` soma `(a.total || a.price)`. O bar só recebe `counterSales` | Cervejas/doses adicionadas à comanda do cliente no corte vão para a conta de "Cortes" em vez de "Bar" |
| **Comissão da Equipe sobre Bar** | Comissões aplicáveis exclusivamente aos serviços (Luis 60%, Yago 50%) | No fluxo do cliente (linhas 808-813), `price: totalPrice`. Se o cliente adiciona extras, `a.price` inclui bebidas | O barbeiro ganha 50% ou 60% de comissão sobre a Heineken ou produto comercializado |
| **Custo de Novos Produtos** | Dedução do Custo Real de Mercadorias Vendidas (CMV) | `newProductForm` não possui campo `cost`. Fallback arbitrária: `prod.price * 0.45` | Margem líquida distorcida para qualquer produto novo adicionado na recepção |
| **Persistência de Vendas Balcão** | Vendas PDV devem persistir no histórico financeiro | `counterSales` é um `useState` em memória sem `localStorage` | Ao atualizar a página (F5), todas as vendas de balcão do dia são apagadas |

### 2.3 Taxas de Comissão Verificadas
- **Luis Valverde (Dono/Barbeiro)**: Cadastrado em `INITIAL_BARBERS` com `commissionRate: 60` (60%). Corretamente parametrizado.
- **Yago Barber (Barbeiro)**: Cadastrado em `INITIAL_BARBERS` com `commissionRate: 50` (50%). Corretamente parametrizado.
- **Exibição no Painel**: No card comparativo de performance por barbeiro (linhas 2715-2749), ambos são exibidos com Atendimentos, Faturamento e Comissão Paga calculada individualmente.

---

## 3. Visão do Barbeiro: Agenda, Métricas & Escalas

### 3.1 Minha Agenda & Contadores (Agendados vs. Livres)
- **Localização**: Linhas 2107 a 2250 em `index.html`.
- **Contadores de Vagas**:
  - Exibe no cabeçalho do dia:
    `{myAllAppointments.filter(a => a.day === selectedWeekDay...).length} agendados • {getAvailableSlotsForBarberAndDay(currentUser.barberKey, selectedWeekDay).length} livres`
  - A contagem de agendados reflete os registros do barbeiro ativo.
  - A contagem de livres subtrai os horários agendados da grade base permitida para aquele dia.
- **Lacuna na Grade de Horários**:
  - `getAvailableSlotsForBarberAndDay` (linha 724) utiliza:
    `const allBaseSlots = ['09:00', '09:45', '10:30', '11:15', '12:00', '13:00', '13:45', '14:30', '15:15', '16:00', '16:45', '17:30', '18:15'];`
  - **Problema**: O requisito R3 exige grade integral de **00:00 até 23:30 (intervalos de 30 minutos, totalizando 48 blocos)**, com suporte a horários customizados. A grade atual só possui 13 horários em blocos de 45 minutos.

### 3.2 Integração com WhatsApp (`wa.me`)
- **Localização**: Linhas 2215 a 2224 em `index.html`.
- **Implementação**:
  ```jsx
  <a
    href={`https://wa.me/55${(a.phone || '21970100668').replace(/\D/g, '')}?text=${encodeURIComponent(
      `Olá ${a.client}! Passando para confirmar seu horário na Valverd's BarberShop hoje às ${a.time} (${a.service}). Até logo!`
    )}`}
    target="_blank"
    rel="noopener noreferrer"
    className="..."
  >
    <Icons.MessageCircle className="w-3.5 h-3.5" />
    <span>WhatsApp</span>
  </a>
  ```
- **Avaliação**: O link opera perfeitamente. Trata caracteres não-numéricos do telefone, formata com DDI 55, faz `encodeURIComponent` da mensagem com o nome do cliente, horário e serviço, e abre em nova aba com segurança (`rel="noopener noreferrer"`).

### 3.3 Gestão de Jornada & Escala Diária (`minha_escala`)
- **Localização**: Linhas 2467 a 2580 em `index.html`.
- **Funcionalidades**:
  - Alternância imediata de status: botão *"Marcar Folga / Doente"* que altera `available: false` para o dia específico (Seg a Sáb).
  - Seletores de Entrada (`start`) e Saída (`end`).
  - Persistência no `localStorage` via chave `valverds_daily_settings`.
  - Sincronização: Quando um dia é marcado como indisponível, `getAvailableSlotsForBarberAndDay` retorna `[]` imediatamente, bloqueando agendamentos de clientes para aquele barbeiro naquele dia.
- **Lacunas**:
  - As opções dos `<select>` de entrada e saída são restritas (Entrada: 08:30 a 11:00; Saída: 15:00 a 20:00). Não cobrem a totalidade da grade flexível requerida.
  - Domingo (`Dom`) não está listado na gestão diária do barbeiro.

---

## 4. Visão da Recepção: Cadeiras, Equipe & Estoque

### 4.1 Multi-Cadeiras (`receptionTab === 'agenda'`)
- **Localização**: Linhas 2800 a 2876 em `index.html`.
- **Estrutura**:
  - `barbers.map(barber => ...)` renderiza um card independente para cada cadeira cadastrada (`Cadeira 01`, `Cadeira 02`, etc.).
  - Exibe foto, nome do profissional, horário de escala e lista de atendimentos do dia.
  - Ações operacionais por atendimento:
    - Botão **Cobrar** (abre modal de checkout com acréscimo de bebidas/produtos do estoque).
    - Botão **Editar** (ajuste de cliente, horário, serviço e observações).
    - Botão **Excluir** (cancelamento com confirmação).
  - Botões de topo: **Venda Balcão (PDV)** e **Novo Encaixe**.
- **Lacuna**: A lista filtra estritamente `todaysAppointments` (`day === 'Seg'`). Falta um seletor visual de dia da semana (Seg a Sáb) para a recepcionista gerenciar a agenda dos outros dias sem sair da tela.

### 4.2 Cadastro de Barbeiros (`receptionTab === 'equipe'`)
- **Localização**: Linhas 3016 a 3084 e Modais (linhas 4308 a 4480).
- **Funcionalidades**:
  - **Adicionar Barbeiro**: Modal completo com Nome, Cadeira (`Cadeira 03`), Comissão percentual (ex: 50%), Instagram handle, Cargo e foto padrão.
  - **Editar Barbeiro**: Edição de qualquer atributo cadastrado com atualização imediata em tela.
  - **Excluir Barbeiro**: Protegido para não permitir exclusão caso reste apenas 1 barbeiro no sistema.
  - Persistência automática em `localStorage.getItem('valverds_barbers')`.
- **Lacuna de Integração**: Ao criar um novo barbeiro via interface, a chave correspondente em `dailyBarberSettings` não é inicializada com valores padrão, dependendo de fallbacks em tempo de execução.

### 4.3 Controle de Estoque & Ajustes Rápidos (`+` e `-`)
- **Localização**: Linhas 2880 a 2935 em `index.html`.
- **Funcionalidades**:
  - Botões rápidos `+` e `-` que invocam `updateStock(p.id, delta)` garantindo que o estoque não fique negativo (`Math.max(0, item.stock + delta)`).
  - Alerta visual em vermelho quando o estoque atinge ou fica abaixo do nível mínimo (`stock <= minStock`).
  - Persistência em `localStorage.getItem('valverds_products')`.
  - Banner fotográfico premium com foto real do balcão (`foto_produtos_reais.jpg`) exibindo pomadas Red Nek, Fox For Men e Dom Pelo.
- **Lacunas**:
  - No modal de cadastro de produto (linhas 4735-4815), não há input para informar o custo (`cost_price`), apenas preço de venda, estoque e estoque mínimo.
  - Não há histórico ou log de movimentações de estoque (tabela `stock_movements`).

---

## 5. Auditoria de Banco de Dados & Neon PostgreSQL

### 5.1 Credenciais & Conectividade Verificada
As credenciais estipuladas no `ORIGINAL_REQUEST.md`:
```env
DATABASE_URL="postgresql://neondb_owner:npg_ge8qFDxnNP9i@ep-cold-sea-b6kzh799.c-2.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require"
DATABASE_URL_POOLED="postgresql://neondb_owner:npg_ge8qFDxnNP9i@ep-cold-sea-b6kzh799-pooler.c-2.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require"
NEON_AUTH_BASE_URL="https://ep-cold-sea-b6kzh799.neonauth.c-2.sa-east-1.aws.neon.tech/neondb/auth"
```

#### Testes Empíricos Executados:
1. **Teste de Conectividade TCP (Porta 5432)**:
   - Host Direto: `ep-cold-sea-b6kzh799.c-2.sa-east-1.aws.neon.tech:5432` -> **TcpTestSucceeded: True** (IP: 15.228.0.140)
   - Host Pooled: `ep-cold-sea-b6kzh799-pooler.c-2.sa-east-1.aws.neon.tech:5432` -> **TcpTestSucceeded: True** (IP: 56.125.127.1)
2. **Handshake SSL PostgreSQL Wire Protocol**:
   - Envio de pacote `SSLRequest` (`0x04D2162F`).
   - Resposta do servidor: byte `'S'` (SSL Habilitado e Exigido).
3. **API HTTP SQL Neon Serverless (`/sql`)**:
   - Requisição autenticada com header `Neon-Connection-String`.
   - Consulta: `SELECT version();`
   - Resposta:
     ```json
     {
       "version": "PostgreSQL 18.6 (6569466) on aarch64-unknown-linux-gnu, compiled by gcc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0, 64-bit"
     }
     ```
   - Status: **Operação em nuvem 100% validada**.
4. **Verificação de Tabelas Existentes**:
   - Consulta: `SELECT count(*) FROM information_schema.tables WHERE table_schema = 'public';`
   - Resposta: `{"count": "0"}`.
   - Diagnóstico: O banco está completamente cru, aguardando aplicação do esquema.

### 5.2 Análise Crítica do Esquema DDL (`database/schema.sql`)
O arquivo `database/schema.sql` (212 linhas) contém tabelas bem arquitetadas com tipos ENUM e restrições de chave estrangeira. No entanto, foram identificadas **incompatibilidades estruturais** com as necessidades do projeto:

1. **Incompatibilidade da Categoria de Produtos**:
   - `schema.sql` define:
     ```sql
     CREATE TYPE product_category_enum AS ENUM ('internal_use', 'resale');
     ```
   - No frontend, os produtos são divididos em `'Bar'` (Heineken, IPA, Corona, Whisky, Café) e `'Produtos'` (Pomadas, Óleos, Tônicos).
   - O enum atual impossibilita a segregação contábil requerida para o DRE ("Receita Bruta com separação de Serviços e Bar").
2. **Falta de Tabela de Itens de Agendamento (`appointment_items`)**:
   - A tabela `appointments` possui apenas `service_id UUID REFERENCES services(id)`.
   - Quando um cliente consome produtos do bar durante o corte (ex: cerveja ou combo com barboterapia), não há como persistir múltiplos itens em um único agendamento sem uma tabela associativa.
3. **Lacunas na Tabela de Barbeiros (`barbers`)**:
   - Faltam colunas: `chair VARCHAR(30)`, `avatar_url VARCHAR(255)`, `instagram_handle VARCHAR(50)`, `reviews_count INT DEFAULT 0`, `bio TEXT` e `daily_settings JSONB`.
4. **Descompasso no `seed.sql`**:
   - O `database/seed.sql` insere barbeiros fictícios ("Carlos Navalha", "Matheus Ribeiro", "Diego Silveira") em vez de registrar **Luis Valverde** (60%) e **Yago Barber** (50%).

---

## 6. Matriz de Recomendações e Plano de Ação

### R4.1 — Correção do Motor de DRE & Comissões
1. **Dinâmica de Seleção de Dia**:
   Substituir a constante hardcoded `'Seg'` por um estado dinâmico (`selectedDREDay`), permitindo ao dono analisar o DRE de qualquer dia da semana ou o consolidado acumulado da semana inteira.
2. **Separação Exata de Receitas**:
   - Classificar cada item faturado (`a.items` e `counterSales`):
     - `revenueServices`: Soma estrita de itens onde categoria é de serviço capilar/barba (`'Cabelo'`, `'Barba'`, `'Combo'`, `'Estética'`, `'Tratamento'`).
     - `revenueBar`: Soma de itens da categoria `'Bar'` (cervejas, destilados, refrigerantes, cafés) consumidos em atendimentos + vendidos no balcão.
     - `revenueRetailProducts`: Soma de produtos de revenda cosmética (pomadas, tônicos).
   - Receita Bruta = `revenueServices + revenueBar + revenueRetailProducts`.
3. **Cálculo Blindado de Comissão**:
   - A comissão do profissional deve incidir **apenas sobre `revenueServices`** gerada por ele, nunca sobre cervejas ou cosméticos:
     $$\text{Comissão Barbeiro} = \sum_{\text{serviços atendidos}} (\text{preço do serviço} \times \text{taxa de comissão})$$
4. **Campo Custo no Modal de Produtos**:
   Adicionar `<input type="number" step="0.50" />` para "Custo Unitário (R$)" no modal `isNewProductModalOpen`.
5. **Persistência do Balcão**:
   Salvar `counterSales` no `localStorage` via chave `valverds_counter_sales`.

### R4.2 — Aprimoramento da Visão do Barbeiro
1. **Grade Integral de Horários**:
   Substituir o vetor estático de 13 horários pela geração de 48 blocos (00:00 a 23:30, de 30 em 30 min) respeitando o requisito R3, além de input de horário customizado.
2. **Horários de Entrada e Saída Livres**:
   Expandir os dropdowns de `minha_escala` para permitir entrada e saída em qualquer faixa horária.

### R4.3 — Recepção & Multi-Cadeiras
1. **Seletor de Dia na Recepção**:
   Adicionar uma barra de dias da semana no topo de `receptionTab === 'agenda'`, possibilitando navegar entre Seg, Ter, Qua, Qui, Sex e Sáb.
2. **Inicialização Automática ao Criar Barbeiro**:
   Garantir que ao cadastrar um profissional, `dailyBarberSettings[novoBarberKey]` seja gerado automaticamente com jornada padrão (09:00 às 19:00).

### R4.4 — Integração Neon PostgreSQL
1. **Criação do `.env`**:
   Criar na raiz do projeto o `.env` com `DATABASE_URL`, `DATABASE_URL_POOLED` e `NEON_AUTH_BASE_URL`.
2. **Atualização do `database/schema.sql`**:
   - Incluir `'bar'` no enum de categorias de produto (`CREATE TYPE product_category_enum AS ENUM ('internal_use', 'resale', 'bar');`).
   - Adicionar tabela `appointment_items (id UUID, appointment_id UUID, item_type VARCHAR, item_name VARCHAR, price NUMERIC, cost NUMERIC)`.
   - Adicionar colunas `chair`, `avatar_url`, `instagram_handle` na tabela `barbers`.
3. **Atualização do `database/seed.sql`**:
   - Inserir Luis Valverde (60%) e Yago Barber (50%) com dados oficiais.
   - Inserir a linha completa de bar (Heineken, IPA, Corona, etc.) e pomadas reais.
4. **Scripts de Teste e Migração**:
   - Criar `database/test_connection.ps1` e `database/migrate_neon.ps1` (ou script JS em Node) para validação contínua e aplicação automatizada do esquema via HTTP SQL API do Neon sem dependência de drivers nativos pesados.

---

*Fim do Relatório de Levantamento — Valverd's BarberShop (R4).*
