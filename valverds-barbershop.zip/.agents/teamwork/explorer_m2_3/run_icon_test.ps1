. (Join-Path $PSScriptRoot "..\..\..\tests\helpers\edge_headless_runner.ps1")

$htmlPath = (Resolve-Path (Join-Path $PSScriptRoot "test_render_icons.html")).Path
$fileUri = "file:///" + $htmlPath.Replace("\", "/")

Write-Host "Dumping DOM from: $fileUri"
$dom = Invoke-EdgeDumpDom -Url $fileUri -VirtualTimeBudgetMs 2500

Write-Host "=== DOM DUMP RESULTS ==="
Write-Host "Has <svg>: " ($dom -match '<svg')
Write-Host "Has Sun circle: " ($dom -match '<circle cx="12" cy="12" r="4"')
Write-Host "Has Moon path: " ($dom -match 'M12 3a6 6 0 0 0 9 9')
Write-Host "Has custom-sun class: " ($dom -match 'class="custom-sun"')
Write-Host "Has custom-moon class: " ($dom -match 'class="custom-moon"')
Write-Host "Has Theme is dark: " ($dom -match 'Theme is dark')
Write-Host "Has React Error: " ($dom -match 'Minified React error')

if (($dom -match '<svg') -and ($dom -match 'M12 3a6 6 0 0 0 9 9') -and (-not ($dom -match 'Minified React error'))) {
    Write-Host ">>> ALL ICON CHECKS PASSED: ZERO REACT #130 ERRORS! <<<" -ForegroundColor Green
} else {
    Write-Host ">>> ICON CHECKS FAILED! <<<" -ForegroundColor Red
}
