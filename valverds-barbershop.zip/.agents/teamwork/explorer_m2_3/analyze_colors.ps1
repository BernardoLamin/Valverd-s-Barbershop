$html = [System.IO.File]::ReadAllText("C:\Users\blaminma\Downloads\valverds-barbershop\index.html")

Write-Host "=== GRAY/TEXT CLASSES ==="
[regex]::Matches($html, 'text-(gray|stone|zinc|neutral|slate)-[0-9]+') |
    Group-Object Value |
    Sort-Object Count -Descending |
    Select-Object Count, Name |
    Format-Table -AutoSize

Write-Host "=== TEXT-WHITE COUNT ==="
([regex]::Matches($html, '\btext-white\b')).Count

Write-Host "=== TEXT-BLACK COUNT ==="
([regex]::Matches($html, '\btext-black\b')).Count

Write-Host "=== BG-WHITE / BG-BLACK COUNT ==="
Write-Host "bg-black: " ([regex]::Matches($html, '\bbg-black\b')).Count
Write-Host "bg-white: " ([regex]::Matches($html, '\bbg-white\b')).Count
