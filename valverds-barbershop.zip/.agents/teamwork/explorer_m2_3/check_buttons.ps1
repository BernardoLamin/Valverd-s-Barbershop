$html = [System.IO.File]::ReadAllText("C:\Users\blaminma\Downloads\valverds-barbershop\index.html")

Write-Host "=== BUTTONS/LINKS WITH TEXT-WHITE ==="
[regex]::Matches($html, '<(button|a)[^>]*>', [System.Text.RegularExpressions.RegexOptions]::Singleline) |
    Where-Object { $_.Value -match 'text-white' } |
    ForEach-Object { $_.Value -replace '\s+', ' ' } |
    Select-Object -First 15
