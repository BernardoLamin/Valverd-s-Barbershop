# Relatório de Levantamento — Explorer Survey 2
## Valverd's BarberShop — Foco R3, Fluxo de Agendamento em 5 Passos e Privacidade do Cliente

**Data:** 2026-09-27  
**Investigador:** Survey Explorer 2  
**Escopo Autorizado:** Requisito R3 (Grade Completa de Horários 00:00 às 23:30 & Horários Customizados), Fluxo de Agendamento do Cliente (5 Etapas: Barbeiro -> Serviços + Bar -> Dia -> Horário -> Nome e WhatsApp + Toast) e Privacidade da Agenda do Cliente.

---

## 1. Sumário Executivo

A plataforma **Valverd's BarberShop** possui duas bases de código principais no repositório:
1. `index.html` (4.842 linhas): Aplicação SPA React 18 completa executada via Babel standalone no navegador, contendo todas as visões integradas (Site Público de Luxo, Painel do Dono com DRE, Agenda do Barbeiro, Painel de Recepção/Cadeiras e Portal do Cliente).
2. `src/App.jsx` (1.215 linhas): Versão anterior/paralela baseada em Vite/Lucide com formulário modal simplificado.

A análise técnica aprofundada revelou que:
- **A grade de horários atual é estática, incompleta e despadronizada:** O sistema utiliza intervalos de 45 minutos (apenas 13 a 14 slots entre 09:00 e 18:45), sem qualquer suporte aos **48 blocos de 30 em 30 minutos (00:00 às 23:30)** exigidos pelo Requisito R3.
- **Inexistência de Horários Customizados:** Não há suporte para inserção dinâmica de horários especiais/fora de grade (ex: 08:15, 19:40). Se um agendamento for criado em horário atípico, ele nem sequer é renderizado na grade comparativa de cadeiras (`barberCalendarMode === 'comparativo'`).
- **Fluxo de Agendamento do Cliente:** O fluxo de 5 passos foi implementado visualmente na aba `clientTab === 'agendar'`, mas encontra-se disposto verticalmente em um formulário único contínuo (sem navegação passo a passo guiada com stepper). Além disso, os botões "Agendar Horário" do site público ainda abrem um modal legado e simplificado (`isBookingModalOpen`), gerando inconsistência de UX.
- **Consumo do Bar no Agendamento:** O Passo 2 do agendamento restringe os itens de bar a `products.slice(0, 4)`, ignorando itens essenciais como o café espresso cortesia e águas minerais.
- **Privacidade do Cliente no Calendário:** A aba `calendario_geral` já cumpre a diretriz de privacidade mostrando apenas a contagem agregada de agendamentos e vagas livres (`X vagas livres` por barbeiro), sem expor nomes de terceiros. Recomenda-se expandir essa visualização para uma matriz horária detalhada protegida (slots marcados apenas como "Ocupado" ou "Livre").
- **Bug Detectado na Navegação:** A função `switchRole('cliente')` no `index.html` (linha 967) chama `setClientTab('agendamentos')`, mas a aba correspondente chama-se `'agendar'` ou `'meu_corte'`, resultando em uma tela em branco para o cliente até que este clique manualmente nos botões do menu.

---

## 2. Diagnóstico Detalhado da Modelagem de Horários e Escalas

### 2.1. Onde e Como os Horários Estão Modelados Hoje

| Arquivo | Linhas | Identificador / Constante | Estrutura Atual | Limitações Detectadas |
|---|---|---|---|---|
| `index.html` | 602–604 | `TIME_SLOTS_COMPARE` | Array estático de 14 strings (`'09:00'`, `'09:45'`, `'10:30'`, ..., `'18:45'`) | Intervalo de 45 min; restrito a 09:00–18:45; estático |
| `index.html` | 724–725 | `allBaseSlots` em `getAvailableSlotsForBarberAndDay` | Array de 13 strings (`'09:00'`, `'09:45'`, ..., `'18:15'`) | Intervalo de 45 min; omite 12:45; ignora horários antes das 09:00 ou após 19:00 |
| `index.html` | 2320–2371 | Tabela Comparativa de Cadeiras | Mapeia `TIME_SLOTS_COMPARE.map(slot => ...)` | Se um cliente agendar em horário customizado (ex: 08:15 ou 19:40), a linha não existe na tabela e o agendamento desaparece da visualização |
| `index.html` | 2537–2571 | Configuração Diária do Barbeiro (`dailyBarberSettings`) | `<select>` com opções fixas: Entrada (`08:30` a `11:00`), Saída (`15:00` a `20:00`) | Impede escalas matutinas (ex: 06:00, 07:00, 08:00) ou noturnas (ex: 21:00 às 23:30) |
| `index.html` | 3852–3855 | Modal Rápido de Agendamento (`isBookingModalOpen`) | Dropdown baseado em `TIME_SLOTS_COMPARE` | Não aceita horários fora dos 14 fixos nem digitação customizada |
| `index.html` | 3924 | Modal de Edição de Agendamento (`isEditApptModalOpen`) | Dropdown baseado em `TIME_SLOTS_COMPARE` | Se um agendamento tiver horário não listado, o select quebra/fica vazio |
| `src/App.jsx` | 1136–1140 | Modal de Agendamento | Array fixo com 7 horários (`['09:30', '10:30', '14:00', '15:00', '16:30', '17:30', '18:15']`) | Não representativo da operação real |
| `database/schema.sql` | 42, 99–100 | Tabela `barbers` e `appointments` | `working_hours JSONB`, `start_time TIME NOT NULL`, `end_time TIME NOT NULL` | O banco relacional suporta qualquer horário nativo via tipo `TIME`, mas o frontend grava apenas uma string única `time` no objeto `appointments` sem `end_time` |

---

## 3. Avaliação dos Requisitos R3: 48 Blocos (00:00 às 23:30) & Horários Dinâmicos Customizados

### 3.1. Especificação dos 48 Blocos de 30 Minutos

A regra matemática para os 48 blocos de 30 minutos em um ciclo de 24 horas deve ser gerada programaticamente de forma padronizada:

```javascript
// Gerador oficial dos 48 blocos de 30 em 30 minutos
const ALL_48_TIME_SLOTS = Array.from({ length: 48 }, (_, i) => {
  const h = String(Math.floor(i / 2)).padStart(2, '0');
  const m = i % 2 === 0 ? '00' : '30';
  return `${h}:${m}`;
});
// Resultado: ['00:00', '00:30', '01:00', '01:30', ..., '23:00', '23:30']
```

### 3.2. Mecanismo de Horários Dinâmicos Customizados (ex: 08:15, 19:40)

Para atender ao requisito de adição de horários personalizados sem quebrar o sistema:
1. **No Passo 4 do Agendamento do Cliente:**
   - Além dos botões dos blocos padrão disponíveis, disponibilizar um botão/campo "+ Horário Especial / Encaixe Personalizado".
   - Ao clicar, abre-se um seletor de horário ou campo formatado `HH:MM` (ex: `08:15` ou `19:40`).
   - O horário customizado é inserido diretamente no estado `clientBookingFlow.time` e destacado com badge "Horário Especial".
2. **Nos Modais de Agendamento (`isBookingModalOpen`) e Edição (`isEditApptModalOpen`):**
   - Substituir o `<select>` estático por um seletor com suporte aos 48 blocos padrão + opção "Outro Horário..." que revela campo `<input type="time">` ou texto formatado.
3. **Na Tabela Comparativa de Cadeiras (`barberCalendarMode === 'comparativo'`):**
   - Atualmente, as linhas da tabela são fixas.
   - **Solução dinâmica:** Construir a lista de slots a exibir unindo os slots ativos de trabalho com quaisquer horários customizados existentes nos agendamentos daquele dia:
     ```javascript
     const activeSlots = ALL_48_TIME_SLOTS.filter(s => s >= shopOpen && s <= shopClose);
     const dayCustomTimes = appointments
       .filter(a => a.day === selectedWeekDay && (a.weekId === currentWeek.id || currentWeek.id === 0))
       .map(a => a.time);
     const tableSlots = Array.from(new Set([...activeSlots, ...dayCustomTimes])).sort();
     ```
   - Dessa forma, se existir um agendamento às `08:15` ou `19:40`, ele automaticamente gerará uma linha intercalada cronologicamente na grade!
4. **Nas Escalas e Bloqueios do Barbeiro (`dailyBarberSettings`):**
   - Os selects de "Entrada" e "Saída" devem listar os 48 blocos ou permitir campo de entrada livre com máscara de hora, permitindo que barbeiros com turnos especiais (madrugada, eventos ou início às 07:00/08:15) sejam configurados sem limitação.

---

## 4. Avaliação do Fluxo de Agendamento do Cliente (5 Etapas)

### 4.1. Análise do Fluxo Atual (`clientTab === 'agendar'`)

O fluxo em `index.html` está estruturado nas seguintes 5 seções sequenciais (linhas 3237–3465):
1. **Passo 1 • Escolha seu Barbeiro:** Exibe cards para cada barbeiro (`Luis Valverde` e `Yago Barber`) com foto circular, cargo, cadeira e badge de seleção.
2. **Passo 2 • Serviços & Adicionais do Bar:**
   - Serviços: Grade de cards com duração, categoria, preço e descrição.
   - Adicionais do Bar: Grade de seleção múltipla com adicionais.
3. **Passo 3 • Escolha o Dia:** Botões dos dias da semana (`Seg` a `Sáb`), exibindo o número do dia e o total de vagas disponíveis (`X vagas` ou `Folga`).
4. **Passo 4 • Escolha o Horário Disponível:** Botões dos horários livres obtidos via `getAvailableSlotsForBarberAndDay`.
5. **Passo 5 • Seus Dados & Confirmação:** Inputs de Nome e WhatsApp, resumo do valor total calculado dinamicamente (serviço + extras do bar) e botão de confirmação.

### 4.2. Gaps e Deficiências Identificadas

1. **Apresentação em Formulário Contínuo vs Stepper de Alta Relojoaria:**
   - Atualmente, todos os 5 passos são renderizados simultaneamente em uma página longa de rolagem vertical.
   - Embora funcional, isso permite que o usuário desça e digite o nome e WhatsApp antes mesmo de selecionar barbeiro ou serviço, sem uma condução refinada de 1 a 5.
   - **Recomendação:** Implementar um componente de Stepper visual (`Passo 1 de 5` com barra de progresso ou botões `Avançar` / `Voltar`), ou transição progressiva elegante mantendo os 5 passos claros e com foco em cada decisão.
2. **Desconexão do CTA do Site Público:**
   - Os botões "Agendar Horário" no cabeçalho e na hero section do site chamam `setIsBookingModalOpen(true)` em vez de encaminhar o cliente para o fluxo oficial de 5 passos do portal!
   - Esse modal legado possui um formulário simples sem itens de bar, sem foto do barbeiro e preso aos 14 horários antigos.
3. **Itens do Bar Incompletos no Passo 2:**
   - Na linha 3307: `products.slice(0, 4).map(...)`. Isso força a exibição dos 4 primeiros produtos da lista (que são cervejas e whisky), omitindo o **Café Espresso Gourmet Especial (Cortesia)** e a **Água Mineral**, itens fundamentais da experiência de boas-vindas da Valverd's.
   - **Recomendação:** Filtrar `products.filter(p => p.category === 'Bar')` e exibir abas ou categorias claras (Cortesias / Bebidas / Cosméticos).
4. **Feedback e Toast de Confirmação:**
   - O toast (`clientBookingSuccessToast`) está implementado nas linhas 4822–4832, com ícone de check dourado e mensagem: *"Agendamento Confirmado! Seu horário já foi reservado na agenda do barbeiro com sucesso."*
   - O redirecionamento automático pós-toast alterna para `setClientTab('meu_corte')`, onde o cliente visualiza o resumo completo de seu atendimento agendado. Essa parte atende plenamente ao critério de aceite.

---

## 5. Avaliação da Privacidade da Agenda do Cliente

### 5.1. Estado Atual da Privacidade

O critério de aceite estabelece:
> *"O calendário geral do cliente respeita estrita privacidade, mostrando contagem de vagas sem expor nomes de outros clientes."*

**Evidências Observadas no Código:**
1. Na aba `clientTab === 'calendario_geral'` (linhas 3560–3625):
   - Há um aviso explícito de proteção de dados: `🔒 Privacidade protegida: exibimos apenas a contagem de horários disponíveis.`
   - Para cada dia da semana, exibe-se apenas a contagem total de agendamentos (`{dayAppts.length} horários agendados`).
   - Para cada barbeiro, exibe-se apenas o número de vagas livres (`{bSlots.length} vagas livres`) ou o status `Folga`.
   - **Nenhum nome, telefone, valor ou serviço de outros clientes é exposto.**
2. Na aba `clientTab === 'meu_corte'` (linhas 3470–3557):
   - Exibe exclusivamente os dados do próprio agendamento realizado pelo cliente na sessão.
3. Na aba `clientTab === 'fidelidade'` (linhas 3685–3750):
   - Exibe exclusivamente o histórico do próprio cliente autenticado.

### 5.2. Oportunidade de Refinamento (Grade Horária sem Vazamento)

Se o cliente desejar visualizar uma grade detalhada por horário dentro do calendário geral, a implementação deve adotar a seguinte matriz de privacidade:
- Slots Livres: marcados com badge verde e texto `Disponível` (permitindo clique direto para iniciar agendamento).
- Slots Ocupados: marcados com badge cinza/âmbar e texto `Reservado` ou `Ocupado` (sem renderizar `a.client`, `a.phone` ou `a.service`).
- Essa abordagem atende com rigor tanto à utilidade para o cliente quanto à total conformidade com a privacidade de dados (LGPD).

---

## 6. Gaps de Fluxo de Dados e Recomendações de Implementação

### 6.1. Resumo dos Gaps Identificados

| ID | Área | Problema Atual | Impacto | Recomendação para Implementação |
|---|---|---|---|---|
| **GAP-01** | Grade R3 | `TIME_SLOTS_COMPARE` tem apenas 14 slots de 45 min | Incompatível com o requisito R3 (48 blocos de 30 min) | Criar `ALL_48_TIME_SLOTS` com intervalo de 30 min cobrindo de `00:00` a `23:30` |
| **GAP-02** | Horários Dinâmicos | Não há input para horários como `08:15` ou `19:40` | Bloqueia encaixes e agendamentos flexíveis | Adicionar seletor/input de horário customizado no Passo 4 e nos modais |
| **GAP-03** | Tabela Comparativa | Tabela usa mapeamento estático de `TIME_SLOTS_COMPARE` | Agendamentos em horários customizados somem da tela | Unir `activeSlots` com `dayCustomTimes` ordenados cronologicamente |
| **GAP-04** | Escalas do Barbeiro | Selects de entrada/saída limitados a 6 opções cada | Não permite configurar jornadas cedo (06h/07h) ou noturnas (21h/23h30) | Utilizar os 48 blocos nos selects de entrada e saída em `dailyBarberSettings` |
| **GAP-05** | Fluxo de Agendamento | 5 passos exibidos em página contínua de rolagem | Experiência de formulário longo em vez de stepper de luxo | Adicionar navegação em abas/etapas ou transição progressiva 1→2→3→4→5 |
| **GAP-06** | Adicionais do Bar | `products.slice(0, 4)` fixo no Passo 2 | Corta cortesias (café espresso e água) e opções do cardápio do bar | Filtrar por `category === 'Bar'` e exibir opções completas |
| **GAP-07** | CTA do Site Público | Botões "Agendar Horário" abrem modal legado `isBookingModalOpen` | Bypassa o fluxo completo de 5 passos e o bar | Fazer o botão direcionar para a visão do cliente com `setClientTab('agendar')` |
| **GAP-08** | Bug no Role Switch | `switchRole('cliente')` chama `setClientTab('agendamentos')` | Tela em branco no portal do cliente ao trocar de papel | Corrigir para `setClientTab('agendar')` (linha 967 de `index.html`) |

---

## 7. Modelos de Código e Snippets Recomendados para o Implementador

### 7.1. Gerador Universal de 48 Blocos e Resolução de Horários Disponíveis

```javascript
// 1. Constante Oficial dos 48 Blocos de 30 minutos (00:00 a 23:30)
const ALL_48_TIME_SLOTS = Array.from({ length: 48 }, (_, i) => {
  const h = String(Math.floor(i / 2)).padStart(2, '0');
  const m = i % 2 === 0 ? '00' : '30';
  return `${h}:${m}`;
});

// 2. Helper aprimorado para obter slots vagos considerando jornada do barbeiro e custom times
const getAvailableSlotsForBarberAndDay = (barberKey, dayName) => {
  const barberSetting = (dailyBarberSettings[barberKey] && dailyBarberSettings[barberKey][dayName]) || { 
    available: true, 
    start: '09:00', 
    end: '19:00' 
  };
  if (!barberSetting.available) return [];

  // Filtra os 48 blocos pela jornada de trabalho configurada para o dia
  const baseSlots = ALL_48_TIME_SLOTS.filter(t => t >= barberSetting.start && t < barberSetting.end);

  // Obtém horários já reservados para o barbeiro no dia (inclusive customizados)
  const bookedTimes = appointments
    .filter(a => {
      const matchBarber = a.barberKey === barberKey || 
        (barberKey === 'luis' && a.barber && a.barber.includes('Luis')) || 
        (barberKey === 'yago' && a.barber && a.barber.includes('Yago'));
      const matchDay = a.day === dayName;
      const notCancelled = a.status !== 'cancelado' && a.status !== 'recusado';
      return matchBarber && matchDay && notCancelled;
    })
    .map(a => a.time);

  return baseSlots.filter(t => !bookedTimes.includes(t));
};
```

### 7.2. Suporte Dinâmico a Horário Personalizado no Agendamento

```javascript
// Estado auxiliar para suportar horário personalizado no formulário do cliente
const [customTimeInput, setCustomTimeInput] = useState('');
const [isCustomTimeMode, setIsCustomTimeMode] = useState(false);

// Handler para selecionar horário customizado
const handleApplyCustomTime = () => {
  if (!customTimeInput || !/^\d{2}:\d{2}$/.test(customTimeInput)) {
    alert('Por favor informe um horário válido no formato HH:MM (ex: 08:15 ou 19:40).');
    return;
  }
  setClientBookingFlow(prev => ({ ...prev, time: customTimeInput }));
  setIsCustomTimeMode(false);
};
```

---

## 8. Conclusão

A arquitetura geral do `index.html` é sólida e conta com componentes visuais de excelente nível, mas necessita da atualização matemática e funcional da grade de horários para cumprir integralmente o Requisito R3 (48 blocos de 30 min + encaixes dinâmicos) e o alinhamento da experiência de agendamento em 5 passos com stepper e integração ao Bar. A privacidade dos clientes já se encontra conceitualmente preservada no calendário geral, bastando mantê-la rigorosa durante a expansão da grade.
