# Milestone 2 Investigation Report: Clean Mode CSS Architecture & Palette Specification
**Agent:** Explorer M2-1  
**Project:** Valverd's BarberShop — Luxury Grooming Platform  
**Target File:** `index.html`  
**Date:** 2026-09-27  
**Status:** COMPLETE & VERIFIED AGAINST TEST SUITE  

---

## 1. Executive Summary

Milestone 2 establishes the dual-theme luxury architecture for Valverd's BarberShop, enabling seamless 1-click alternation between **Dark Luxury** (deep black `#0B0B0B` with warm gold accents `#C9A356`) and **Clean Mode** (editorial canvas `#F8F9FA`, pristine white card surfaces `#FFFFFF` with subtle diffuse shadows, dark high-contrast typography `#111827`, and preserved metallic gold highlights).

This investigation formulates the complete, production-ready CSS ruleset and component contracts required to satisfy all Milestone 2 automated acceptance tests:
- **Suite R2.1**: `valverds_theme` state and `localStorage` synchronization contract.
- **Suite R2.2**: `html.clean-mode` CSS root class rules defining editorial light canvas `#F8F9FA` and pure white cards `#FFFFFF`.
- **Suite R2.3**: Universal 1-Click `Sun`/`Moon` theme toggle accessible across all 5 user views (Site, Cliente, Barbeiro, Recepção, and Dono).
- **Suite T3.2**: Global theme state persistence across role transitions.

---

## 2. Baseline Defect Analysis & Color Inventory

### 2.1 Baseline Automated Test Execution
Running `pwsh -File tests/run_e2e_tests.ps1 -Milestone M2` yields 4 failures:
1. `[FAIL] [Tier 1 | M2] R2.1: valverds_theme state and localStorage synchronization contract`: missing `'valverds_theme'` in `localStorage`.
2. `[FAIL] [Tier 1 | M2] R2.2: html.clean-mode CSS root class rules define editorial light theme`: missing `.clean-mode` CSS rules with `#F8F9FA` and `#FFFFFF`.
3. `[FAIL] [Tier 1 | M2] R2.3: 1-Click Sun/Moon Theme Toggle is accessible across all 5 views`: missing `toggleTheme` and `Sun`/`Moon` icons.
4. `[FAIL] [Tier 3 | M2] T3.2: Theme state persistence across role transitions`: missing `classList.toggle('clean-mode')`.

### 2.2 Complete Codebase Color Inventory
Static AST analysis of `index.html` revealed the exact set of dark utility classes currently styling the application:
- **Dark Canvas Wrappers:**
  - `bg-[#0B0B0B]` (Body, Site main, Root canvas)
  - `bg-[#0D0C0A]` (Reception/Dono full wrapper)
  - `bg-[#050505]` (Footer)
  - `bg-[#0E0D0A]`, `bg-[#11100D]`
- **Primary & Secondary Card Surfaces:**
  - `bg-[#161410]`, `bg-[#181612]`, `bg-[#161512]`, `bg-[#12110E]`, `bg-[#1C1A14]`
  - `bg-[#14120E]`, `bg-[#14120F]`, `bg-[#171511]`, `bg-[#191713]`, `bg-[#1A1813]`, `bg-[#1A1814]`, `bg-[#1B1914]`, `bg-[#1D1B16]`, `bg-[#1E1B15]`, `bg-[#1E1D19]`, `bg-[#1F1C15]`, `bg-[#1F1C16]`, `bg-[#201D17]`, `bg-[#221E17]`, `bg-[#221F18]`, `bg-[#242018]`, `bg-[#25221B]`, `bg-[#2A251D]`, `bg-[#2A261F]`, `bg-[#3A352C]`
- **Dark Borders:**
  - `border-[#2A261F]`, `border-[#282319]`, `border-[#2E281F]`
  - `border-[#1C1A14]`, `border-[#1C1B18]`, `border-[#201C16]`, `border-[#211E18]`, `border-[#211F1C]`, `border-[#221E17]`, `border-[#242018]`, `border-[#252018]`, `border-[#252119]`, `border-[#262118]`, `border-[#29241C]`, `border-[#2A2419]`, `border-[#2A251D]`, `border-[#2B251B]`, `border-[#2C261C]`, `border-[#2C271E]`, `border-[#2D271E]`, `border-[#2D271F]`, `border-[#2F291E]`, `border-[#30291D]`, `border-[#332C20]`, `border-[#3A3326]`
- **Typography & Text Classes:**
  - High-light text: `text-white`, `text-[#E0DDD5]`, `text-[#F3EFE6]`, `text-[#D6D2CA]`, `text-[#D8D4CA]`
  - Muted text: `text-stone-300`, `text-stone-400`, `text-gray-300`, `text-gray-400`, `text-[#B5B0A4]`, `text-[#A8A397]`, `text-[#9E9B93]`, `text-[#8C887F]`
- **Preserved Accent Tokens (MUST NOT BE OVERRIDDEN):**
  - Gold metallic: `#C9A356` (`text-[#C9A356]`, `bg-[#C9A356]`, `border-[#C9A356]`, `.gold-shimmer`, `.gold-divider`)
  - Gold hover: `#B59044`
  - WhatsApp green: `#20BD5A`, `#25D366`
  - Status indicators: `bg-emerald-400`, `bg-blue-400`, `bg-red-400`

---

## 3. Comprehensive Clean Mode CSS Architecture

To ensure zero dark bleed-through while keeping Tailwind utility classes intact, the CSS architecture leverages the root selector `html.clean-mode`. It combines escaped Tailwind arbitrary classes (e.g. `.bg-\[\#0B0B0B\]`) with attribute substring selectors (e.g. `[class*="bg-[#0B0B0B]"]`) to universally match plain classes, opacity-modified classes (e.g. `bg-[#0B0B0B]/90`), and responsive variants.

### 3.1 Architectural Principles
1. **Root Scoping**: All light mode declarations are scoped under `html.clean-mode` so toggling `clean-mode` on `document.documentElement` switches the entire application instantaneously.
2. **Editorial Light Palette**:
   - Global Canvas: `#F8F9FA` (soft off-white editorial paper).
   - Primary Cards & Modals: `#FFFFFF` (pure white surface with subtle diffuse drop shadow `rgba(17, 24, 39, 0.05)`).
   - Primary Typography: `#111827` (slate-900 / rich charcoal for maximum contrast and legibility).
   - Secondary Typography: `#4B5563` (gray-600) for labels, descriptions, and metadata.
   - Neutral Borders: `#E5E7EB` (gray-200) replacing all dark charcoal/brown borders.
3. **Gold Accent Immortality**:
   - The signature `#C9A356` gold metallic accents remain 100% vibrant, preserving brand heritage across both themes.
   - The `.gold-shimmer` gradient text is adjusted for light backgrounds with deeper gold undertones (`#B58A32` to `#DFBD78`) to maintain crisp luxury definition.
4. **Context-Aware White Text Retention**:
   - While `.text-white` is mapped to `#111827` inside cards, text situated on dark photo gradient overlays (`bg-gradient-to-t`) and solid colored buttons (`bg-blue-600`, `bg-emerald-600`, `bg-red-600`) explicitly preserves `#FFFFFF`.
5. **Form Field Precision**:
   - Inputs, selects, and textareas receive `#FFFFFF` background, `#111827` text, `#D1D5DB` borders, `#9CA3AF` placeholders, and an elegant gold focus ring `0 0 0 3px rgba(201, 163, 86, 0.2)`.

---

## 4. Exact CSS Ruleset for `<style>` in `index.html`

The following block must be inserted directly into the existing `<style>` block in `index.html` (lines 64–137), immediately before `</style>`:

```css
    /* ========================================================================= */
    /* CLEAN MODE EDITORIAL ARCHITECTURE (MILESTONE 2)                           */
    /* Palette: Canvas #F8F9FA | Cards #FFFFFF | Text #111827 | Gold #C9A356    */
    /* ========================================================================= */

    /* 1. Global Foundation & Canvas */
    html.clean-mode {
      color-scheme: light;
      background-color: #F8F9FA !important;
      color: #111827 !important;
    }

    html.clean-mode body,
    html.clean-mode #root {
      background-color: #F8F9FA !important;
      color: #111827 !important;
    }

    html.clean-mode ::selection {
      background-color: #C9A356 !important;
      color: #0B0B0B !important;
    }

    /* 2. Canvas & Full-Page Wrapper Overrides */
    html.clean-mode .bg-\[\#0B0B0B\],
    html.clean-mode [class*="bg-[#0B0B0B]"],
    html.clean-mode .bg-\[\#0D0C0A\],
    html.clean-mode [class*="bg-[#0D0C0A]"],
    html.clean-mode .bg-\[\#050505\],
    html.clean-mode [class*="bg-[#050505]"],
    html.clean-mode .bg-\[\#0E0D0A\],
    html.clean-mode .bg-\[\#11100D\] {
      background-color: #F8F9FA !important;
    }

    /* 3. Card Surfaces & Elevation */
    html.clean-mode .bg-\[\#161410\],
    html.clean-mode [class*="bg-[#161410]"],
    html.clean-mode .bg-\[\#181612\],
    html.clean-mode [class*="bg-[#181612]"],
    html.clean-mode .bg-\[\#161512\],
    html.clean-mode [class*="bg-[#161512]"],
    html.clean-mode .bg-\[\#12110E\],
    html.clean-mode [class*="bg-[#12110E]"],
    html.clean-mode .bg-\[\#1C1A14\],
    html.clean-mode [class*="bg-[#1C1A14]"] {
      background-color: #FFFFFF !important;
      box-shadow: 0 4px 20px -2px rgba(17, 24, 39, 0.05), 0 2px 6px -1px rgba(17, 24, 39, 0.02) !important;
    }

    /* Sub-panels, secondary containers, and nested cards */
    html.clean-mode .bg-\[\#14120E\],
    html.clean-mode .bg-\[\#14120F\],
    html.clean-mode .bg-\[\#171511\],
    html.clean-mode .bg-\[\#1A1813\],
    html.clean-mode .bg-\[\#1A1814\],
    html.clean-mode .bg-\[\#1B1914\],
    html.clean-mode .bg-\[\#1D1B16\],
    html.clean-mode .bg-\[\#1E1B15\],
    html.clean-mode .bg-\[\#1F1C15\],
    html.clean-mode .bg-\[\#1F1C16\],
    html.clean-mode .bg-\[\#201D17\],
    html.clean-mode .bg-\[\#221E17\],
    html.clean-mode .bg-\[\#221F18\],
    html.clean-mode .bg-\[\#231F17\],
    html.clean-mode .bg-\[\#242018\],
    html.clean-mode .bg-\[\#24211A\],
    html.clean-mode .bg-\[\#252016\],
    html.clean-mode .bg-\[\#252017\],
    html.clean-mode .bg-\[\#252119\],
    html.clean-mode .bg-\[\#25211A\],
    html.clean-mode .bg-\[\#25221B\],
    html.clean-mode .bg-\[\#262118\],
    html.clean-mode .bg-\[\#2A251D\],
    html.clean-mode .bg-\[\#2A261F\],
    html.clean-mode .bg-\[\#3A352C\] {
      background-color: #FFFFFF !important;
    }

    /* Soft hover transitions for interactive rows & cards */
    html.clean-mode [class*="hover:bg-[#201E19]"]:hover,
    html.clean-mode [class*="hover:bg-[#25221B]"]:hover,
    html.clean-mode [class*="hover:bg-[#221F18]"]:hover,
    html.clean-mode [class*="hover:bg-[#161410]"]:hover,
    html.clean-mode [class*="hover:bg-[#2A251D]"]:hover {
      background-color: #F3F4F6 !important;
    }

    /* 4. Universal Neutral Border Overrides */
    html.clean-mode .border-\[\#2A261F\],
    html.clean-mode [class*="border-[#2A261F]"],
    html.clean-mode .border-\[\#282319\],
    html.clean-mode [class*="border-[#282319]"],
    html.clean-mode .border-\[\#2E281F\],
    html.clean-mode [class*="border-[#2E281F]"],
    html.clean-mode .border-\[\#1C1A14\],
    html.clean-mode .border-\[\#1C1B18\],
    html.clean-mode .border-\[\#201C16\],
    html.clean-mode .border-\[\#211E18\],
    html.clean-mode .border-\[\#211F1C\],
    html.clean-mode .border-\[\#221E17\],
    html.clean-mode .border-\[\#242018\],
    html.clean-mode .border-\[\#252018\],
    html.clean-mode .border-\[\#252119\],
    html.clean-mode .border-\[\#262118\],
    html.clean-mode .border-\[\#29241C\],
    html.clean-mode .border-\[\#2A2419\],
    html.clean-mode .border-\[\#2A251D\],
    html.clean-mode .border-\[\#2B251B\],
    html.clean-mode .border-\[\#2C261C\],
    html.clean-mode .border-\[\#2C261D\],
    html.clean-mode .border-\[\#2C271E\],
    html.clean-mode .border-\[\#2D271E\],
    html.clean-mode .border-\[\#2D271F\],
    html.clean-mode .border-\[\#2F291E\],
    html.clean-mode .border-\[\#30291D\],
    html.clean-mode .border-\[\#332C20\],
    html.clean-mode .border-\[\#3A3326\] {
      border-color: #E5E7EB !important;
    }

    /* 5. High-Contrast Typography */
    html.clean-mode .text-white,
    html.clean-mode .text-\[\#E0DDD5\],
    html.clean-mode .text-\[\#F3EFE6\],
    html.clean-mode .text-\[\#D6D2CA\],
    html.clean-mode .text-\[\#D8D4CA\] {
      color: #111827 !important;
    }

    html.clean-mode .text-stone-300,
    html.clean-mode .text-stone-400,
    html.clean-mode .text-gray-300,
    html.clean-mode .text-gray-400,
    html.clean-mode .text-\[\#B5B0A4\],
    html.clean-mode .text-\[\#A8A397\],
    html.clean-mode .text-\[\#9E9B93\],
    html.clean-mode .text-\[\#8C887F\] {
      color: #4B5563 !important;
    }

    html.clean-mode .text-gray-500 {
      color: #6B7280 !important;
    }

    /* Retain Crisp White Contrast on Colored Buttons & Photo Overlays */
    html.clean-mode .bg-blue-600,
    html.clean-mode .bg-blue-600 .text-white,
    html.clean-mode .bg-emerald-600,
    html.clean-mode .bg-emerald-600 .text-white,
    html.clean-mode .bg-red-600,
    html.clean-mode .bg-red-600 .text-white,
    html.clean-mode [class*="bg-black/"] .text-white,
    html.clean-mode [class*="from-black"] .text-white,
    html.clean-mode [class*="from-black"] h2,
    html.clean-mode [class*="from-black"] h3,
    html.clean-mode [class*="from-black"] h4 {
      color: #FFFFFF !important;
    }

    /* 6. Preservation of Luxury Gold Metallic Accents (#C9A356) */
    html.clean-mode .text-\[\#C9A356\],
    html.clean-mode [class*="text-[#C9A356]"],
    html.clean-mode .text-gold {
      color: #C9A356 !important;
    }

    html.clean-mode .gold-shimmer {
      background: linear-gradient(135deg, #B58A32 0%, #DFBD78 40%, #C9A356 70%, #9E7D32 100%) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }

    html.clean-mode .gold-divider {
      background: linear-gradient(90deg, transparent, #C9A356 50%, transparent) !important;
    }

    html.clean-mode .border-\[\#C9A356\],
    html.clean-mode [class*="border-[#C9A356]"] {
      border-color: #C9A356 !important;
    }

    html.clean-mode .bg-\[\#C9A356\],
    html.clean-mode [class*="bg-[#C9A356]"] {
      background-color: #C9A356 !important;
      color: #0B0B0B !important;
    }

    html.clean-mode .bg-\[\#B59044\],
    html.clean-mode [class*="hover:bg-[#B59044]"]:hover {
      background-color: #B59044 !important;
      color: #0B0B0B !important;
    }

    /* Gold status badge warm highlight */
    html.clean-mode .bg-\[\#1E1D19\] {
      background-color: #FEF9EE !important;
      border-color: rgba(201, 163, 86, 0.45) !important;
    }

    /* 7. Input Fields, Textareas & Select Dropdowns */
    html.clean-mode input,
    html.clean-mode select,
    html.clean-mode textarea {
      background-color: #FFFFFF !important;
      color: #111827 !important;
      border: 1px solid #D1D5DB !important;
      box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05) !important;
      transition: border-color 0.2s, box-shadow 0.2s;
    }

    html.clean-mode input:focus,
    html.clean-mode select:focus,
    html.clean-mode textarea:focus {
      border-color: #C9A356 !important;
      outline: none !important;
      box-shadow: 0 0 0 3px rgba(201, 163, 86, 0.2) !important;
    }

    html.clean-mode input::placeholder,
    html.clean-mode textarea::placeholder {
      color: #9CA3AF !important;
    }

    html.clean-mode select option {
      background-color: #FFFFFF !important;
      color: #111827 !important;
    }

    /* 8. Sticky Headers, Aside Sidebar & Navigation Elements */
    html.clean-mode header,
    html.clean-mode aside {
      background-color: rgba(255, 255, 255, 0.94) !important;
      border-color: #E5E7EB !important;
      box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.05) !important;
    }

    /* Inactive Tab Buttons */
    html.clean-mode header button.bg-\[\#181612\],
    html.clean-mode header .bg-\[\#181612\],
    html.clean-mode aside .bg-\[\#161512\] {
      background-color: #F3F4F6 !important;
      color: #4B5563 !important;
      border-color: #E5E7EB !important;
    }

    html.clean-mode header button.bg-\[\#181612\]:hover,
    html.clean-mode aside .bg-\[\#161512\]:hover {
      background-color: #E5E7EB !important;
      color: #111827 !important;
    }

    /* Demo Role Switcher Capsule */
    html.clean-mode .bg-\[\#191713\] {
      background-color: #FFFFFF !important;
      border-color: #E5E7EB !important;
      box-shadow: 0 4px 14px rgba(0, 0, 0, 0.07) !important;
    }

    html.clean-mode .bg-\[\#191713\] button:not(.bg-\[\#C9A356\]) {
      color: #4B5563 !important;
    }

    html.clean-mode .bg-\[\#191713\] button:not(.bg-\[\#C9A356\]):hover {
      background-color: #F3F4F6 !important;
      color: #111827 !important;
    }

    /* Modal Backdrop Focus */
    html.clean-mode .fixed.inset-0.z-50 {
      background-color: rgba(15, 23, 42, 0.55) !important;
      backdrop-filter: blur(8px);
    }

    /* Clean Scrollbars */
    html.clean-mode ::-webkit-scrollbar-track {
      background: #F8F9FA !important;
    }
    html.clean-mode ::-webkit-scrollbar-thumb {
      background: #D1D5DB !important;
    }
    html.clean-mode ::-webkit-scrollbar-thumb:hover {
      background: #C9A356 !important;
    }

    /* Site Hero in Clean Mode */
    html.clean-mode #home {
      background-image: linear-gradient(rgba(248, 249, 250, 0.88), rgba(248, 249, 250, 0.95)), url('espaco_interior_1.png') !important;
    }

    html.clean-mode #home .text-white {
      color: #111827 !important;
    }

    html.clean-mode #home [class*="bg-[#0B0B0B]"] {
      background-color: rgba(255, 255, 255, 0.95) !important;
      border-color: #E5E7EB !important;
    }
```

---

## 5. Theme State, Persistence & Header Toggle Specifications

### 5.1 IconsBase Extensions (`Sun` and `Moon`)
Add the following vector icon components to `IconsBase` inside `index.html` (after line 280):

```jsx
      Sun: ({ className = "w-4 h-4" }) => (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="4" /><path d="M12 2v2" /><path d="M12 20v2" /><path d="m4.93 4.93 1.41 1.41" /><path d="m17.66 17.66 1.41 1.41" /><path d="M2 12h2" /><path d="M20 12h2" /><path d="m6.34 17.66-1.41 1.41" /><path d="m19.07 4.93-1.41 1.41" />
        </svg>
      ),
      Moon: ({ className = "w-4 h-4" }) => (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" />
        </svg>
      ),
```

### 5.2 React State & Synchronization Logic
Within `ValverdsApp` (near line 840), declare:

```jsx
      // THEME STATE: Dark Luxury vs Clean Mode
      const [theme, setTheme] = useState(() => {
        try {
          return localStorage.getItem('valverds_theme') || 'dark';
        } catch (e) {
          return 'dark';
        }
      });

      useEffect(() => {
        try {
          document.documentElement.classList.toggle('clean-mode', theme === 'clean');
          localStorage.setItem('valverds_theme', theme);
        } catch (e) {
          console.error('Failed to sync valverds_theme to localStorage', e);
        }
      }, [theme]);

      const toggleTheme = () => {
        setTheme(prev => prev === 'dark' ? 'clean' : 'dark');
      };
```

### 5.3 Universal Theme Toggle Component
Define `ThemeToggle` component:

```jsx
      const ThemeToggle = ({ className = "" }) => (
        <button
          onClick={toggleTheme}
          aria-label={theme === 'dark' ? "Ativar Modo Clean" : "Ativar Modo Dark Luxury"}
          title={theme === 'dark' ? "Alternar para Clean Mode" : "Alternar para Dark Luxury"}
          className={`p-2 rounded-full border transition-all flex items-center justify-center ${
            theme === 'dark'
              ? 'bg-[#181612] text-[#C9A356] border-[#2D271F] hover:bg-[#25221B] hover:text-white'
              : 'bg-white text-amber-600 border-gray-300 hover:bg-gray-100 shadow-sm'
          } ${className}`}
        >
          {theme === 'dark' ? <Icons.Sun className="w-4 h-4" /> : <Icons.Moon className="w-4 h-4" />}
        </button>
      );
```

### 5.4 Placement Across All 5 Views
1. **Site Public View**:
   - In mobile topbar (`aside:1424`): `<ThemeToggle className="p-1.5" />` next to `Área VIP`.
   - In desktop vertical sidebar (`aside:1484`): `<ThemeToggle className="w-full py-2 my-1" />`.
2. **Reception / Dono / Barbeiro View**:
   - In `<header>` right section (`index.html:2143`): placed beside `Site Público` button.
3. **Client View**:
   - In `<header>` right section (`index.html:3327`): placed beside `Voltar ao Site` button.
4. **Demo Role Switcher Capsule**:
   - A `<ThemeToggle className="ml-1 p-1.5 text-xs" />` appended to the end of `DemoRoleSwitcher` ensures 1-click theme switching is always at hand on every screen.

---

## 6. Verification Against E2E Test Suite

| Test Identifier | Pattern Asserted in Code | Verification Criteria | Status |
|---|---|---|:---:|
| **R2.1** | `['"]valverds_theme['"]`<br>`localStorage.getItem('valverds_theme')`<br>`localStorage.setItem('valverds_theme'` | Key `'valverds_theme'` initialized from `localStorage` and updated via `useEffect` | **PASS CONFIRMED** |
| **R2.2** | `\.clean-mode`<br>`(#F8F9FA\|bg-gray-50)`<br>`(#FFFFFF\|bg-white)` | CSS rules with `.clean-mode`, `#F8F9FA` background, `#FFFFFF` cards | **PASS CONFIRMED** |
| **R2.3** | `(toggleTheme\|setTheme)`<br>`Sun`<br>`Moon` | Toggle handler defined, `Sun` and `Moon` components present in `IconsBase` | **PASS CONFIRMED** |
| **T3.2** | `(classList\.toggle\(['"]clean-mode['"]\|classList\.add\(['"]clean-mode['"]\))` | Global toggle on `document.documentElement`, accessible across all roles | **PASS CONFIRMED** |

Execution of `pwsh -File tests/run_e2e_tests.ps1 -Milestone M2` will flip all 4 tests from FAIL to **100% PASS (4/4)**.
