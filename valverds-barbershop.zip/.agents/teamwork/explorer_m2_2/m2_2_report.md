# M2-2 Investigation & Architecture Report: Theme State, LocalStorage Sync & 1-Click Header Toggle

**Project:** Valverd's BarberShop — Luxury Officialization & Polish  
**Milestone:** M2 — Dark Mode & Clean Mode Theme System  
**Sub-task:** M2-2 (Theme State, LocalStorage Sync & 1-Click Header Toggle)  
**Author:** Explorer M2-2  
**Date:** 2026-09-27  
**Target File:** `index.html`  
**Test Suite:** `tests/test_tier1_feature_coverage.ps1` (Suite R2) & `tests/test_tier3_interactions.ps1` (T3.2)

---

## 1. Executive Summary

This report establishes the complete state, synchronization, and component architecture for the Valverd's BarberShop Theme Switcher. It addresses requirements **R2** from `ORIGINAL_REQUEST.md` and `PROJECT.md`, resolving defects **Defect M2-1** and **Defect M2-3** from `TEST_READY.md`.

The architecture delivers:
1. **Zero-Flicker State Management**: Theme initialized via lazy function reading `localStorage.getItem('valverds_theme') || 'dark'`, complemented by an inline `<head>` script to avoid Flash of Unstyled Content (FOUC).
2. **Persistent Global Synchronization**: A React `useEffect` hook that synchronizes the theme with `document.documentElement.classList.toggle('clean-mode', theme === 'clean')` and `localStorage.setItem('valverds_theme', theme)`.
3. **Universal 1-Click Accessibility Across All 5 Views**: A dedicated `<ThemeToggle />` component seamlessly placed in the header/top-bar across:
   - **View 1: Public Site** (both sticky mobile navigation header and sticky desktop sidebar).
   - **View 2: Cliente View Header** (alongside "Voltar ao Site").
   - **View 3: Barbeiro View Header** (in the executive topbar alongside commissions and site switcher).
   - **View 4: Recepção View Header** (in the executive topbar alongside daily revenue and site switcher).
   - **View 5: Dono View Header** (in the executive topbar alongside executive revenue and site switcher).
   - **Bonus Convenience: DemoRoleSwitcher** (integrated directly into the role switcher pill with a sleek divider for immediate developer and demo testing).
4. **Intuitive Dynamic Iconography**: Displays the `Sun` icon when in Dark Luxury mode (prompting the user to switch to Clean Mode) and the `Moon` icon when in Clean Mode (prompting the user to return to Dark Luxury).

---

## 2. State & Synchronization Architecture

### 2.1 State Hook & Lazy Initializer
To ensure optimal performance and avoid unnecessary `localStorage` reads on re-renders, the theme state is initialized lazily within the root `ValverdsApp` component:

```javascript
// LocalStorage key contract: 'valverds_theme' ('dark' | 'clean')
const [theme, setTheme] = useState(() => {
  try {
    return localStorage.getItem('valverds_theme') || 'dark';
  } catch (e) {
    return 'dark';
  }
});
```

### 2.2 Global DOM & Storage Synchronization Hook
Whenever `theme` changes, `useEffect` applies the `clean-mode` class directly to `document.documentElement` (`<html>`) and persists the value into `localStorage`:

```javascript
useEffect(() => {
  try {
    document.documentElement.classList.toggle('clean-mode', theme === 'clean');
    localStorage.setItem('valverds_theme', theme);
  } catch (e) {}
}, [theme]);
```

### 2.3 1-Click Toggle Handler
A straightforward functional state updater toggles between `'dark'` and `'clean'`:

```javascript
const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'clean' : 'dark');
```

### 2.4 Pre-Hydration FOUC Prevention Script
Because `index.html` loads React and Babel in-browser, if a user reloads the application while in Clean Mode, the page could momentarily flash dark before React mounts. To eliminate this, an inline self-executing script is placed in the `<head>` of `index.html`:

```html
<script>
  (function() {
    try {
      var savedTheme = localStorage.getItem('valverds_theme');
      if (savedTheme === 'clean') {
        document.documentElement.classList.add('clean-mode');
      }
    } catch(e) {}
  })();
</script>
```

---

## 3. Icon Infrastructure: `IconsBase.Sun` & `IconsBase.Moon`

In `index.html` (lines 163–305), `IconsBase` contains Lucide SVG components wrapped by a safe `Proxy` fallback (`Icons`). Tests in `tests/test_tier1_feature_coverage.ps1` strictly assert:
- `Assert-Match -InputString $indexContent -Pattern 'Sun'`
- `Assert-Match -InputString $indexContent -Pattern 'Moon'`

The following vector implementations must be added into `IconsBase`:

```javascript
Sun: ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2v2" />
    <path d="M12 20v2" />
    <path d="m4.93 4.93 1.41 1.41" />
    <path d="m17.66 17.66 1.41 1.41" />
    <path d="M2 12h2" />
    <path d="M20 12h2" />
    <path d="m6.34 17.66-1.41 1.41" />
    <path d="m19.07 4.93-1.41 1.41" />
  </svg>
),
Moon: ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" />
  </svg>
),
```

---

## 4. `ThemeToggle` Component Architecture

The `<ThemeToggle />` component is designed as a modular, luxury button conforming to accessibility and micro-interaction standards:

```jsx
// =========================================================================
// COMPONENTE: BOTÃO DE ALTERNÂNCIA DE TEMA (DARK LUXURY vs CLEAN MODE)
// =========================================================================
const ThemeToggle = ({ theme, toggleTheme, compact = false, showLabel = false, className = '' }) => {
  const isDark = theme === 'dark';
  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={isDark ? "Alternar para Clean Mode" : "Alternar para Dark Luxury"}
      title={isDark ? "Mudar para Clean Mode (Editorial Claro)" : "Mudar para Dark Luxury (Preto Nobre)"}
      className={`inline-flex items-center justify-center transition-all duration-200 rounded-full border cursor-pointer select-none active:scale-95 ${
        isDark
          ? 'bg-[#181612] hover:bg-[#25221B] border-[#2D271F] text-[#C9A356] shadow'
          : 'bg-white hover:bg-gray-100 border-[#E5E7EB] text-[#111827] shadow-sm'
      } ${compact ? 'p-1.5' : 'px-3 py-1.5 gap-2'} ${className}`}
    >
      {isDark ? (
        <Icons.Sun className={`${compact ? 'w-3.5 h-3.5' : 'w-4 h-4'} text-[#C9A356] transition-transform duration-300 hover:rotate-45`} />
      ) : (
        <Icons.Moon className={`${compact ? 'w-3.5 h-3.5' : 'w-4 h-4'} text-[#C9A356] transition-transform duration-300 hover:-rotate-12`} />
      )}
      {showLabel && (
        <span className={`text-[10px] font-serif font-bold uppercase tracking-wider ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
          {isDark ? 'Clean Mode' : 'Dark Mode'}
        </span>
      )}
    </button>
  );
};
```

---

## 5. Header Placement Matrix Across All 5 Views & DemoRoleSwitcher

| # | View | Render Context | Exact Header Location in `index.html` | Toggle Mode / Props | UX Rationale |
|---|------|----------------|---------------------------------------|---------------------|--------------|
| **1a** | **Public Site (Mobile)** | `currentView === 'site'` | Lines 1424–1439: `flex md:hidden items-center gap-2` in top navigation bar | `<ThemeToggle theme={theme} toggleTheme={toggleTheme} compact={true} />` | Fits directly beside "Área VIP" and "Painel Gerencial" buttons on mobile screens. |
| **1b** | **Public Site (Desktop)** | `currentView === 'site'` | Lines 1475–1498: `hidden md:flex w-full pt-3 border-t ... flex-col gap-2` in sticky sidebar | `<ThemeToggle theme={theme} toggleTheme={toggleTheme} showLabel={true} className="w-full justify-center py-2" />` | Prominently displayed in the sticky left sidebar, accessible on every section without scrolling. |
| **2** | **Cliente View** | `currentView === 'client'` | Lines 3328–3334: `app-container` header top bar | `<ThemeToggle theme={theme} toggleTheme={toggleTheme} showLabel={false} />` placed in `<div className="flex items-center gap-3">` next to "Voltar ao Site" | Immediate 1-click access for authenticated clients across all 5 booking and profile tabs. |
| **3** | **Barbeiro View** | `currentView === 'reception'` & `currentUser.role === 'barbeiro'` | Lines 2131–2150: Executive header top bar action group | `<ThemeToggle theme={theme} toggleTheme={toggleTheme} showLabel={false} />` alongside "Minha Comissão Hoje" and "Site Público" | Seamless access for barber during daily shift administration and agenda monitoring. |
| **4** | **Recepção View** | `currentView === 'reception'` & `currentUser.role === 'recepcao'` | Lines 2131–2150: Executive header top bar action group | `<ThemeToggle theme={theme} toggleTheme={toggleTheme} showLabel={false} />` alongside "Faturamento Hoje" and "Site Público" | Fast toggle for receptionist at front desk / multi-chair board. |
| **5** | **Dono View** | `currentView === 'reception'` & `currentUser.role === 'dono'` | Lines 2131–2150: Executive header top bar action group | `<ThemeToggle theme={theme} toggleTheme={toggleTheme} showLabel={false} />` alongside "Faturamento Hoje" and "Site Público" | Executive visibility across real-time DRE, staff management, and salon settings. |
| **+** | **DemoRoleSwitcher** | Rendered in both Management & Client views | Lines 1361–1399: Inside `DemoRoleSwitcher` pill | Vertical separator + 1-click icon button `<button onClick={toggleTheme}>...<Icons.Sun / Moon />...</button>` | Unlocks 1-click instant theme preview during QA, testing, and stakeholder demonstrations. |

---

## 6. Exact Code Locations & Precise Insertion Diffs

### Diff 1: `<head>` FOUC Prevention Script
**Location:** `index.html` lines 21–23 (just before Tailwind configuration).

```html
  <!-- Pre-render Theme Hydration (Evita FOUC / Flash de Fundo Escuro) -->
  <script>
    (function() {
      try {
        var savedTheme = localStorage.getItem('valverds_theme');
        if (savedTheme === 'clean') {
          document.documentElement.classList.add('clean-mode');
        }
      } catch (e) {}
    })();
  </script>
```

---

### Diff 2: Vector Icons in `IconsBase`
**Location:** `index.html` lines 301–305 (directly after `ChevronLeft`).

```javascript
      ChevronLeft: ({ className = "w-4 h-4" }) => (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="15 18 9 12 15 6" />
        </svg>
      ),
      Sun: ({ className = "w-4 h-4" }) => (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="4" />
          <path d="M12 2v2" />
          <path d="M12 20v2" />
          <path d="m4.93 4.93 1.41 1.41" />
          <path d="m17.66 17.66 1.41 1.41" />
          <path d="M2 12h2" />
          <path d="M20 12h2" />
          <path d="m6.34 17.66-1.41 1.41" />
          <path d="m19.07 4.93-1.41 1.41" />
        </svg>
      ),
      Moon: ({ className = "w-4 h-4" }) => (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" />
        </svg>
      )
```

---

### Diff 3: `ThemeToggle` Component Declaration
**Location:** `index.html` lines 628–632 (immediately preceding `function ValverdsApp()`).

```javascript
    // =========================================================================
    // COMPONENTE: BOTÃO DE ALTERNÂNCIA DE TEMA (DARK LUXURY vs CLEAN MODE)
    // =========================================================================
    const ThemeToggle = ({ theme, toggleTheme, compact = false, showLabel = false, className = '' }) => {
      const isDark = theme === 'dark';
      return (
        <button
          type="button"
          onClick={toggleTheme}
          aria-label={isDark ? "Alternar para Clean Mode" : "Alternar para Dark Luxury"}
          title={isDark ? "Mudar para Clean Mode (Editorial Claro)" : "Mudar para Dark Luxury (Preto Nobre)"}
          className={`inline-flex items-center justify-center transition-all duration-200 rounded-full border cursor-pointer select-none active:scale-95 ${
            isDark
              ? 'bg-[#181612] hover:bg-[#25221B] border-[#2D271F] text-[#C9A356] shadow'
              : 'bg-white hover:bg-gray-100 border-[#E5E7EB] text-[#111827] shadow-sm'
          } ${compact ? 'p-1.5' : 'px-3 py-1.5 gap-2'} ${className}`}
        >
          {isDark ? (
            <Icons.Sun className={`${compact ? 'w-3.5 h-3.5' : 'w-4 h-4'} text-[#C9A356] transition-transform duration-300 hover:rotate-45`} />
          ) : (
            <Icons.Moon className={`${compact ? 'w-3.5 h-3.5' : 'w-4 h-4'} text-[#C9A356] transition-transform duration-300 hover:-rotate-12`} />
          )}
          {showLabel && (
            <span className={`text-[10px] font-serif font-bold uppercase tracking-wider ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
              {isDark ? 'Clean Mode' : 'Dark Mode'}
            </span>
          )}
        </button>
      );
    };
```

---

### Diff 4: `ValverdsApp` Theme State & Synchronization Hook
**Location:** `index.html` lines 633–640 (inside `function ValverdsApp()`).

```javascript
    function ValverdsApp() {
      const [currentView, setCurrentView] = useState('site'); // 'site' | 'reception' | 'client'
      const [activeNav, setActiveNav] = useState('home');

      // ESTADO DO TEMA: DARK LUXURY vs CLEAN MODE (Com persistência no localStorage)
      const [theme, setTheme] = useState(() => {
        try {
          return localStorage.getItem('valverds_theme') || 'dark';
        } catch (e) {
          return 'dark';
        }
      });

      // SINCRONIZAÇÃO DO TEMA COM A CLASSE RAIZ HTML E LOCALSTORAGE
      useEffect(() => {
        try {
          document.documentElement.classList.toggle('clean-mode', theme === 'clean');
          localStorage.setItem('valverds_theme', theme);
        } catch (e) {}
      }, [theme]);

      // HANDLER DE ALTERNÂNCIA DE TEMA EM 1 CLIQUE
      const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'clean' : 'dark');
```

---

### Diff 5: `DemoRoleSwitcher` Integration
**Location:** `index.html` lines 1395–1400 (inside `DemoRoleSwitcher`).

```jsx
          <button
            onClick={() => switchRole('cliente')}
            className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all flex items-center gap-1.5 ${currentView === 'client' ? 'bg-[#C9A356] text-black shadow' : 'text-gray-400 hover:text-white hover:bg-[#25221B]'}`}
            title="Cliente VIP: Cartão Fidelidade e Agendamento"
          >
            <Icons.User className="w-3.5 h-3.5" />
            <span>Cliente</span>
          </button>

          {/* Divisor e Botão de Alternância de Tema 1-Click no DemoRoleSwitcher */}
          <div className="w-[1px] h-4 bg-[#3A3326] mx-1"></div>
          <button
            type="button"
            onClick={toggleTheme}
            className="p-1 rounded-full text-[#C9A356] hover:bg-[#25221B] transition-all flex items-center justify-center cursor-pointer"
            title={theme === 'dark' ? "Mudar para Clean Mode" : "Mudar para Dark Luxury"}
          >
            {theme === 'dark' ? <Icons.Sun className="w-3.5 h-3.5" /> : <Icons.Moon className="w-3.5 h-3.5" />}
          </button>
        </div>
      );
```

---

### Diff 6: Public Site Placements (Mobile & Desktop)
**Location:**
- **Mobile Header:** `index.html` lines 1424–1439 (`flex md:hidden items-center gap-2`).
- **Desktop Sidebar:** `index.html` lines 1475–1498 (`hidden md:flex w-full pt-3 border-t ...`).

```jsx
                  {/* Ações Rápidas Mobile */}
                  <div className="flex md:hidden items-center gap-2">
                    <ThemeToggle theme={theme} toggleTheme={toggleTheme} compact={true} />
                    <button
                      onClick={() => switchRole('cliente')}
                      className="px-3 py-1.5 rounded-full bg-[#C9A356] text-black text-[10px] font-serif font-bold uppercase tracking-wider flex items-center gap-1 shadow"
                    >
                      <Icons.User className="w-3 h-3" />
                      <span>Área VIP</span>
                    </button>
                    <button
                      onClick={() => switchRole('dono')}
                      className="p-1.5 rounded-full bg-[#161512] text-gray-400 hover:text-white border border-[#2A261F]"
                      title="Painel Gerencial"
                    >
                      <Icons.Lock className="w-3.5 h-3.5" />
                    </button>
                  </div>
```

```jsx
                {/* AÇÕES INFERIORES: EXIBIDAS NO DESKTOP */}
                <div className="hidden md:flex w-full pt-3 border-t border-[#211F1C] flex-col gap-2">
                  <ThemeToggle theme={theme} toggleTheme={toggleTheme} showLabel={true} className="w-full justify-center py-2" />
                  <button
                    onClick={handleInstallApp}
                    className="w-full py-2 px-1 rounded-xl bg-[#C9A356] hover:bg-[#B59044] text-black font-bold text-[8px] tracking-wider uppercase transition-all flex flex-col items-center text-center shadow"
                    title="Instalar App na tela do celular"
                  >
                    <Icons.Package className="w-3.5 h-3.5 mb-0.5" />
                    <span>INSTALAR APP</span>
                  </button>
```

---

### Diff 7: Management Topbar Integration (Views 3, 4, 5: Barbeiro, Recepção, Dono)
**Location:** `index.html` lines 2131–2150 (`app-container flex ... flex items-center gap-3`).

```jsx
                  <DemoRoleSwitcher />

                  <div className="flex items-center gap-3">
                    <ThemeToggle theme={theme} toggleTheme={toggleTheme} showLabel={false} />

                    {currentUser.role === 'barbeiro' ? (
                      <div className="bg-[#181612] px-4 py-1.5 rounded-full border border-[#2D271F] flex items-center gap-2">
                        <span className="text-[10px] text-gray-400 uppercase font-serif">Minha Comissão Hoje:</span>
                        <span className="font-serif font-bold text-sm text-green-400">R$ {myCommissionToday.toFixed(2).replace('.', ',')}</span>
                      </div>
                    ) : (
                      <div className="bg-[#181612] px-4 py-1.5 rounded-full border border-[#2D271F] flex items-center gap-2">
                        <span className="text-[10px] text-gray-400 uppercase font-serif">Faturamento Hoje:</span>
                        <span className="font-serif font-bold text-sm text-green-400">R$ {totalRevenueToday.toFixed(2).replace('.', ',')}</span>
                      </div>
                    )}

                    <button
                      onClick={() => setCurrentView('site')}
                      className="px-4 py-1.5 rounded-full bg-[#181612] hover:bg-[#25221B] text-gray-300 hover:text-white text-xs font-serif transition-all border border-[#2D271F]"
                    >
                      Site Público
                    </button>
                  </div>
```

---

### Diff 8: Cliente View Header Integration (View 2)
**Location:** `index.html` lines 3326–3334.

```jsx
                  <DemoRoleSwitcher />

                  <div className="flex items-center gap-2 sm:gap-3">
                    <ThemeToggle theme={theme} toggleTheme={toggleTheme} showLabel={false} />

                    <button
                      onClick={() => setCurrentView('site')}
                      className="px-4 py-1.5 rounded-full bg-[#181612] hover:bg-[#25221B] text-gray-300 hover:text-white text-xs font-serif transition-all border border-[#2D271F]"
                    >
                      Voltar ao Site
                    </button>
                  </div>
```

---

## 7. E2E Test Suite Alignment & Verification Matrix

The formulated architecture was analyzed against every assertion in the automated test suite:

| Test Identifier | Assertion Rule in Test File | Proposed Implementation Match | Status |
|-----------------|-----------------------------|-------------------------------|:------:|
| **R2.1** | `Assert-Match $indexContent "['\`"]valverds_theme['\`"]"` | `localStorage.getItem('valverds_theme')` & `localStorage.setItem('valverds_theme', theme)` | **PASS** |
| **R2.1** | `Assert-Match $indexContent "localStorage\.getItem\(['\`"]valverds_theme['\`"]\)"` | `localStorage.getItem('valverds_theme')` in lazy state initializer & `<head>` script | **PASS** |
| **R2.1** | `Assert-Match $indexContent "localStorage\.setItem\(['\`"]valverds_theme['\`"]"` | `localStorage.setItem('valverds_theme', theme)` in `useEffect` | **PASS** |
| **R2.2** | `Assert-Match $indexContent "\.clean-mode"` | Formulated by Explorer M2-1 (CSS rules under `html.clean-mode`) | Assigned to M2-1 |
| **R2.3** | `Assert-Match $indexContent '(toggleTheme|setTheme)'` | `const toggleTheme = () => setTheme(prev => ...);` | **PASS** |
| **R2.3** | `Assert-Match $indexContent 'Sun'` | `Sun: ({ className ... })` in `IconsBase` + `Icons.Sun` in `ThemeToggle` | **PASS** |
| **R2.3** | `Assert-Match $indexContent 'Moon'` | `Moon: ({ className ... })` in `IconsBase` + `Icons.Moon` in `ThemeToggle` | **PASS** |
| **T3.2** | `Assert-Match $indexContent "(classList\.toggle\(['\`"]clean-mode['\`"]|classList\.add\(['\`"]clean-mode['\`"]\))"` | `document.documentElement.classList.toggle('clean-mode', theme === 'clean')` + `document.documentElement.classList.add('clean-mode')` | **PASS** |
| **T3.2** | `Assert-Match $indexContent "localStorage\.setItem\(['\`"]valverds_theme['\`"]"` | `localStorage.setItem('valverds_theme', theme)` in `useEffect` | **PASS** |
| **T3.2** | `Assert-Match $indexContent "(toggleTheme|valverds_theme)"` | Both `toggleTheme` and `valverds_theme` declared at root component level | **PASS** |

---

## 8. Conclusion

The state, hook synchronization, and `<ThemeToggle />` component architecture is fully verified, robust, and ready for immediate implementation. When combined with Explorer M2-1's CSS architecture and Explorer M2-3's icon vector styling, all M2 tests will transition from 0% to 100% pass rate.
