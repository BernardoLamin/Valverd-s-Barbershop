## 2026-09-27T19:34:12Z

<USER_REQUEST>
You are Explorer M2-2 for Milestone 2 (Theme State, LocalStorage Sync & 1-Click Header Toggle).
Working directory: C:\Users\blaminma\Downloads\valverds-barbershop\.agents\teamwork\explorer_m2_2
Project root: C:\Users\blaminma\Downloads\valverds-barbershop
Target file: C:\Users\blaminma\Downloads\valverds-barbershop\index.html
Requirements: C:\Users\blaminma\Downloads\valverds-barbershop\.agents\teamwork\ORIGINAL_REQUEST.md
Project plan: C:\Users\blaminma\Downloads\valverds-barbershop\.agents\teamwork\PROJECT.md
Test suite guide: C:\Users\blaminma\Downloads\valverds-barbershop\TEST_READY.md

Instructions:
1. Read ORIGINAL_REQUEST.md, PROJECT.md, and TEST_READY.md.
2. Formulate the state and component architecture for the theme switcher:
   - State hook: `const [theme, setTheme] = useState(() => localStorage.getItem('valverds_theme') || 'dark');`
   - Synchronization hook: `useEffect` to toggle `document.documentElement.classList.toggle('clean-mode', theme === 'clean')` and `localStorage.setItem('valverds_theme', theme)`.
   - Toggle handler: `const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'clean' : 'dark');`
   - Component placement: 1-click toggle button visible in the header/top-bar across ALL 5 views:
     1. Public Site: In top mobile header and desktop sidebar/header.
     2. Cliente view header.
     3. Barbeiro view header.
     4. Recepção view header.
     5. Dono view header.
     (Also consider placing in DemoRoleSwitcher for developer/demo convenience).
   - Dynamic icon: displays `Sun` when in dark mode (click to switch to Clean Mode) and `Moon` when in clean mode (click to switch to Dark Luxury).
3. Check against `tests/test_tier1_feature_coverage.ps1` Suite R2 tests.
4. Specify exact code locations, JSX snippets, and props.
5. Write your report in C:\Users\blaminma\Downloads\valverds-barbershop\.agents\teamwork\explorer_m2_2\m2_2_report.md and produce a structured handoff.md. Send a message when finished.
</USER_REQUEST>
