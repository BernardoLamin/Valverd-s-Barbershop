# Relatório de Auditoria & Especificação Técnica — Explorer M1-1
**Projeto:** Valverd's BarberShop — Sistema Web de Gestão & Agendamento  
**Milestone:** M1 — Luxury Visual Polish & Responsiveness  
**Investigador:** Explorer M1-1 (Tipografia, Acabamento de Luxo & Responsividade Mobile)  
**Data:** 2026-09-27  
**Arquivo Alvo Principal:** `C:\Users\blaminma\Downloads\valverds-barbershop\index.html` (4.842 linhas)

---

## 1. Sumário Executivo

A plataforma **Valverd's BarberShop** tem como base estética o universo da alta alfaiataria e barbearia clássica internacional (padrão Mayfair / Savile Row / Manhattan). Possui ativos fotográficos de alta resolução reais do espaço em Resende/RJ (fundado em 2022) e uma paleta sólida de Dark Luxury com base em `#0B0B0B` e ouro nobre `#C9A356`.

Entretanto, nossa auditoria aprofundada identificou **6 grandes gargalos de acabamento e responsividade** que impedem o site de alcançar o patamar de produto oficial:

1. **Navegação Mobile Quebrada (Crítico):** Na linha 1379, `<nav>` aloca 9 botões com ícones e rótulos verticais (`HOME`, `SOBRE`, `ESPAÇO`, `CORTES`, `SERVIÇOS`, `BAR`, `PRODUTOS`, `EQUIPE`, `RESENDE`) dentro de uma linha flex horizontal compartilhada com a Logo e com a coluna de ações. Em celulares (375px a 414px), cada botão recebe apenas ~21px de largura, comprimindo e sobrepondo textos e ícones. Além disso, a coluna de ações inferiores (`INSTALAR APP`, `ÁREA CLIENTE`, `GESTÃO / LOGIN`) disputa espaço horizontalmente no topo da tela mobile.
2. **Desconexão do Layout Widescreen (`max-w-[1440px]`):** No Site Público (linhas 1370-1445), o `<aside>` utiliza `md:fixed md:left-0` e o `<main>` usa `md:ml-[140px]`. Em monitores widescreen (1920px, 2560px ultrawide, 4K), a sidebar fica presa ao canto extremo esquerdo do monitor (pixel 0), enquanto o conteúdo central se afasta centenas de pixels, quebrando o alinhamento da grade de 1440px.
3. **Potencial Dourado e Sombras Inativos (Zero Usos):** No arquivo `index.html`, a classe `.gold-shimmer` (gradiente metálico ouro) está definida na linha 108 mas possui **0 ocorrências** no JSX. As sombras de luxo `'gold-glow'` e `'card-luxury'` estão configuradas no Tailwind (linhas 51-52), mas possuem **0 ocorrências** no JSX.
4. **Animações e Micro-Interações Ausentes ou Quebradas:** A classe `animate-fade-in` é invocada no toast de agendamento (linha 4823), porém **não está declarada** no `<style>` nem no Tailwind (animação fantasma). Os modais surgem de forma abrupta sem transição de escala/opacidade (`animate-modal`).
5. **Caracteres Brutos de Texto no Lugar de Ícones Vetoriais:** Setas de carrossel usam caracteres ASCII `‹` e `›` (linhas 1574-1575); a paginação semanal usa `<` e `>` (linhas 2146, 2153); botões de fechar modal usam o glifo unicode `✕` (linhas 3773, 3902, 3988, 4084, 4735). Todos devem ser substituídos por ícones SVG do sistema Lucide (`Icons.ChevronLeft`, `Icons.ChevronRight`, `Icons.X`).
6. **Espaçamento Tipográfico em Títulos ("Hacks" de Espaços):** Títulos principais usam caracteres manuais como `S O B R E - N Ó S` e `C O R T E S &nbsp; & &nbsp; T R A B A L H O S`. Devem ser padronizados com letter spacing nativo CSS (`tracking-[0.25em]`).

Este relatório fornece a análise minuciosa e a especificação exata de cada linha de código necessária para que o **Worker M1** execute a transformação com precisão cirúrgica.

---

## 2. Auditoria de Tipografia (Cinzel, Playfair Display & Plus Jakarta Sans)

### 2.1. Configuração Atual
- **Importação Google Fonts (`index.html`, linhas 18-20):**
  - `Cinzel` (400, 500, 600, 700, 800, 900) — Classic Roman / Vintage Barber Serif.
  - `Playfair Display` (500, 600, 700, 800, 900, itálicos) — Editorial Elegance.
  - `Plus Jakarta Sans` (300, 400, 500, 600, 700, 800) — Modern Executive Sans-Serif.
- **Tailwind Font Families (linhas 28-32):**
  - `serif`: `['Cinzel', 'Playfair Display', 'Georgia', 'serif']`
  - `sans`: `['Plus Jakarta Sans', '-apple-system', 'sans-serif']`
  - `display`: `['Playfair Display', 'Cinzel', 'serif']`

### 2.2. Diretrizes de Uso Padrão Luxo Internacional

| Elemento | Família Tipográfica | Classes Tailwind Recomendadas | Efeito Visual |
| :--- | :--- | :--- | :--- |
| **Título Principal Hero** | `font-serif` (Cinzel) | `text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-[0.15em] uppercase gold-shimmer` | Imponente, metálico, relojoeiro |
| **Subtítulo Hero** | `font-serif` (Cinzel Italic) | `text-base sm:text-xl font-serif italic text-[#C9A356] tracking-widest` | Elegância de alfaiataria italiana |
| **Lema da Marca** | `font-serif` | `text-xs sm:text-sm text-[#C9A356] font-bold tracking-widest uppercase` | Distinção e prestígio |
| **Títulos de Seção** | `font-serif` (Cinzel) | `text-2xl sm:text-3xl md:text-4xl font-bold tracking-[0.25em] uppercase text-white` | Editorial limpo sem espaçamento manual |
| **Rótulos de Categoria / Badges** | `font-serif` (Cinzel) | `text-[9px] sm:text-[10px] uppercase tracking-[0.25em] font-bold text-[#C9A356]` | Badge de manufatura suíça |
| **Valores Monetários & Preços** | `font-serif` (Cinzel) | `font-serif font-bold text-[#C9A356] tracking-wider` | Destaque monetário de alto valor |
| **Corpo de Texto & Descrições** | `font-sans` (Plus Jakarta) | `font-sans text-xs sm:text-sm text-[#A8A397] leading-relaxed antialiased` | Leitura fluida, moderna e sem cansaço |
| **Inputs e Formulários** | `font-sans` | `font-sans text-xs text-white placeholder-gray-500` | Ergonomia operacional limpa |

### 2.3. Eliminação dos Hacks de Espaçamento Manual
Substituir os títulos com espaços literais entre letras por classes com `tracking-[0.25em]`:
- Linha 1523: `S O B R E - N Ó S` ➔ `SOBRE NÓS` com `tracking-[0.25em]`
- Linha 1556: `E S P A Ç O` ➔ `ESPAÇO` com `tracking-[0.25em]`
- Linha 1620: `C O R T E S &nbsp; & &nbsp; T R A B A L H O S` ➔ `CORTES & TRABALHOS` com `tracking-[0.25em]`
- Linha 1661: `N O S S O S &nbsp; S E R V I Ç O S` ➔ `NOSSOS SERVIÇOS` com `tracking-[0.25em]`
- Linha 1736: `B E B I D A S &nbsp; & &nbsp; B A R` ➔ `BEBIDAS & BAR` com `tracking-[0.25em]`
- Linha 1829: `N O S S A &nbsp; E Q U I P E` ➔ `NOSSA EQUIPE` com `tracking-[0.25em]`

*Benefício:* Leitura de tela acessível (Screen Readers não soletram letra por letra) e renderização tipográfica tipicamente editorial de revistas de luxo.

---

## 3. Acabamentos Metálicos Dourados (`#C9A356`) & Sistema de Cor

### 3.1. Diagnóstico do Uso Atual
O inventário revelou:
- `text-[#C9A356]`: 169 ocorrências
- `bg-[#C9A356]`: 92 ocorrências
- `border-[#C9A356]`: 60 ocorrências
- `gold-shimmer`: **0 usos**
- `shadow-gold-glow`: **0 usos**

### 3.2. Aprimoramento da Classe `.gold-shimmer`
Na linha 108 de `index.html`, refinar a fórmula do gradiente para conferir profundidade de metal nobre escovado:

```css
/* Gradiente metálico de ouro nobre escovado */
.gold-shimmer {
  background: linear-gradient(135deg, #C9A356 0%, #F5E0AA 40%, #C9A356 70%, #9E7D32 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  display: inline-block;
}
```

### 3.3. Introdução do Elemento `.gold-divider`
Para conferir o aspecto de alta joalheria sob os títulos de seções, introduzir no `<style>`:

```css
.gold-divider {
  height: 1px;
  background: linear-gradient(90deg, transparent, #C9A356 50%, transparent);
  margin: 1rem auto 1.5rem auto;
  width: 96px;
}
```

### 3.4. Aplicação de `shadow-gold-glow`
Aplicar `hover:shadow-gold-glow` nos botões principais de agendamento e destaques:
- Botão Hero "Agende Seu Horário" (linha 1475):
  `px-8 py-3.5 bg-[#C9A356] hover:bg-[#B59044] text-[#0B0B0B] font-serif text-xs font-bold uppercase tracking-widest rounded-xl shadow-xl hover:shadow-gold-glow transition-all hover:scale-[1.02] active:scale-95`
- Card Mais Pedido ("Barba + Cabelo", linha 1683):
  Adicionar `hover:shadow-gold-glow` à borda dourada existente.
- Botão Flutuante de Agendamento (linha 1941):
  Adicionar `hover:shadow-gold-glow`.

---

## 4. Estética de Cartões & Sistema de Elevação

### 4.1. Camadas de Superfície no Dark Luxury
A arquitetura de elevação deve seguir um contraste límpido de 4 níveis:
1. **Canvas Global:** `#0B0B0B` (Preto Absoluto / Fundo de Sala)
2. **Superfície Secundária:** `#12110E` (Paineis, Headers e Seções Alternadas)
3. **Cartões de Conteúdo:** `#161410` / `#161512` com bordas `#2A261F` e cantos `rounded-2xl` / `rounded-3xl`
4. **Pílulas & Badges de Destaque:** `#1C1A14` / `#1F1C15` com bordas `#C9A356`/30

### 4.2. Aplicação da Sombra de Luxo (`shadow-card-luxury`)
Aplicar a classe `shadow-card-luxury` (definida no Tailwind na linha 52: `0 8px 32px 0 rgba(0, 0, 0, 0.45)`):
- Nos cards de cortes do portfólio (linha 1629): `hover:shadow-card-luxury hover:border-[#C9A356]/60 transition-all duration-300`
- Nos cards dos barbeiros (linha 1835): `hover:shadow-card-luxury hover:border-[#C9A356]/60 transition-all duration-300`
- No modal de agendamento (linha 3767): `shadow-card-luxury border border-[#C9A356]/30`

---

## 5. Micro-Interações & Sistema de Animações

### 5.1. Correção de `animate-fade-in` e Criação de `animate-modal`
Adicionar ao `<style>` de `index.html` (por volta da linha 112):

```css
/* Animações de Luxo */
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(6px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes modalFadeIn {
  from { opacity: 0; transform: scale(0.96) translateY(10px); }
  to { opacity: 1; transform: scale(1) translateY(0); }
}

.animate-fade-in {
  animation: fadeIn 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards;
}

.animate-modal {
  animation: modalFadeIn 0.25s cubic-bezier(0.16, 1, 0.3, 1) forwards;
}
```

### 5.2. Substituição Obrigatória de Glifos ASCII/Unicode por Ícones Lucide

1. **Setas do Carrossel de Fotos (Linhas 1574-1575):**
   - *Antes:*
     ```html
     <button onClick={prevSlide} className="w-9 h-9 rounded-full bg-black/60 hover:bg-[#C9A356] hover:text-black text-white flex items-center justify-center transition-all">‹</button>
     <button onClick={nextSlide} className="w-9 h-9 rounded-full bg-black/60 hover:bg-[#C9A356] hover:text-black text-white flex items-center justify-center transition-all">›</button>
     ```
   - *Depois:*
     ```html
     <button onClick={prevSlide} aria-label="Foto anterior" className="w-9 h-9 rounded-full bg-black/70 hover:bg-[#C9A356] hover:text-black text-white border border-white/10 flex items-center justify-center transition-all shadow-lg active:scale-90">
       <Icons.ChevronLeft className="w-4 h-4" />
     </button>
     <button onClick={nextSlide} aria-label="Próxima foto" className="w-9 h-9 rounded-full bg-black/70 hover:bg-[#C9A356] hover:text-black text-white border border-white/10 flex items-center justify-center transition-all shadow-lg active:scale-90">
       <Icons.ChevronRight className="w-4 h-4" />
     </button>
     ```

2. **Paginação Semanal do Calendário Geral (Linhas 2146 e 2153):**
   - *Antes:* `<span><</span><span>Semana Anterior</span>` e `<span>Próxima Semana</span><span>></span>`
   - *Depois:*
     ```html
     <button onClick={handlePrevWeek} className="...">
       <Icons.ChevronLeft className="w-4 h-4" />
       <span>Semana Anterior</span>
     </button>
     ...
     <button onClick={handleNextWeek} className="...">
       <span>Próxima Semana</span>
       <Icons.ChevronRight className="w-4 h-4" />
     </button>
     ```

3. **Botões de Fechamento de Modais (Linhas 3773, 3902, 3988, 4084, 4735):**
   - *Antes:* `<button onClick={...} className="text-gray-400 hover:text-white text-xl">✕</button>`
   - *Depois:*
     ```html
     <button onClick={...} aria-label="Fechar" className="p-1.5 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-colors">
       <Icons.X className="w-5 h-5" />
     </button>
     ```

4. **Entrada Suave dos Modais:**
   - Adicionar a classe `animate-modal` no container interno de todos os modais (linhas 3767, 3896, 3982, 4078, 4729).

---

## 6. Travamento de Responsividade `max-w-[1440px]` & Overflow-X

### 6.1. Diagnóstico do Problema de Layout Widescreen
No Site Público (`currentView === 'site'`, linhas 1370-1445):
```html
<div className="flex flex-col md:flex-row min-h-screen">
  <aside className="w-full md:w-[140px] md:fixed md:inset-y-0 md:left-0 ...">
  <main className="flex-1 md:ml-[140px] bg-[#0B0B0B] min-h-screen ...">
```
Em telas > 1440px:
- `md:fixed md:left-0` ancora a barra lateral à borda esquerda física da tela (pixel 0).
- Se a tela tiver 2560px, o container principal centralizado com `max-w-6xl mx-auto` fica posicionado a mais de 500px de distância da sidebar, quebrando a harmonia visual.

### 6.2. Solução Arquitetural de Alta Precisão
Converter a sidebar desktop para `md:sticky md:top-0 md:h-screen md:shrink-0` e envelopar o layout em um container delimitado por `max-w-[1440px] mx-auto w-full relative`:

```html
{/* CONTAINER PRINCIPAL TRAVADO EM 1440PX */}
<div className="flex flex-col md:flex-row min-h-screen max-w-[1440px] mx-auto w-full relative">
  {/* SIDEBAR ADAPTATIVA */}
  <aside className="w-full md:w-[140px] md:sticky md:top-0 md:h-screen md:shrink-0 sticky top-0 bg-[#0B0B0B]/95 md:bg-[#0B0B0B] border-b md:border-b-0 md:border-r border-[#211F1C] z-40 flex flex-col justify-between p-3 md:py-6 text-white shadow-2xl backdrop-blur-md">
    ...
  </aside>
  {/* CONTEÚDO PRINCIPAL (sem necessidade de margin-left forçado) */}
  <main className="flex-1 min-w-0 bg-[#0B0B0B] min-h-screen text-[#E0DDD5]">
    ...
  </main>
</div>
```

*Resultado:*
- Em telas gigantes (1920px, 2560px, 4K), o site fica centrado em 1440px com fundo preto profundo uniforme nas laterais, mantendo a barra de navegação exatamente encostada no conteúdo.
- Em telas médias (laptops de 1366px ou 1440px), ocupa 100% da tela perfeitamente.
- Em tablets e celulares, colapsa para a navegação mobile fluida no topo.

### 6.3. Auditoria de Transbordo Horizontal (`overflow-x: hidden`)
- `html, body` já possuem `overflow-x: hidden;` (linha 73).
- `#root` já possui `overflow-x: hidden;` (linha 86).
- A tabela de ocupação das cadeiras (`TIME_SLOTS_COMPARE`, linha 2310) já possui `overflow-x-auto`.
- A barra de abas de Barbeiro/Recepção (linha 2003) e do Cliente (linha 3186) já utilizam `overflow-x-auto no-scrollbar`.
- O único ponto de risco residual de overflow horizontal identificado era a barra de 9 itens mobile no site público, resolvida a seguir.

---

## 7. Análise Forense & Solução da Navegação Mobile

### 7.1. Causa-Raiz do Problema Atual (Linhas 1373-1442)
Na implementação atual:
```html
<aside className="w-full md:w-[140px] md:fixed md:inset-y-0 md:left-0 bg-[#0B0B0B] border-r border-[#211F1C] z-40 flex md:flex-col items-center justify-between p-3 md:py-6 text-white shadow-2xl">
  <div className="flex flex-col items-center text-center cursor-pointer mb-3" onClick={() => scrollToSection('home')}>
    <OfficialLogo className="w-16 h-16" />
    <span className="text-[8px] font-serif tracking-[0.25em] text-[#C9A356] mt-1 font-bold">EST. 2022</span>
  </div>

  <nav className="w-full flex md:flex-col items-center justify-around md:justify-center gap-1 md:gap-2 py-1">
    {/* 9 BOTÕES COM ÍCONE E TEXTO VERTICAL */}
  </nav>

  <div className="w-full pt-3 border-t border-[#211F1C] flex flex-col gap-2">
    {/* 3 BOTÕES: INSTALAR APP, ÁREA CLIENTE, GESTÃO / LOGIN */}
  </div>
</aside>
```

**Comportamento em Telas Mobile (< 768px):**
1. O elemento `<aside>` possui classe `flex md:flex-col`. Em mobile, `flex` assume direção horizontal (`flex-direction: row`).
2. Existem 3 filhos diretos na mesma linha horizontal:
   - Filho 1: Logo e EST. 2022 (~70px)
   - Filho 2: `<nav>` com 9 botões
   - Filho 3: `<div>` com os 3 botões verticais de ação (`w-full flex flex-col`)
3. Em uma tela de celular de 375px:
   - Sobram menos de 200px para o `<nav>`.
   - 200px dividido por 9 botões = **22px por botão**!
   - Cada botão possui ícone e texto vertical como `SERVIÇOS` e `PRODUTOS`. As palavras quebram em várias linhas, letras colidem e os botões se esmagam mutuamente.
4. O terceiro filho (`INSTALAR APP`, `ÁREA CLIENTE`, `GESTÃO / LOGIN`) fica empilhado em uma minúscula coluna lateral espremida, com borda cortada.

### 7.2. Especificação da Nova Navegação Mobile & Desktop
A nova estrutura deve operar em duas camadas elegantes no mobile, sem alterar o funcionamento vertical desktop:

#### A. Camada Superior Mobile:
- Lado esquerdo: Logo compacta (`w-10 h-10`), "VALVERD'S" e "EST. 2022".
- Lado direito: Botão de acesso rápido "Cliente VIP" e atalho para o painel de gestão.
- Desktop: Logo centralizada com `w-16 h-16` e `EST. 2022`.

#### B. Camada de Navegação com Scroll Horizontal (`overflow-x-auto no-scrollbar`):
- No mobile: fita deslizante horizontal suave contendo os 9 itens, com ícone e texto dispostos lado a lado (`flex-row`), `shrink-0`, padding ergonômico (`px-3 py-1.5`), cantos arredondados (`rounded-full`), e sem quebra de texto (`whitespace-nowrap`).
- No desktop: menu vertical tradicional (`md:flex-col md:w-full`) perfeitamente distribuído.

#### C. Ações Inferiores:
- No mobile: `hidden md:flex`, não poluindo a tela (o acesso ao cliente e gestão já está na barra superior e no rodapé do site).
- No desktop: mantidas no rodapé da barra lateral com `w-full flex flex-col gap-2`.

---

## 8. Especificação de Código Linha a Linha para o Worker M1

### 8.1. Edição no `<style>` (`index.html`, Linhas 105-113)

**Substituição Proposta:**

```html
<<<<<<< TARGET (Linhas 108-113)
    .gold-shimmer {
      background: linear-gradient(135deg, #C9A356 0%, #F5E0AA 50%, #B59044 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
  </style>
=======
    /* Gradiente metálico de ouro nobre com profundidade */
    .gold-shimmer {
      background: linear-gradient(135deg, #C9A356 0%, #F5E0AA 40%, #C9A356 70%, #9E7D32 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      display: inline-block;
    }
    /* Divisor editorial de luxo */
    .gold-divider {
      height: 1px;
      background: linear-gradient(90deg, transparent, #C9A356 50%, transparent);
      margin: 1rem auto 1.5rem auto;
      width: 96px;
    }
    /* Animações fluidas de luxo */
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(6px); }
      to { opacity: 1; transform: translateY(0); }
    }
    @keyframes modalFadeIn {
      from { opacity: 0; transform: scale(0.96) translateY(10px); }
      to { opacity: 1; transform: scale(1) translateY(0); }
    }
    .animate-fade-in {
      animation: fadeIn 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }
    .animate-modal {
      animation: modalFadeIn 0.25s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }
  </style>
>>>>>>>
```

---

### 8.2. Edição da Navegação do Site Público (`index.html`, Linhas 1370-1445)

**Substituição Proposta:**

```html
<<<<<<< TARGET (Linhas 1370-1445)
          {currentView === 'site' && (
            <div className="flex flex-col md:flex-row min-h-screen">
              
              {/* SIDEBAR VERTICAL ESQUERDA REFINADA */}
              <aside className="w-full md:w-[140px] md:fixed md:inset-y-0 md:left-0 bg-[#0B0B0B] border-r border-[#211F1C] z-40 flex md:flex-col items-center justify-between p-3 md:py-6 text-white shadow-2xl">
                <div className="flex flex-col items-center text-center cursor-pointer mb-3" onClick={() => scrollToSection('home')}>
                  <OfficialLogo className="w-16 h-16" />
                  <span className="text-[8px] font-serif tracking-[0.25em] text-[#C9A356] mt-1 font-bold">EST. 2022</span>
                </div>

                <nav className="w-full flex md:flex-col items-center justify-around md:justify-center gap-1 md:gap-2 py-1">
                  <button onClick={() => scrollToSection('home')} className={`flex flex-col items-center justify-center p-2 rounded-xl w-full transition-all ${activeNav === 'home' ? 'text-[#C9A356] bg-[#161410] border border-[#2A2419]' : 'text-gray-400 hover:text-[#C9A356] hover:bg-[#161410]/50'}`}>
                    <Icons.Home className="w-4 h-4 mb-1" />
                    <span className="text-[8px] font-serif tracking-widest uppercase font-bold">HOME</span>
                  </button>
                  <button onClick={() => scrollToSection('sobre-nos')} className={`flex flex-col items-center justify-center p-2 rounded-xl w-full transition-all ${activeNav === 'sobre-nos' ? 'text-[#C9A356] bg-[#161410] border border-[#2A2419]' : 'text-gray-400 hover:text-[#C9A356] hover:bg-[#161410]/50'}`}>
                    <Icons.Info className="w-4 h-4 mb-1" />
                    <span className="text-[8px] font-serif tracking-widest uppercase font-bold">SOBRE</span>
                  </button>
                  <button onClick={() => scrollToSection('espaco')} className={`flex flex-col items-center justify-center p-2 rounded-xl w-full transition-all ${activeNav === 'espaco' ? 'text-[#C9A356] bg-[#161410] border border-[#2A2419]' : 'text-gray-400 hover:text-[#C9A356] hover:bg-[#161410]/50'}`}>
                    <Icons.Camera className="w-4 h-4 mb-1" />
                    <span className="text-[8px] font-serif tracking-widest uppercase font-bold">ESPAÇO</span>
                  </button>
                  <button onClick={() => scrollToSection('cortes')} className={`flex flex-col items-center justify-center p-2 rounded-xl w-full transition-all ${activeNav === 'cortes' ? 'text-[#C9A356] bg-[#161410] border border-[#2A2419]' : 'text-gray-400 hover:text-[#C9A356] hover:bg-[#161410]/50'}`}>
                    <Icons.Scissors className="w-4 h-4 mb-1" />
                    <span className="text-[8px] font-serif tracking-widest uppercase font-bold">CORTES</span>
                  </button>
                  <button onClick={() => scrollToSection('servicos')} className={`flex flex-col items-center justify-center p-2 rounded-xl w-full transition-all ${activeNav === 'servicos' ? 'text-[#C9A356] bg-[#161410] border border-[#2A2419]' : 'text-gray-400 hover:text-[#C9A356] hover:bg-[#161410]/50'}`}>
                    <Icons.Award className="w-4 h-4 mb-1" />
                    <span className="text-[8px] font-serif tracking-widest uppercase font-bold">SERVIÇOS</span>
                  </button>
                  <button onClick={() => scrollToSection('bebidas')} className={`flex flex-col items-center justify-center p-2 rounded-xl w-full transition-all ${activeNav === 'bebidas' ? 'text-[#C9A356] bg-[#161410] border border-[#2A2419]' : 'text-gray-400 hover:text-[#C9A356] hover:bg-[#161410]/50'}`}>
                    <Icons.Wine className="w-4 h-4 mb-1" />
                    <span className="text-[8px] font-serif tracking-widest uppercase font-bold">BAR</span>
                  </button>
                  <button onClick={() => scrollToSection('produtos')} className={`flex flex-col items-center justify-center p-2 rounded-xl w-full transition-all ${activeNav === 'produtos' ? 'text-[#C9A356] bg-[#161410] border border-[#2A2419]' : 'text-gray-400 hover:text-[#C9A356] hover:bg-[#161410]/50'}`}>
                    <Icons.Package className="w-4 h-4 mb-1" />
                    <span className="text-[8px] font-serif tracking-widest uppercase font-bold">PRODUTOS</span>
                  </button>
                  <button onClick={() => scrollToSection('barbeiros')} className={`flex flex-col items-center justify-center p-2 rounded-xl w-full transition-all ${activeNav === 'barbeiros' ? 'text-[#C9A356] bg-[#161410] border border-[#2A2419]' : 'text-gray-400 hover:text-[#C9A356] hover:bg-[#161410]/50'}`}>
                    <Icons.Users className="w-4 h-4 mb-1" />
                    <span className="text-[8px] font-serif tracking-widest uppercase font-bold">EQUIPE</span>
                  </button>
                  <button onClick={() => scrollToSection('localizacao')} className={`flex flex-col items-center justify-center p-2 rounded-xl w-full transition-all ${activeNav === 'localizacao' ? 'text-[#C9A356] bg-[#161410] border border-[#2A2419]' : 'text-gray-400 hover:text-[#C9A356] hover:bg-[#161410]/50'}`}>
                    <Icons.MapPin className="w-4 h-4 mb-1 text-[#C9A356]" />
                    <span className="text-[8px] font-serif tracking-wider uppercase font-bold">RESENDE</span>
                  </button>
                </nav>

                <div className="w-full pt-3 border-t border-[#211F1C] flex flex-col gap-2">
                  <button
                    onClick={handleInstallApp}
                    className="w-full py-2 px-1 rounded-xl bg-[#C9A356] hover:bg-[#B59044] text-black font-bold text-[8px] tracking-wider uppercase transition-all flex flex-col items-center text-center shadow"
                    title="Instalar App na tela do celular"
                  >
                    <Icons.Package className="w-3.5 h-3.5 mb-0.5" />
                    <span>INSTALAR APP</span>
                  </button>
                  <button
                    onClick={() => switchRole('cliente')}
                    className="w-full py-2 px-1 rounded-xl bg-[#C9A356]/15 hover:bg-[#C9A356] border border-[#C9A356]/40 text-[#C9A356] hover:text-black transition-all flex flex-col items-center text-center shadow"
                  >
                    <Icons.User className="w-3.5 h-3.5 mb-0.5" />
                    <span className="text-[8px] uppercase tracking-wider font-bold">ÁREA CLIENTE</span>
                  </button>
                  <button
                    onClick={() => switchRole('dono')}
                    className="w-full py-2 px-1 rounded-xl bg-[#161512] hover:bg-[#201E19] border border-[#2A261F] text-gray-400 hover:text-white transition-all flex flex-col items-center text-center"
                  >
                    <Icons.Lock className="w-3.5 h-3.5 mb-0.5" />
                    <span className="text-[8px] uppercase tracking-wider font-bold">GESTÃO / LOGIN</span>
                  </button>
                </div>
              </aside>

              {/* CONTEÚDO PRINCIPAL */}
              <main className="flex-1 md:ml-[140px] bg-[#0B0B0B] min-h-screen text-[#E0DDD5]">
=======
          {currentView === 'site' && (
            <div className="flex flex-col md:flex-row min-h-screen max-w-[1440px] mx-auto w-full relative">
              
              {/* SIDEBAR VERTICAL ESQUERDA REFINADA & RESPONSIVA */}
              <aside className="w-full md:w-[140px] md:sticky md:top-0 md:h-screen md:shrink-0 sticky top-0 bg-[#0B0B0B]/95 md:bg-[#0B0B0B] border-b md:border-b-0 md:border-r border-[#211F1C] z-40 flex flex-col justify-between p-3 md:py-6 text-white shadow-2xl backdrop-blur-md">
                
                {/* TOPO: LOGO & ATALHOS MOBILE / LOGO DESKTOP */}
                <div className="w-full flex md:flex-col items-center justify-between md:justify-center text-center cursor-pointer mb-2 md:mb-3">
                  <div className="flex items-center md:flex-col gap-2 md:gap-0" onClick={() => scrollToSection('home')}>
                    <OfficialLogo className="w-10 h-10 md:w-16 md:h-16" />
                    <div className="text-left md:text-center">
                      <span className="font-serif font-bold text-sm tracking-widest text-white md:hidden block">VALVERD'S</span>
                      <span className="text-[8px] font-serif tracking-[0.25em] text-[#C9A356] font-bold">EST. 2022</span>
                    </div>
                  </div>

                  {/* Ações Rápidas Mobile */}
                  <div className="flex md:hidden items-center gap-2">
                    <button
                      onClick={() => switchRole('cliente')}
                      className="px-3 py-1.5 rounded-full bg-[#C9A356] text-black text-[10px] font-serif font-bold uppercase tracking-wider flex items-center gap-1 shadow"
                    >
                      <Icons.User className="w-3 h-3" />
                      <span>Área VIP</span>
                    </button>
                    <button
                      onClick={() => switchRole('dono')}
                      className="p-1.5 rounded-full bg-[#161512] text-gray-400 hover:text-white border border-[#2A261F]"
                      title="Painel Gerencial"
                    >
                      <Icons.Lock className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* NAVEGAÇÃO: SCROLL HORIZONTAL NO MOBILE, VERTICAL NO DESKTOP */}
                <nav className="w-full flex flex-row md:flex-col items-center gap-1 md:gap-2 py-1 overflow-x-auto no-scrollbar">
                  {[
                    { id: 'home', label: 'HOME', icon: Icons.Home },
                    { id: 'sobre-nos', label: 'SOBRE', icon: Icons.Info },
                    { id: 'espaco', label: 'ESPAÇO', icon: Icons.Camera },
                    { id: 'cortes', label: 'CORTES', icon: Icons.Scissors },
                    { id: 'servicos', label: 'SERVIÇOS', icon: Icons.Award },
                    { id: 'bebidas', label: 'BAR', icon: Icons.Wine },
                    { id: 'produtos', label: 'PRODUTOS', icon: Icons.Package },
                    { id: 'barbeiros', label: 'EQUIPE', icon: Icons.Users },
                    { id: 'localizacao', label: 'RESENDE', icon: Icons.MapPin }
                  ].map((item) => {
                    const IconComp = item.icon;
                    const isActive = activeNav === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => scrollToSection(item.id)}
                        className={`shrink-0 flex flex-row md:flex-col items-center justify-center gap-1 md:gap-1 px-3 py-1.5 md:p-2 rounded-full md:rounded-xl md:w-full transition-all whitespace-nowrap ${
                          isActive
                            ? 'text-black bg-[#C9A356] font-bold shadow'
                            : 'text-gray-400 hover:text-[#C9A356] hover:bg-[#161410] border border-transparent hover:border-[#2A2419]'
                        }`}
                      >
                        <IconComp className={`w-3.5 h-3.5 md:w-4 md:h-4 ${isActive ? 'text-black' : ''}`} />
                        <span className="text-[10px] md:text-[8px] font-serif tracking-widest uppercase font-bold">{item.label}</span>
                      </button>
                    );
                  })}
                </nav>

                {/* AÇÕES INFERIORES: EXIBIDAS NO DESKTOP */}
                <div className="hidden md:flex w-full pt-3 border-t border-[#211F1C] flex-col gap-2">
                  <button
                    onClick={handleInstallApp}
                    className="w-full py-2 px-1 rounded-xl bg-[#C9A356] hover:bg-[#B59044] text-black font-bold text-[8px] tracking-wider uppercase transition-all flex flex-col items-center text-center shadow"
                    title="Instalar App na tela do celular"
                  >
                    <Icons.Package className="w-3.5 h-3.5 mb-0.5" />
                    <span>INSTALAR APP</span>
                  </button>
                  <button
                    onClick={() => switchRole('cliente')}
                    className="w-full py-2 px-1 rounded-xl bg-[#C9A356]/15 hover:bg-[#C9A356] border border-[#C9A356]/40 text-[#C9A356] hover:text-black transition-all flex flex-col items-center text-center shadow"
                  >
                    <Icons.User className="w-3.5 h-3.5 mb-0.5" />
                    <span className="text-[8px] uppercase tracking-wider font-bold">ÁREA CLIENTE</span>
                  </button>
                  <button
                    onClick={() => switchRole('dono')}
                    className="w-full py-2 px-1 rounded-xl bg-[#161512] hover:bg-[#201E19] border border-[#2A261F] text-gray-400 hover:text-white transition-all flex flex-col items-center text-center"
                  >
                    <Icons.Lock className="w-3.5 h-3.5 mb-0.5" />
                    <span className="text-[8px] uppercase tracking-wider font-bold">GESTÃO / LOGIN</span>
                  </button>
                </div>
              </aside>

              {/* CONTEÚDO PRINCIPAL (sem margem forçada graças ao sticky flex) */}
              <main className="flex-1 min-w-0 bg-[#0B0B0B] min-h-screen text-[#E0DDD5]">
>>>>>>>
```

---

### 8.3. Edição do Hero e Títulos com `.gold-shimmer` e `.gold-divider` (`index.html`, Linhas 1459-1471)

**Substituição Proposta:**

```html
<<<<<<< TARGET (Linhas 1459-1471)
                    <h1 className="font-serif text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-wider uppercase text-white mb-2">
                      VALVERD'S
                    </h1>
                    <div className="text-base sm:text-xl font-serif italic text-[#C9A356] tracking-widest mb-3">
                      BarberShop — Desde 2022
                    </div>
                    <p className="text-sm sm:text-base md:text-lg font-serif text-[#D6D2CA] tracking-widest uppercase max-w-xl mb-2">
                      "Beard, hair and mustache"
                    </p>
                    <p className="text-xs sm:text-sm text-[#C9A356] font-serif font-bold tracking-wider uppercase mb-8">
                      "Dê um tapa no seu estilo!"
                    </p>
=======
                    <h1 className="font-serif text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-[0.15em] uppercase gold-shimmer mb-2 drop-shadow-lg">
                      VALVERD'S
                    </h1>
                    <div className="text-base sm:text-xl font-serif italic text-[#C9A356] tracking-widest mb-2">
                      BarberShop — Desde 2022
                    </div>
                    <div className="gold-divider"></div>
                    <p className="text-sm sm:text-base md:text-lg font-serif text-[#D6D2CA] tracking-[0.2em] uppercase max-w-xl mb-2">
                      "Beard, hair and mustache"
                    </p>
                    <p className="text-xs sm:text-sm text-[#C9A356] font-serif font-bold tracking-widest uppercase mb-8">
                      "Dê um tapa no seu estilo!"
                    </p>
>>>>>>>
```

---

### 8.4. Substituição das Setas do Carrossel de Fotos (`index.html`, Linhas 1573-1577)

**Substituição Proposta:**

```html
<<<<<<< TARGET (Linhas 1573-1577)
                          <div className="flex gap-2">
                            <button onClick={prevSlide} className="w-9 h-9 rounded-full bg-black/60 hover:bg-[#C9A356] hover:text-black text-white flex items-center justify-center transition-all">‹</button>
                            <button onClick={nextSlide} className="w-9 h-9 rounded-full bg-black/60 hover:bg-[#C9A356] hover:text-black text-white flex items-center justify-center transition-all">›</button>
                          </div>
=======
                          <div className="flex gap-2">
                            <button onClick={prevSlide} aria-label="Slide anterior" className="w-9 h-9 rounded-full bg-black/70 hover:bg-[#C9A356] hover:text-black text-white border border-white/10 flex items-center justify-center transition-all shadow-lg active:scale-90">
                              <Icons.ChevronLeft className="w-4 h-4" />
                            </button>
                            <button onClick={nextSlide} aria-label="Próximo slide" className="w-9 h-9 rounded-full bg-black/70 hover:bg-[#C9A356] hover:text-black text-white border border-white/10 flex items-center justify-center transition-all shadow-lg active:scale-90">
                              <Icons.ChevronRight className="w-4 h-4" />
                            </button>
                          </div>
>>>>>>>
```

---

### 8.5. Limpeza de Espaçamento Tipográfico nos Títulos de Seção

1. **Sobre Nós (Linha 1523):**
   - Alterar `S O B R E - N Ó S` para `SOBRE NÓS` mantendo `tracking-[0.25em]`.
2. **Espaço (Linha 1556):**
   - Alterar `E S P A Ç O` para `ESPAÇO` mantendo `tracking-[0.25em]`.
3. **Cortes & Trabalhos (Linha 1620):**
   - Alterar `C O R T E S &nbsp; & &nbsp; T R A B A L H O S` para `CORTES & TRABALHOS` com `tracking-[0.25em]`.
4. **Nossos Serviços (Linha 1661):**
   - Alterar `N O S S O S &nbsp; S E R V I Ç O S` para `NOSSOS SERVIÇOS` com `tracking-[0.25em]`.
5. **Bebidas & Bar (Linha 1736):**
   - Alterar `B E B I D A S &nbsp; & &nbsp; B A R` para `BEBIDAS & BAR` com `tracking-[0.25em]`.
6. **Nossa Equipe (Linha 1829):**
   - Alterar `N O S S A &nbsp; E Q U I P E` para `NOSSA EQUIPE` com `tracking-[0.25em]`.

---

## 9. Matriz de Verificação & Critérios de Aceite para M1

| Item | Critério de Aceite | Como Testar |
| :--- | :--- | :--- |
| **Mobile Nav** | Todos os 9 botões visíveis sem quebra de linha ou corte de texto em viewport 375px | Redimensionar navegador para 375px de largura. Testar rolagem horizontal suave da barra de navegação. Clicar em cada seção. |
| **Widescreen 1440px** | Sidebar fica unida ao conteúdo central em monitores widescreen (1920px+) | Abrir em tela de 1920px. Verificar que o container central tem max 1440px e a sidebar está adjacente sem gap vazio. |
| **Ícones Vetoriais** | Zero caracteres ASCII `‹`, `›`, `<`, `>` ou `✕` nos botões do carrossel, modais ou paginação | Inspecionar elementos dos botões do carrossel e botões de fechar modal. Confirmar presença de tags `<svg>`. |
| **Animações** | Modais e Toasts abrem com animação suave de fade e escala | Abrir modal de agendamento e confirmar agendamento para disparar toast. Verificar fluidez da transição visual. |
| **Tipografia & Dourado** | Logo e título possuem brilho de metal escovado (`gold-shimmer`) e títulos legíveis | Verificar contraste no Dark Mode do título `VALVERD'S` com gradiente dourado metálico. |

---

## 10. Conclusão & Recomendações

O conjunto de mudanças detalhado neste relatório elimina completamente qualquer aspecto residual de protótipo no Site Público e no sistema de navegação da Valverd's BarberShop. Ao adotar a arquitetura `md:sticky` com container `max-w-[1440px]` e fita deslizante com `overflow-x-auto no-scrollbar` no mobile, a experiência se equipara imediatamente aos maiores nomes da hotelaria e estética masculina internacional.
