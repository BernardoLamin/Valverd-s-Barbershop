<#
.SYNOPSIS
    Master E2E Test Runner for Valverd's BarberShop.
.DESCRIPTION
    Executes automated opaque-box tests across Tiers 1-4 validating R1, R2, R3, and R4 acceptance criteria.
    Supports filtering by Tier and Milestone.
    Returns exit code 0 when all tests pass, exit code 1 if any test fails.
.PARAMETER Tier
    Specify target tier: 1, 2, 3, 4, or "All" (default: "All").
.PARAMETER Milestone
    Specify target milestone: "M1", "M2", "M3", "M4", or "All" (default: "All").
.PARAMETER Detailed
    Display verbose diagnostic information.
.PARAMETER ProjectRoot
    Root directory of the project.
.EXAMPLE
    pwsh -File tests/run_e2e_tests.ps1
.EXAMPLE
    pwsh -File tests/run_e2e_tests.ps1 -Tier 1
.EXAMPLE
    pwsh -File tests/run_e2e_tests.ps1 -Milestone M1
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$Tier = "All",

    [Parameter(Mandatory = $false)]
    [string]$Milestone = "All",

    [Parameter(Mandatory = $false)]
    [switch]$Detailed,

    [Parameter(Mandatory = $false)]
    [string]$ProjectRoot = "C:\Users\blaminma\Downloads\valverds-barbershop"
)

$ErrorActionPreference = "Continue"

Write-Host "========================================================" -ForegroundColor DarkYellow
Write-Host "     VALVERD'S BARBERSHOP — AUTOMATED E2E TEST SUITE    " -ForegroundColor DarkYellow
Write-Host "========================================================" -ForegroundColor DarkYellow
Write-Host " Project Root : $ProjectRoot"
Write-Host " Filter Tier  : $Tier"
Write-Host " Milestone    : $Milestone"
Write-Host " Timestamp    : $([System.DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ'))"
Write-Host "========================================================" -ForegroundColor DarkYellow

# Resolve Paths
$testsDir = $PSScriptRoot
$enginePath = Join-Path $testsDir "e2e_test_engine.ps1"

if (-not (Test-Path $enginePath)) {
    Write-Error "Test engine not found at $enginePath"
    exit 1
}

# Load Engine
. $enginePath

# Configure Filter Variables
$global:FilterTier = if ($Tier -eq "All" -or [string]::IsNullOrWhiteSpace($Tier)) { 0 } else { [int]$Tier }
$global:FilterMilestone = if ($Milestone -eq "All" -or [string]::IsNullOrWhiteSpace($Milestone)) { "All" } else { $Milestone }

Initialize-TestContext

# 1. Tier 1: Feature Coverage (R1 - R4)
if ($global:FilterTier -eq 0 -or $global:FilterTier -eq 1) {
    $t1Path = Join-Path $testsDir "test_tier1_feature_coverage.ps1"
    if (Test-Path $t1Path) {
        . $t1Path -ProjectRoot $ProjectRoot
    }
}

# 2. Tier 2: Boundaries & Corner Cases
if ($global:FilterTier -eq 0 -or $global:FilterTier -eq 2) {
    $t2Path = Join-Path $testsDir "test_tier2_boundaries.ps1"
    if (Test-Path $t2Path) {
        . $t2Path -ProjectRoot $ProjectRoot
    }
}

# 3. Tier 3: Cross-Feature Interactions
if ($global:FilterTier -eq 0 -or $global:FilterTier -eq 3) {
    $t3Path = Join-Path $testsDir "test_tier3_interactions.ps1"
    if (Test-Path $t3Path) {
        . $t3Path -ProjectRoot $ProjectRoot
    }
}

# 4. Tier 4: Real-World Workloads
if ($global:FilterTier -eq 0 -or $global:FilterTier -eq 4) {
    $t4Path = Join-Path $testsDir "test_tier4_workloads.ps1"
    if (Test-Path $t4Path) {
        . $t4Path -ProjectRoot $ProjectRoot
    }
}

# Display Summary Report
$allPassed = Show-TestSummary

if ($allPassed) {
    Write-Host "`n>>> RESULT: SUCCESS — ALL TARGETED TESTS PASSED (EXIT CODE 0) <<<" -ForegroundColor Green
    exit 0
} else {
    Write-Host "`n>>> RESULT: FAILURE — ONE OR MORE TESTS FAILED (EXIT CODE 1) <<<" -ForegroundColor Red
    exit 1
}
