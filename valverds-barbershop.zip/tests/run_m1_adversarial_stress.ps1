# run_m1_adversarial_stress.ps1 — Milestone 1 Empirical Stress Test Runner
[CmdletBinding()]
param(
    [string]$ProjectRoot = "C:\Users\blaminma\Downloads\valverds-barbershop"
)

$ErrorActionPreference = "Continue"

Write-Host "========================================================" -ForegroundColor Magenta
Write-Host "   EMPIRICAL ADVERSARIAL CHALLENGER SUITE — MILESTONE 1 " -ForegroundColor Magenta
Write-Host "========================================================" -ForegroundColor Magenta
Write-Host " Project Root : $ProjectRoot"
Write-Host " Target File  : $ProjectRoot\index.html"
Write-Host " Timestamp    : $([System.DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ'))"
Write-Host "========================================================" -ForegroundColor Magenta

. (Join-Path $PSScriptRoot "helpers\edge_headless_runner.ps1")
$edgePath = Get-EdgeExecutablePath
$harnessPath = Join-Path $PSScriptRoot "m1_stress_runner.html"
$fileUri = "file:///" + $harnessPath.Replace("\", "/")

Write-Host "Launching Headless Chromium via Edge: $edgePath"
Write-Host "Harness URI: $fileUri"
Write-Host "Executing empirical stress tests inside browser runtime..."

$args = @(
    "--headless",
    "--disable-gpu",
    "--dump-dom",
    "--virtual-time-budget=40000",
    "--allow-file-access-from-files",
    "--no-sandbox",
    "--log-level=3",
    "`"$fileUri`""
)

$pinfo = New-Object System.Diagnostics.ProcessStartInfo
$pinfo.FileName = $edgePath
$pinfo.Arguments = ($args -join " ")
$pinfo.RedirectStandardOutput = $true
$pinfo.RedirectStandardError = $true
$pinfo.UseShellExecute = $false
$pinfo.CreateNoWindow = $true

$startTime = [System.DateTime]::UtcNow
$process = [System.Diagnostics.Process]::Start($pinfo)

$stdout = $process.StandardOutput.ReadToEnd()
$stderr = $process.StandardError.ReadToEnd()
$completed = $process.WaitForExit(45000)

if (-not $completed) {
    try { $process.Kill() } catch {}
    Write-Error "Edge headless stress execution timed out after 45000 ms"
    exit 1
}

$elapsed = ([System.DateTime]::UtcNow - $startTime).TotalMilliseconds

# Check for test-output in DOM
if ($stdout -match '<div id="test-output"[^>]*>([\s\S]*?)<\/div>') {
    $rawJson = $matches[1]
    $decodedJson = [System.Net.WebUtility]::HtmlDecode($rawJson)
    try {
        $data = $decodedJson | ConvertFrom-Json
        Write-Host "`n========================================================" -ForegroundColor Cyan
        Write-Host "             ADVERSARIAL STRESS TEST RESULTS            " -ForegroundColor Cyan
        Write-Host "========================================================" -ForegroundColor Cyan
        
        foreach ($t in $data.tests) {
            if ($t.passed) {
                Write-Host "  [PASS] " -NoNewline -ForegroundColor Green
                Write-Host "$($t.name)" -NoNewline
                if ($t.details) { Write-Host " — $($t.details)" -ForegroundColor DarkGray } else { Write-Host "" }
            } else {
                Write-Host "  [FAIL] " -NoNewline -ForegroundColor Red
                Write-Host "$($t.name)" -NoNewline
                if ($t.details) { Write-Host " — $($t.details)" -ForegroundColor Yellow } else { Write-Host "" }
            }
        }

        Write-Host "`n========================================================" -ForegroundColor Magenta
        Write-Host "                 STRESS EXECUTION SUMMARY               " -ForegroundColor Magenta
        Write-Host "========================================================" -ForegroundColor Magenta
        Write-Host " Total Tests  : $($data.total)"
        Write-Host " Passed       : $($data.passed)" -ForegroundColor Green
        Write-Host " Failed       : $($data.failed)" -ForegroundColor $(if ($data.failed -gt 0) { "Red" } else { "Gray" })
        $passRate = if ($data.total -gt 0) { [Math]::Round(($data.passed / $data.total) * 100, 1) } else { 0 }
        Write-Host " Pass Rate    : $passRate%"
        Write-Host " Elapsed Time : $([Math]::Round($elapsed)) ms"
        Write-Host " Console Errs : $($data.consoleErrors.Count)"
        Write-Host " Exceptions   : $($data.uncaughtExceptions.Count)"
        Write-Host "========================================================" -ForegroundColor Magenta

        if ($data.consoleErrors.Count -gt 0) {
            Write-Host "`nBrowser Console Errors:" -ForegroundColor Yellow
            foreach ($err in $data.consoleErrors) {
                Write-Host "  • $err" -ForegroundColor Red
            }
        }

        if ($data.uncaughtExceptions.Count -gt 0) {
            Write-Host "`nUncaught Exceptions:" -ForegroundColor Red
            foreach ($ex in $data.uncaughtExceptions) {
                Write-Host "  • $ex" -ForegroundColor Red
            }
        }

        if ($data.failed -eq 0 -and $data.total -gt 0) {
            Write-Host "`n>>> VERDICT: APPROVE (ALL EMPIRICAL TESTS PASSED) <<<" -ForegroundColor Green
            exit 0
        } else {
            Write-Host "`n>>> VERDICT: REQUEST_CHANGES (FAILURES DETECTED) <<<" -ForegroundColor Red
            exit 1
        }
    } catch {
        Write-Error "Failed to parse JSON test output: $_"
        Write-Host "Raw output:`n$rawJson"
        exit 1
    }
} else {
    Write-Error "Could not find #test-output in Edge stdout."
    Write-Host "STDOUT Sample (First 1000 chars):`n$($stdout.Substring(0, [Math]::Min(1000, $stdout.Length)))"
    exit 1
}
