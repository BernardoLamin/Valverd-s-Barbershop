# test_adversarial_m1.ps1 — Empirical Adversarial Test Harness for Milestone 1
param(
    [string]$ProjectRoot = "C:\Users\blaminma\Downloads\valverds-barbershop"
)

. (Join-Path $PSScriptRoot "e2e_test_engine.ps1")
. (Join-Path $PSScriptRoot "helpers\edge_headless_runner.ps1")

$indexPath = Join-Path $ProjectRoot "index.html"
if (-not (Test-Path $indexPath)) {
    throw "index.html not found at $indexPath"
}

$rawHtml = [System.IO.File]::ReadAllText($indexPath, [System.Text.Encoding]::UTF8)

# Inject error tracking at the very top of <head>
$errorTrap = @"
<script>
window.__capturedErrors = [];
window.__capturedWarnings = [];
window.addEventListener('error', function(e) {
    window.__capturedErrors.push({ type: 'error', message: e.message, filename: e.filename, lineno: e.lineno });
});
window.addEventListener('unhandledrejection', function(e) {
    window.__capturedErrors.push({ type: 'unhandledrejection', reason: String(e.reason) });
});
const _origConsoleError = console.error;
console.error = function() {
    window.__capturedErrors.push({ type: 'console.error', args: Array.from(arguments).map(String).join(' ') });
    _origConsoleError.apply(console, arguments);
};
</script>
"@

# Inject test harness at the very end of <body>
$testHarness = @"
<div id="test-results-container" style="display:none;"></div>
<script>
(async function() {
    const results = {
        timestamp: new Date().toISOString(),
        initialMount: false,
        consoleErrors: [],
        carousel: {},
        clientNavigation: {},
        clientProfileIntegrity: {},
        modalVectorButtons: {},
        modalEscapeKey: {},
        checkoutEdgeCases: {}
    };

    // Wait for React to mount
    function waitFor(predicate, timeoutMs = 4000) {
        return new Promise((resolve, reject) => {
            const start = Date.now();
            const interval = setInterval(() => {
                try {
                    const res = predicate();
                    if (res) {
                        clearInterval(interval);
                        resolve(res);
                    } else if (Date.now() - start > timeoutMs) {
                        clearInterval(interval);
                        resolve(null);
                    }
                } catch (e) {
                    clearInterval(interval);
                    reject(e);
                }
            }, 50);
        });
    }

    try {
        // 1. Initial Mount Check
        const rootMounted = await waitFor(() => document.getElementById('root') && document.getElementById('root').children.length > 0);
        results.initialMount = !!rootMounted;

        // 2. Check Carousel controls & counter in DOM
        const slideCounterEl = Array.from(document.querySelectorAll('*')).find(el => el.textContent && el.textContent.includes('01 / 09'));
        const chevrons = document.querySelectorAll('svg.lucide-chevron-left, svg.lucide-chevron-right, svg');
        results.carousel = {
            hasSlideCounter: !!slideCounterEl,
            counterText: slideCounterEl ? slideCounterEl.textContent.trim() : null,
            chevronCount: chevrons.length
        };

        // 3. Modals & Close Buttons (Vector X vs Escape) in Site view
        const heroBookingBtn = Array.from(document.querySelectorAll('button')).find(b => b.textContent && (b.textContent.includes('Agende Seu Horário') || b.textContent.includes('Agendar')));
        let modalOpened = false;
        let vectorXClosed = false;
        let escapeClosed = false;

        if (heroBookingBtn) {
            heroBookingBtn.click();
            await new Promise(r => setTimeout(r, 200));

            const modalCloseBtn = document.querySelector('button[aria-label="Fechar"]');
            modalOpened = !!modalCloseBtn;
            if (modalCloseBtn) {
                const hasSvgX = !!modalCloseBtn.querySelector('svg');
                
                // Test Escape key first!
                window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true }));
                document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true }));
                await new Promise(r => setTimeout(r, 100));

                const stillOpenAfterEscape = !!document.querySelector('button[aria-label="Fechar"]');
                escapeClosed = !stillOpenAfterEscape;

                // Now test vector X button
                const btnX = document.querySelector('button[aria-label="Fechar"]');
                if (btnX) {
                    btnX.click();
                    await new Promise(r => setTimeout(r, 150));
                    const closedAfterX = !document.querySelector('button[aria-label="Fechar"]');
                    vectorXClosed = closedAfterX;
                }
                results.modalVectorButtons = {
                    modalOpened,
                    hasSvgX,
                    vectorXClosed
                };
                results.modalEscapeKey = {
                    escapeClosed
                };
            }
        }

        // 4. Client Role Navigation
        const clientAreaBtns = Array.from(document.querySelectorAll('button')).filter(b => b.textContent && (b.textContent.includes('Meu Espaço VIP') || b.textContent.includes('Área VIP') || b.textContent.includes('Área do Cliente')));
        if (clientAreaBtns.length > 0) {
            clientAreaBtns[0].click();
            await new Promise(r => setTimeout(r, 200));
        }

        const clientViewHeader = Array.from(document.querySelectorAll('*')).find(el => el.textContent && el.textContent.includes('ESPAÇO CLIENTE'));
        const bookingStepper = Array.from(document.querySelectorAll('*')).find(el => el.textContent && (el.textContent.includes('Passo 1') || el.textContent.includes('Escolha o Barbeiro')));
        results.clientNavigation = {
            switchedToClientView: !!clientViewHeader,
            bookingStepperVisible: !!bookingStepper
        };

        // 5. Client Profile Integrity
        const clientNameEl = Array.from(document.querySelectorAll('*')).find(el => el.textContent && el.textContent.includes('Roberto Andrade'));
        const loyaltyStampsEl = Array.from(document.querySelectorAll('*')).find(el => el.textContent && el.textContent.includes('7 de 10 Selos Conquistados'));
        results.clientProfileIntegrity = {
            nameRendered: !!clientNameEl,
            loyaltyStampsRendered: !!loyaltyStampsEl
        };

        // 6. Checkout edge case test in JS (Testing exact verbatim logic in index.html)
        // Verbatim openCheckout (line 1243):
        // setCheckoutAppt({ ...appt, items: Array.isArray(appt.items) ? [...appt.items] : (appt.items || (appt.service ? [{ name: appt.service, price: appt.price || 0 }] : [])) })
        // Verbatim JSX item map (line 4151-4154):
        // (checkoutAppt.items || []).map((item, idx) => item.price.toFixed(2))
        // Verbatim JSX total (line 4188):
        // checkoutAppt.total.toFixed(2)
        function testCheckoutLogicVerbatim(appt) {
            try {
                if (!appt) return { ok: true, status: 'null_handled_early' };
                const checkoutAppt = {
                    ...appt,
                    items: Array.isArray(appt.items) ? [...appt.items] : (appt.items || (appt.service ? [{ name: appt.service, price: appt.price || 0 }] : []))
                };
                
                // Exactly line 4151-4154:
                const itemPrices = (checkoutAppt.items || []).map((item, idx) => {
                    return item.price.toFixed(2).replace('.', ',');
                });

                // Exactly line 4188:
                const totalStr = checkoutAppt.total.toFixed(2).replace('.', ',');

                return {
                    ok: true,
                    itemCount: itemPrices.length,
                    totalStr: totalStr
                };
            } catch (err) {
                return {
                    ok: false,
                    error: err.name + ': ' + err.message,
                    vulnerability: 'Unhandled TypeError on missing field'
                };
            }
        }

        results.checkoutEdgeCases = {
            emptyItems: testCheckoutLogicVerbatim({ id: 1, service: 'Corte', price: 40, total: 40, items: [] }),
            nullItemsWithService: testCheckoutLogicVerbatim({ id: 2, service: 'Barba', price: 30, total: 30, items: null }),
            undefinedItemsWithService: testCheckoutLogicVerbatim({ id: 3, service: 'Combo', price: 65, total: 65, items: undefined }),
            nullAppt: testCheckoutLogicVerbatim(null),
            missingTotalProperty: testCheckoutLogicVerbatim({ id: 5, service: 'Corte', price: 40, items: [{ name: 'Corte', price: 40 }] }),
            itemWithNullPrice: testCheckoutLogicVerbatim({ id: 6, service: 'Corte', total: 40, items: [{ name: 'Corte', price: null }] })
        };

        // Capture all console errors and unhandled rejections
        results.consoleErrors = window.__capturedErrors || [];

    } catch (globalErr) {
        results.globalError = globalErr.message;
        results.globalStack = globalErr.stack;
    }

    const container = document.getElementById('test-results-container');
    container.textContent = JSON.stringify(results);
})();
</script>
"@

# Prepare modified HTML for test harness
$htmlWithTrap = $rawHtml.Replace("<head>", "<head>`n" + $errorTrap)
$htmlWithHarness = $htmlWithTrap.Replace("</body>", $testHarness + "`n</body>")

$tempTestFile = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), "valverds_adversarial_test_$([System.Guid]::NewGuid().ToString('N')).html")
try {
    [System.IO.File]::WriteAllText($tempTestFile, $htmlWithHarness, [System.Text.Encoding]::UTF8)
    $testUrl = "file:///" + $tempTestFile.Replace("\", "/")

    # Run Edge headless with virtual time budget
    $dom = Invoke-EdgeDumpDom -Url $testUrl -TimeoutMs 20000 -VirtualTimeBudgetMs 3000

    if ($dom -match '<div id="test-results-container"[^>]*>(.*?)<\/div>') {
        $rawJson = $matches[1]
        $decodedJson = [System.Net.WebUtility]::HtmlDecode($rawJson)
        $parsed = $decodedJson | ConvertFrom-Json
        $parsed | ConvertTo-Json -Depth 6
        return
    } else {
        throw "Failed to find test results in Edge DOM. DOM length was: $($dom.Length)"
    }
}
finally {
    if (Test-Path $tempTestFile) {
        Remove-Item -Force $tempTestFile -ErrorAction SilentlyContinue
    }
}
