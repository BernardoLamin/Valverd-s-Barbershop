if (-not $global:TestSuiteResults) {
    $global:TestSuiteResults = [System.Collections.Generic.List[PSCustomObject]]::new()
}
if (-not $global:CurrentSuiteName) {
    $global:CurrentSuiteName = "Default"
}
if (-not $global:TestTimer) {
    $global:TestTimer = [System.Diagnostics.Stopwatch]::new()
}

function Initialize-TestContext {
    [CmdletBinding()]
    param()

    $global:TestSuiteResults = [System.Collections.Generic.List[PSCustomObject]]::new()
    $global:TestTimer = [System.Diagnostics.Stopwatch]::StartNew()
}

function Describe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [Parameter(Mandatory = $true)]
        [scriptblock]$ScriptBlock
    )

    $prevSuite = $global:CurrentSuiteName
    $global:CurrentSuiteName = $Name
    Write-Host "`n=== [SUITE] $Name ===" -ForegroundColor Cyan
    try {
        & $ScriptBlock
    }
    finally {
        $global:CurrentSuiteName = $prevSuite
    }
}

function It {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Description,
        [Parameter(Mandatory = $false)]
        [int]$Tier = 1,
        [Parameter(Mandatory = $false)]
        [string]$Milestone = "All",
        [Parameter(Mandatory = $true)]
        [scriptblock]$ScriptBlock
    )

    # Check filter conditions
    if ($global:FilterTier -and $global:FilterTier -ne 0 -and $global:FilterTier -ne $Tier) {
        return # Skip test outside target tier
    }
    if ($global:FilterMilestone -and $global:FilterMilestone -ne "All" -and $Milestone -ne "All" -and $global:FilterMilestone -ne $Milestone) {
        return # Skip test outside target milestone
    }

    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $status = "PASS"
    $errorMsg = ""

    try {
        & $ScriptBlock
        Write-Host "  [PASS] [Tier $Tier | $Milestone] $Description" -ForegroundColor Green
    }
    catch {
        $status = "FAIL"
        $errorMsg = $_.Exception.Message
        Write-Host "  [FAIL] [Tier $Tier | $Milestone] $Description" -ForegroundColor Red
        Write-Host "         Error: $errorMsg" -ForegroundColor DarkRed
    }
    finally {
        $sw.Stop()
        $record = [PSCustomObject]@{
            Suite       = $global:CurrentSuiteName
            Description = $Description
            Tier        = $Tier
            Milestone   = $Milestone
            Status      = $status
            DurationMs  = $sw.ElapsedMilliseconds
            Error       = $errorMsg
        }
        $global:TestSuiteResults.Add($record)
    }
}

# --- Assertion Helpers ---

function Assert-Equal {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        $Actual,
        [Parameter(Mandatory = $false)]
        $Expected,
        [Parameter(Mandatory = $false)]
        [string]$Message = ""
    )

    $detail = if ($Message) { " ($Message)" } else { "" }

    # If both can be converted to double, compare numerically
    $dAct = 0.0
    $dExp = 0.0
    $isActNum = [double]::TryParse("$Actual", [System.Globalization.NumberStyles]::Any, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$dAct)
    $isExpNum = [double]::TryParse("$Expected", [System.Globalization.NumberStyles]::Any, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$dExp)

    if ($isActNum -and $isExpNum) {
        if ([Math]::Abs($dAct - $dExp) -gt 0.0001) {
            throw "Assertion Failed$detail. Expected: '$Expected', Actual: '$Actual'"
        }
        return
    }

    $actStr = if ($null -eq $Actual) { "<null>" } else { $Actual.ToString() }
    $expStr = if ($null -eq $Expected) { "<null>" } else { $Expected.ToString() }

    if ($actStr -ne $expStr) {
        throw "Assertion Failed$detail. Expected: '$expStr', Actual: '$actStr'"
    }
}

function Assert-NotEqual {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        $Actual,
        [Parameter(Mandatory = $false)]
        $Expected,
        [Parameter(Mandatory = $false)]
        [string]$Message = ""
    )

    $actStr = if ($null -eq $Actual) { "<null>" } else { $Actual.ToString() }
    $expStr = if ($null -eq $Expected) { "<null>" } else { $Expected.ToString() }

    if ($actStr -eq $expStr) {
        $detail = if ($Message) { " ($Message)" } else { "" }
        throw "Assertion Failed$detail. Value should not equal '$expStr'"
    }
}

function Assert-True {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [bool]$Condition,
        [Parameter(Mandatory = $false)]
        [string]$Message = ""
    )

    if (-not $Condition) {
        $detail = if ($Message) { ": $Message" } else { "" }
        throw "Assertion Failed: Condition evaluated to False$detail"
    }
}

function Assert-False {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [bool]$Condition,
        [Parameter(Mandatory = $false)]
        [string]$Message = ""
    )

    if ($Condition) {
        $detail = if ($Message) { ": $Message" } else { "" }
        throw "Assertion Failed: Condition evaluated to True$detail"
    }
}

function Assert-Match {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [string]$InputString,
        [Parameter(Mandatory = $true)]
        [string]$Pattern,
        [Parameter(Mandatory = $false)]
        [string]$Message = ""
    )

    if ($null -eq $InputString -or -not ($InputString -match $Pattern)) {
        $detail = if ($Message) { " ($Message)" } else { "" }
        $preview = if ($null -eq $InputString) { "<null>" } elseif ($InputString.Length -gt 120) { $InputString.Substring(0, 120) + "..." } else { $InputString }
        throw "Assertion Failed$detail. Input does not match pattern '$Pattern'. Received: '$preview'"
    }
}

function Assert-NotMatch {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [string]$InputString,
        [Parameter(Mandatory = $true)]
        [string]$Pattern,
        [Parameter(Mandatory = $false)]
        [string]$Message = ""
    )

    if ($InputString -and ($InputString -match $Pattern)) {
        $detail = if ($Message) { " ($Message)" } else { "" }
        throw "Assertion Failed$detail. Input unexpectedly matched pattern '$Pattern'"
    }
}

function Assert-ApproxEqual {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [double]$Actual,
        [Parameter(Mandatory = $true)]
        [double]$Expected,
        [Parameter(Mandatory = $false)]
        [double]$Tolerance = 0.01,
        [Parameter(Mandatory = $false)]
        [string]$Message = ""
    )

    $diff = [Math]::Abs($Actual - $Expected)
    if ($diff -gt $Tolerance) {
        $detail = if ($Message) { " ($Message)" } else { "" }
        throw "Assertion Failed$detail. Expected: $Expected, Actual: $Actual, Diff: $diff, Allowed Tolerance: $Tolerance"
    }
}

function Assert-FileExists {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [Parameter(Mandatory = $false)]
        [long]$MinBytes = 0,
        [Parameter(Mandatory = $false)]
        [string]$Message = ""
    )

    if (-not (Test-Path $Path)) {
        $detail = if ($Message) { " ($Message)" } else { "" }
        throw "Assertion Failed$detail. File not found: '$Path'"
    }

    if ($MinBytes -gt 0) {
        $item = Get-Item $Path
        if ($item.Length -lt $MinBytes) {
            $detail = if ($Message) { " ($Message)" } else { "" }
            throw "Assertion Failed$detail. File '$Path' is too small ($($item.Length) bytes, expected at least $MinBytes bytes)"
        }
    }
}

function Assert-Contains {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        $Collection,
        [Parameter(Mandatory = $true)]
        $Item,
        [Parameter(Mandatory = $false)]
        [string]$Message = ""
    )

    $found = $false
    foreach ($elem in $Collection) {
        if ($elem -eq $Item) {
            $found = $true
            break
        }
    }

    if (-not $found) {
        $detail = if ($Message) { " ($Message)" } else { "" }
        throw "Assertion Failed$detail. Collection does not contain expected item: '$Item'"
    }
}

function Show-TestSummary {
    [CmdletBinding()]
    param()

    $total = $global:TestSuiteResults.Count
    $passed = ($global:TestSuiteResults | Where-Object { $_.Status -eq "PASS" }).Count
    $failed = ($global:TestSuiteResults | Where-Object { $_.Status -eq "FAIL" }).Count
    $passRate = if ($total -gt 0) { [Math]::Round(($passed / $total) * 100, 1) } else { 0.0 }

    Write-Host "`n========================================================" -ForegroundColor Cyan
    Write-Host "                E2E TEST EXECUTION SUMMARY              " -ForegroundColor Cyan
    Write-Host "========================================================" -ForegroundColor Cyan
    Write-Host " Total Tests  : $total"
    Write-Host " Passed       : $passed" -ForegroundColor Green
    Write-Host " Failed       : $failed" -ForegroundColor $(if ($failed -gt 0) { "Red" } else { "Green" })
    Write-Host " Pass Rate    : $passRate%" -ForegroundColor $(if ($passRate -eq 100.0) { "Green" } else { "Yellow" })
    Write-Host " Total Time   : $($global:TestTimer.ElapsedMilliseconds) ms"
    Write-Host "========================================================" -ForegroundColor Cyan

    # Tier Breakdown Table
    $tierGroups = $global:TestSuiteResults | Group-Object -Property Tier
    Write-Host "`nTier Breakdown:" -ForegroundColor DarkCyan
    foreach ($tg in ($tierGroups | Sort-Object Name)) {
        $tTotal = $tg.Group.Count
        $tPass = ($tg.Group | Where-Object { $_.Status -eq "PASS" }).Count
        $tFail = ($tg.Group | Where-Object { $_.Status -eq "FAIL" }).Count
        $tRate = if ($tTotal -gt 0) { [Math]::Round(($tPass / $tTotal) * 100, 1) } else { 0.0 }
        $color = if ($tFail -eq 0) { "Green" } else { "Yellow" }
        Write-Host ("  Tier {0} : {1}/{2} passed ({3}%)" -f $tg.Name, $tPass, $tTotal, $tRate) -ForegroundColor $color
    }

    if ($failed -gt 0) {
        Write-Host "`nFailed Tests Detail:" -ForegroundColor Red
        foreach ($f in ($global:TestSuiteResults | Where-Object { $_.Status -eq "FAIL" })) {
            Write-Host ("  - [{0}] {1}: {2}" -f $f.Suite, $f.Description, $f.Error) -ForegroundColor DarkRed
        }
        return $false
    }

    return $true
}

# End of e2e_test_engine.ps1
