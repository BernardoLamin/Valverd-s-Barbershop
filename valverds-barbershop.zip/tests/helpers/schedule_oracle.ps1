# schedule_oracle.ps1 — Independent Reference Oracle for Schedule Grids & Time Slots
# Authoritative Source: ORIGINAL_REQUEST.md §R3 & PROJECT.md § Interface Contracts
param()

function Get-All48TimeSlotsOracle {
    [CmdletBinding()]
    param()

    $slots = [System.Collections.Generic.List[string]]::new()
    for ($i = 0; $i -lt 48; $i++) {
        $hours = [Math]::Floor($i / 2)
        $mins = if ($i % 2 -eq 0) { "00" } else { "30" }
        $slots.Add(("{0:D2}:{1}" -f [int]$hours, $mins))
    }
    return $slots.ToArray()
}

function Test-ValidTimeFormatOracle {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [AllowEmptyString()]
        [string]$TimeStr = ""
    )

    if ([string]::IsNullOrWhiteSpace($TimeStr)) {
        return $false
    }

    # Strict 24h format HH:mm (00:00 to 23:59)
    if ($TimeStr -match '^([01]\d|2[0-3]):[0-5]\d$') {
        return $true
    }
    return $false
}

function Get-MergedSlotsOracle {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [string[]]$BaseSlots = @(),
        [Parameter(Mandatory = $false)]
        [string[]]$CustomSlots = @()
    )

    $combined = [System.Collections.Generic.HashSet[string]]::new()
    foreach ($s in $BaseSlots) {
        if (-not [string]::IsNullOrWhiteSpace($s)) {
            [void]$combined.Add($s.Trim())
        }
    }
    foreach ($c in $CustomSlots) {
        if (-not [string]::IsNullOrWhiteSpace($c)) {
            [void]$combined.Add($c.Trim())
        }
    }

    $sortedList = [System.Collections.Generic.List[string]]::new($combined)
    $sortedList.Sort([System.StringComparer]::Ordinal)
    return $sortedList.ToArray()
}

# End of schedule_oracle.ps1
