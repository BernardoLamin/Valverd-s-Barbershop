# edge_headless_runner.ps1 — Headless Browser Execution Helper for Valverd's BarberShop
param()

function Get-EdgeExecutablePath {
    $candidates = @(
        "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        "C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        "C:\Program Files\Google\Chrome\Application\chrome.exe",
        "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
    )
    foreach ($path in $candidates) {
        if (Test-Path $path) {
            return $path
        }
    }
    throw "No Chromium-based browser (msedge.exe or chrome.exe) found on this system."
}

function Invoke-EdgeDumpDom {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Url,
        [int]$TimeoutMs = 15000,
        [int]$VirtualTimeBudgetMs = 2000
    )

    $edgePath = Get-EdgeExecutablePath
    $tempFile = [System.IO.Path]::GetTempFileName()
    $errFile = [System.IO.Path]::GetTempFileName()

    $args = @(
        "--headless",
        "--disable-gpu",
        "--dump-dom",
        "--virtual-time-budget=$VirtualTimeBudgetMs",
        "--log-level=3",
        "--no-sandbox",
        "`"$Url`""
    )

    try {
        $pinfo = New-Object System.Diagnostics.ProcessStartInfo
        $pinfo.FileName = $edgePath
        $pinfo.Arguments = ($args -join " ")
        $pinfo.RedirectStandardOutput = $true
        $pinfo.RedirectStandardError = $true
        $pinfo.UseShellExecute = $false
        $pinfo.CreateNoWindow = $true

        $process = New-Object System.Diagnostics.Process
        $process.StartInfo = $pinfo
        [void]$process.Start()

        $stdout = $process.StandardOutput.ReadToEnd()
        $stderr = $process.StandardError.ReadToEnd()
        $completed = $process.WaitForExit($TimeoutMs)

        if (-not $completed) {
            try { $process.Kill() } catch {}
            throw "Edge headless execution timed out after $TimeoutMs ms for $Url"
        }

        return $stdout
    }
    finally {
        if (Test-Path $tempFile) { Remove-Item -Force $tempFile -ErrorAction SilentlyContinue }
        if (Test-Path $errFile) { Remove-Item -Force $errFile -ErrorAction SilentlyContinue }
    }
}

function Invoke-EdgeEvalJs {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$JsCode,
        [int]$TimeoutMs = 10000
    )

    $tempHtml = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), "valverds_eval_$([System.Guid]::NewGuid().ToString('N')).html")
    $wrappedHtml = @"
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body>
<div id="output"></div>
<script>
try {
    const fn = new Function(`$JsCode`);
    const res = fn();
    document.getElementById('output').textContent = JSON.stringify({ success: true, result: res });
} catch (err) {
    document.getElementById('output').textContent = JSON.stringify({ success: false, error: err.message, stack: err.stack });
}
</script>
</body>
</html>
"@
    try {
        [System.IO.File]::WriteAllText($tempHtml, $wrappedHtml, [System.Text.Encoding]::UTF8)
        $fileUri = "file:///" + $tempHtml.Replace("\", "/")
        $dom = Invoke-EdgeDumpDom -Url $fileUri -TimeoutMs $TimeoutMs -VirtualTimeBudgetMs 1000

        if ($dom -match '<div id="output">(.*?)<\/div>') {
            $rawJson = $matches[1]
            # Decode HTML entities if any
            $decodedJson = [System.Net.WebUtility]::HtmlDecode($rawJson)
            return ($decodedJson | ConvertFrom-Json)
        }
        else {
            throw "Failed to extract test output from Edge DOM. Raw output: $dom"
        }
    }
    finally {
        if (Test-Path $tempHtml) {
            Remove-Item -Force $tempHtml -ErrorAction SilentlyContinue
        }
    }
}

# End of edge_headless_runner.ps1
