# dre_reference_oracle.ps1 — Independent Mathematical Reference Oracle for DRE Calculations
# Authoritative Source: ORIGINAL_REQUEST.md §R4 & PROJECT.md § Interface Contracts
param()

function Invoke-CalculateDREOracle {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [array]$Appointments = @(),
        [Parameter(Mandatory = $false)]
        [array]$CounterSales = @(),
        [Parameter(Mandatory = $false)]
        [hashtable]$BarberCommissionRates = @{
            "Luis Valverde" = 0.60
            "luis"          = 0.60
            "Yago Barber"   = 0.50
            "yago"          = 0.50
        },
        [Parameter(Mandatory = $false)]
        [hashtable]$ProductCosts = @{},
        [Parameter(Mandatory = $false)]
        [double]$DefaultProductCostRatio = 0.45,
        [Parameter(Mandatory = $false)]
        [double]$FixedCosts = 0.0,
        [Parameter(Mandatory = $false)]
        [string]$TargetDay = $null
    )

    # 1. Filter completed appointments (optionally by target day)
    $completedAppts = @()
    foreach ($a in $Appointments) {
        $status = if ($a.status) { $a.status.ToString().ToLower() } else { "" }
        if ($status -eq "concluido" -or $status -eq "completed") {
            if ($null -eq $TargetDay -or $TargetDay -eq "" -or $a.day -eq $TargetDay) {
                $completedAppts += $a
            }
        }
    }

    # 2. Filter counter sales (optionally by target day)
    $filteredCounterSales = @()
    foreach ($sale in $CounterSales) {
        if ($null -eq $TargetDay -or $TargetDay -eq "" -or $sale.day -eq $TargetDay) {
            $filteredCounterSales += $sale
        }
    }

    # 3. Calculate Service Revenue vs Bar Revenue in Appointments
    $revenueServices = 0.0
    $revenueAppointmentBar = 0.0
    $commissionsByBarber = @{}
    foreach ($k in $BarberCommissionRates.Keys) {
        $commissionsByBarber[$k] = 0.0
    }
    $totalTeamCommissions = 0.0
    $apptProductsCost = 0.0

    foreach ($appt in $completedAppts) {
        $barberName = if ($appt.barber) { $appt.barber.ToString() } else { "Unknown" }
        $rate = 0.50 # default fallback
        if ($BarberCommissionRates.ContainsKey($barberName)) {
            $rate = [double]$BarberCommissionRates[$barberName]
        }

        # Handle items breakdown if structured, else single service
        if ($appt.items -and ($appt.items -is [System.Collections.IEnumerable]) -and ($appt.items.Count -gt 0)) {
            $isFirst = $true
            foreach ($item in $appt.items) {
                $itemPrice = [double]$item.price
                $itemType = if ($item.type) { $item.type.ToString().ToLower() } else { if ($isFirst) { "service" } else { "bar" } }

                if ($itemType -eq "service" -or $itemType -eq "corte") {
                    $revenueServices += $itemPrice
                    $barberComm = [Math]::Round($itemPrice * $rate, 2)
                    $totalTeamCommissions += $barberComm
                    if ($commissionsByBarber.ContainsKey($barberName)) {
                        $commissionsByBarber[$barberName] += $barberComm
                    } else {
                        $commissionsByBarber[$barberName] = $barberComm
                    }
                } else {
                    # Bar items attached to appointment generate strictly 0% barber commission
                    $revenueAppointmentBar += $itemPrice

                    # Product cost
                    $prodName = $item.name
                    $cost = 0.0
                    if ($ProductCosts.ContainsKey($prodName)) {
                        $cost = [double]$ProductCosts[$prodName]
                    } else {
                        $cost = [Math]::Round($itemPrice * $DefaultProductCostRatio, 2)
                    }
                    $apptProductsCost += $cost
                }
                $isFirst = $false
            }
        } else {
            # Legacy/simple format: price is service price
            $servicePrice = [double]$(if ($appt.servicePrice) { $appt.servicePrice } elseif ($appt.price) { $appt.price } else { 0.0 })
            $revenueServices += $servicePrice

            $barberComm = [Math]::Round($servicePrice * $rate, 2)
            $totalTeamCommissions += $barberComm
            if ($commissionsByBarber.ContainsKey($barberName)) {
                $commissionsByBarber[$barberName] += $barberComm
            } else {
                $commissionsByBarber[$barberName] = $barberComm
            }

            # If appointment had explicit barItems list
            if ($appt.barItems) {
                foreach ($bItem in $appt.barItems) {
                    $bPrice = [double]$bItem.price
                    $revenueAppointmentBar += $bPrice

                    $bCost = 0.0
                    if ($ProductCosts.ContainsKey($bItem.name)) {
                        $bCost = [double]$ProductCosts[$bItem.name]
                    } else {
                        $bCost = [Math]::Round($bPrice * $DefaultProductCostRatio, 2)
                    }
                    $apptProductsCost += $bCost
                }
            }
        }
    }

    # 4. Calculate Counter Sales (Balcão)
    $revenueBalcao = 0.0
    $balcaoProductsCost = 0.0
    foreach ($sale in $filteredCounterSales) {
        $qty = if ($sale.qty) { [int]$sale.qty } else { 1 }
        $unitPrice = [double]$sale.price
        $saleTotal = if ($sale.total) { [double]$sale.total } else { $unitPrice * $qty }
        $revenueBalcao += $saleTotal

        $itemCost = 0.0
        $itemName = if ($sale.item) { $sale.item } else { $sale.name }
        if ($itemName -and $ProductCosts.ContainsKey($itemName)) {
            $itemCost = [double]$ProductCosts[$itemName] * $qty
        } else {
            $itemCost = [Math]::Round($saleTotal * $DefaultProductCostRatio, 2)
        }
        $balcaoProductsCost += $itemCost
    }

    # 5. Aggregate Totals
    $revenueBarTotal = $revenueAppointmentBar + $revenueBalcao
    $grossRevenue = $revenueServices + $revenueBarTotal
    $suppliesCostTotal = $apptProductsCost + $balcaoProductsCost
    $netProfit = $grossRevenue - $totalTeamCommissions - $suppliesCostTotal - $FixedCosts

    $netMarginPercent = 0.0
    if ($grossRevenue -gt 0.0) {
        $netMarginPercent = [Math]::Round(($netProfit / $grossRevenue) * 100.0, 1)
    }

    return [PSCustomObject]@{
        GrossRevenue             = [Math]::Round($grossRevenue, 2)
        RevenueServices          = [Math]::Round($revenueServices, 2)
        RevenueBarTotal          = [Math]::Round($revenueBarTotal, 2)
        RevenueAppointmentBar    = [Math]::Round($revenueAppointmentBar, 2)
        RevenueBalcao            = [Math]::Round($revenueBalcao, 2)
        TotalTeamCommissions     = [Math]::Round($totalTeamCommissions, 2)
        CommissionsByBarber      = $commissionsByBarber
        TotalSuppliesCost        = [Math]::Round($suppliesCostTotal, 2)
        FixedCosts               = [Math]::Round($FixedCosts, 2)
        NetProfit                = [Math]::Round($netProfit, 2)
        NetMarginPercent         = $netMarginPercent
        CompletedApptsCount      = $completedAppts.Count
        CounterSalesCount        = $filteredCounterSales.Count
    }
}

# End of dre_reference_oracle.ps1
