# test_tier4_workloads.ps1 — Tier 4: Real-World Workload Scenarios Test Suite
# Tests authentic operating days, WhatsApp communication workflows, and executive financial closeouts.
param(
    [string]$ProjectRoot = "C:\Users\blaminma\Downloads\valverds-barbershop"
)

. (Join-Path $PSScriptRoot "e2e_test_engine.ps1")
. (Join-Path $PSScriptRoot "helpers\schedule_oracle.ps1")
. (Join-Path $PSScriptRoot "helpers\dre_reference_oracle.ps1")
. (Join-Path $PSScriptRoot "helpers\edge_headless_runner.ps1")

Describe "Tier 4: Real-World Workload Scenarios" {

    It "T4.1: Full Operational Barbershop Day Simulation (Appointments + Bar + Counter Sales)" -Tier 4 -Milestone "M4" {
        # 12 Appointments across the day:
        # - Luis Valverde: 5 completed, 1 pending, 1 canceled
        # - Yago Barber: 3 completed, 1 pending, 1 canceled
        $workloadAppts = @(
            # Luis Completed:
            [PSCustomObject]@{
                id = 1; status = "concluido"; barber = "Luis Valverde"; day = "Seg";
                items = @(
                    [PSCustomObject]@{ name = "Corte Clássico"; price = 60.0; type = "service" },
                    [PSCustomObject]@{ name = "Café Espresso"; price = 0.0; type = "bar" }
                )
            },
            [PSCustomObject]@{
                id = 2; status = "concluido"; barber = "Luis Valverde"; day = "Seg";
                items = @(
                    [PSCustomObject]@{ name = "Barba Terapia"; price = 50.0; type = "service" },
                    [PSCustomObject]@{ name = "Cerveja Heineken"; price = 15.0; type = "bar" }
                )
            },
            [PSCustomObject]@{
                id = 3; status = "concluido"; barber = "Luis Valverde"; day = "Seg";
                items = @(
                    [PSCustomObject]@{ name = "Combo Corte + Barba"; price = 100.0; type = "service" }
                )
            },
            [PSCustomObject]@{
                id = 4; status = "concluido"; barber = "Luis Valverde"; day = "Seg";
                items = @(
                    [PSCustomObject]@{ name = "Corte Clássico"; price = 60.0; type = "service" }
                )
            },
            [PSCustomObject]@{
                id = 5; status = "concluido"; barber = "Luis Valverde"; day = "Seg";
                items = @(
                    [PSCustomObject]@{ name = "Acabamento Navalha"; price = 30.0; type = "service" },
                    [PSCustomObject]@{ name = "Pomada Matte"; price = 40.0; type = "bar" }
                )
            },

            # Yago Completed:
            [PSCustomObject]@{
                id = 6; status = "concluido"; barber = "Yago Barber"; day = "Seg";
                items = @(
                    [PSCustomObject]@{ name = "Corte Fade"; price = 60.0; type = "service" }
                )
            },
            [PSCustomObject]@{
                id = 7; status = "concluido"; barber = "Yago Barber"; day = "Seg";
                items = @(
                    [PSCustomObject]@{ name = "Corte Kids"; price = 50.0; type = "service" },
                    [PSCustomObject]@{ name = "Refrigerante"; price = 8.0; type = "bar" }
                )
            },
            [PSCustomObject]@{
                id = 8; status = "concluido"; barber = "Yago Barber"; day = "Seg";
                items = @(
                    [PSCustomObject]@{ name = "Barba Alinhada"; price = 40.0; type = "service" }
                )
            },

            # Uncompleted (Pending & Canceled):
            [PSCustomObject]@{ id = 9; status = "pendente"; barber = "Luis Valverde"; day = "Seg"; price = 60.0 },
            [PSCustomObject]@{ id = 10; status = "cancelado"; barber = "Luis Valverde"; day = "Seg"; price = 100.0 },
            [PSCustomObject]@{ id = 11; status = "pendente"; barber = "Yago Barber"; day = "Seg"; price = 50.0 },
            [PSCustomObject]@{ id = 12; status = "cancelado"; barber = "Yago Barber"; day = "Seg"; price = 40.0 }
        )

        $counterSales = @(
            [PSCustomObject]@{ item = "Cerveja Heineken"; price = 15.0; qty = 2; total = 30.0 },
            [PSCustomObject]@{ item = "Pomada Modeladora"; price = 45.0; qty = 1; total = 45.0 }
        )

        $costs = @{
            "Café Espresso"      = 1.50
            "Cerveja Heineken"   = 6.00
            "Pomada Matte"       = 18.00
            "Refrigerante"       = 3.00
            "Pomada Modeladora"  = 20.00
        }

        $rates = @{
            "Luis Valverde" = 0.60
            "Yago Barber"   = 0.50
        }

        $dre = Invoke-CalculateDREOracle -Appointments $workloadAppts -CounterSales $counterSales -ProductCosts $costs -BarberCommissionRates $rates -FixedCosts 120.0

        # Calculations breakdown:
        # Completed Services Luis: 60 + 50 + 100 + 60 + 30 = R$ 300.00 -> 60% = R$ 180.00
        # Completed Services Yago: 60 + 50 + 40 = R$ 150.00 -> 50% = R$ 75.00
        # Total Service Revenue: 300 + 150 = R$ 450.00
        # Total Team Commission: 180 + 75 = R$ 255.00
        # Appointment Bar Items: 0 (Café) + 15 (Heineken) + 40 (Pomada) + 8 (Refrigerante) = R$ 63.00
        # Counter Sales: 30 + 45 = R$ 75.00
        # Total Bar Revenue: 63 + 75 = R$ 138.00
        # Gross Revenue: 450 + 138 = R$ 588.00
        # Supplies Cost:
        #   Appts: 1.50 + 6.00 + 18.00 + 3.00 = 28.50
        #   Counter: (6.00 * 2 = 12.00) + 20.00 = 32.00
        #   Total supplies: 28.50 + 32.00 = R$ 60.50
        # Net Profit: 588.00 - 255.00 - 60.50 - 120.00 = R$ 152.50
        # Net Margin: (152.50 / 588.00) * 100 = 25.935% -> ~25.9%

        Assert-Equal -Actual $dre.CompletedApptsCount -Expected 8 -Message "8 completed appointments"
        Assert-Equal -Actual $dre.RevenueServices -Expected 450.0 -Message "Service revenue must be R$ 450.00"
        Assert-Equal -Actual $dre.RevenueBarTotal -Expected 138.0 -Message "Total bar revenue must be R$ 138.00"
        Assert-Equal -Actual $dre.GrossRevenue -Expected 588.0 -Message "Gross revenue must be R$ 588.00"
        Assert-Equal -Actual $dre.CommissionsByBarber["Luis Valverde"] -Expected 180.0 -Message "Luis commission = R$ 180.00"
        Assert-Equal -Actual $dre.CommissionsByBarber["Yago Barber"] -Expected 75.0 -Message "Yago commission = R$ 75.00"
        Assert-Equal -Actual $dre.TotalTeamCommissions -Expected 255.0 -Message "Team commissions = R$ 255.00"
        Assert-Equal -Actual $dre.TotalSuppliesCost -Expected 60.5 -Message "Total supplies cost = R$ 60.50"
        Assert-Equal -Actual $dre.NetProfit -Expected 152.5 -Message "Net profit must be R$ 152.50"
        Assert-ApproxEqual -Actual $dre.NetMarginPercent -Expected 25.9 -Tolerance 0.1 -Message "Net margin must be ~25.9%"
    }

    It "T4.2: Barber WhatsApp Notification Link Generation & Phone Normalization" -Tier 4 -Milestone "M4" {
        function Format-WhatsAppLink {
            param(
                [string]$rawPhone,
                [string]$clientName,
                [string]$serviceName,
                [string]$timeSlot
            )
            $digits = $rawPhone -replace '\D', ''
            if ($digits.Length -eq 10 -or $digits.Length -eq 11) {
                $digits = "55" + $digits
            }
            $msg = "Olá $clientName! Confirmamos seu agendamento no Valverd's BarberShop para $serviceName às $timeSlot."
            $encodedMsg = [System.Net.WebUtility]::UrlEncode($msg)
            return "https://wa.me/${digits}?text=${encodedMsg}"
        }

        $link1 = Format-WhatsAppLink -rawPhone "(24) 99999-8888" -clientName "Carlos" -serviceName "Corte Clássico" -timeSlot "14:30"
        Assert-Match -InputString $link1 -Pattern '^https:\/\/wa\.me\/5524999998888\?text=' -Message "Must produce clean wa.me link with 55 country code"
        Assert-Match -InputString $link1 -Pattern 'Carlos' -Message "URL encoded message should mention client name"

        $link2 = Format-WhatsAppLink -rawPhone "+55 (24) 98888-7777" -clientName "Marcos" -serviceName "Barba" -timeSlot "16:00"
        Assert-Match -InputString $link2 -Pattern '^https:\/\/wa\.me\/5524988887777\?text=' -Message "Should normalize +55 phone number properly"
    }

    It "T4.3: Executive DRE Financial Daily Closeout Accounting Equality Verification" -Tier 4 -Milestone "M4" {
        $appts = @(
            [PSCustomObject]@{ status = "concluido"; barber = "Luis Valverde"; price = 800.0 },
            [PSCustomObject]@{ status = "concluido"; barber = "Yago Barber"; price = 500.0 }
        )
        $sales = @(
            [PSCustomObject]@{ item = "Bar Assortment"; price = 300.0; qty = 1; total = 300.0 }
        )

        $dre = Invoke-CalculateDREOracle -Appointments $appts -CounterSales $sales -DefaultProductCostRatio 0.40 -FixedCosts 200.0

        # Mathematical invariance audit:
        # Gross = Services (1300) + Bar (300) = 1600.00
        # Luis: 800 * 0.6 = 480.00
        # Yago: 500 * 0.5 = 250.00
        # Total Commission: 730.00
        # Supplies: 300 * 0.4 = 120.00
        # Fixed: 200.00
        # Net: 1600 - 730 - 120 - 200 = 550.00
        # Margin: (550 / 1600) * 100 = 34.375% -> 34.4%

        $reconciledNet = $dre.GrossRevenue - $dre.TotalTeamCommissions - $dre.TotalSuppliesCost - $dre.FixedCosts
        Assert-Equal -Actual $dre.NetProfit -Expected $reconciledNet -Message "Net Profit must satisfy exact accounting equality: Gross - Comm - Supplies - Fixed"

        $reconciledMargin = [Math]::Round(($dre.NetProfit / $dre.GrossRevenue) * 100.0, 1)
        Assert-Equal -Actual $dre.NetMarginPercent -Expected $reconciledMargin -Message "Margin % must satisfy exact equality: (NetProfit / Gross) * 100"
    }
}

# End of test_tier4_workloads.ps1
