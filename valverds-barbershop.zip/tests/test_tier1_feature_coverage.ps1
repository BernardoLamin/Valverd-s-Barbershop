# test_tier1_feature_coverage.ps1 — Tier 1: Feature Coverage Test Suite
# Validates Acceptance Criteria for R1, R2, R3, and R4 as specified in ORIGINAL_REQUEST.md and PROJECT.md
param(
    [string]$ProjectRoot = "C:\Users\blaminma\Downloads\valverds-barbershop"
)

. (Join-Path $PSScriptRoot "e2e_test_engine.ps1")
. (Join-Path $PSScriptRoot "helpers\schedule_oracle.ps1")
. (Join-Path $PSScriptRoot "helpers\dre_reference_oracle.ps1")
. (Join-Path $PSScriptRoot "helpers\edge_headless_runner.ps1")

$indexPath = Join-Path $ProjectRoot "index.html"
$indexContent = if (Test-Path $indexPath) { [System.IO.File]::ReadAllText($indexPath, [System.Text.Encoding]::UTF8) } else { "" }

# ==============================================================================
# SUITE 1.1: R1 Luxury Visual Polish, Typography & Responsive Layout
# ==============================================================================
Describe "R1: Luxury Visual Polish & Aesthetics" {

    It "R1.1: Cinzel, Playfair Display, and Plus Jakarta Sans fonts are linked and configured" -Tier 1 -Milestone "M1" {
        Assert-FileExists -Path $indexPath -MinBytes 1000 -Message "index.html must exist"
        Assert-Match -InputString $indexContent -Pattern 'family=Cinzel' -Message "Google Fonts must link Cinzel font"
        Assert-Match -InputString $indexContent -Pattern 'family=Plus\+Jakarta\+Sans' -Message "Google Fonts must link Plus Jakarta Sans font"
        Assert-Match -InputString $indexContent -Pattern "serif:\s*\[['`"]Cinzel['`"]" -Message "tailwind.config must map Cinzel as primary serif font"
        Assert-Match -InputString $indexContent -Pattern "sans:\s*\[['`"]Plus Jakarta Sans['`"]" -Message "tailwind.config must map Plus Jakarta Sans as primary sans font"
    }

    It "R1.2: Gold metallic color palette (#C9A356) and luxury dark theme are defined" -Tier 1 -Milestone "M1" {
        Assert-Match -InputString $indexContent -Pattern '#C9A356' -Message "Primary gold metallic color (#C9A356) must be defined"
        Assert-Match -InputString $indexContent -Pattern "DEFAULT:\s*['`"]#C9A356['`"]" -Message "tailwind.config gold DEFAULT must be #C9A356"
        Assert-Match -InputString $indexContent -Pattern "bg:\s*['`"]#0B0B0B['`"]" -Message "tailwind.config dark.bg must be #0B0B0B"
    }

    It "R1.3: Responsive layout limits max width to 1440px and locks horizontal overflow" -Tier 1 -Milestone "M1" {
        Assert-Match -InputString $indexContent -Pattern 'max-width:\s*1440px' -Message ".app-container or layout must lock max-width to 1440px"
        Assert-Match -InputString $indexContent -Pattern 'overflow-x:\s*hidden' -Message "html, body or #root must enforce overflow-x: hidden"
    }

    It "R1.4: All 18 local photographic assets referenced in code exist on disk" -Tier 1 -Milestone "M1" {
        $requiredAssets = @(
            "logo_valverds_clean.png",
            "barbeiro_valverds.jpg",
            "foto_atendimento_salao.jpg",
            "foto_barbeiro_yago.jpg",
            "luis_valverde.jpg",
            "foto_letreiro_frontal.jpg",
            "foto_letreiro_neon.jpg",
            "foto_lounge_espera.jpg",
            "foto_estacao_cafe.jpg",
            "foto_cafe_maquina.jpg",
            "foto_corte_fade.jpg",
            "foto_corte_taper.jpg",
            "foto_corte_tesoura.jpg",
            "foto_corte_navalha_barba.jpg",
            "foto_corte_kids.jpg",
            "foto_maquina_jrl.jpg",
            "foto_produtos_reais.jpg",
            "espaco_interior_1.png"
        )

        foreach ($assetName in $requiredAssets) {
            $assetPath = Join-Path $ProjectRoot $assetName
            Assert-FileExists -Path $assetPath -MinBytes 5000 -Message "Asset $assetName must exist and be valid"
        }
    }

    It "R1.5: Photo carousel contains slide counter (01/09), vector arrows, and autoplay logic" -Tier 1 -Milestone "M1" {
        Assert-Match -InputString $indexContent -Pattern 'GALLERY_SLIDES' -Message "GALLERY_SLIDES array must be defined"
        Assert-Match -InputString $indexContent -Pattern '(01\s*/\s*09|slideCounter|currentSlide\s*\+\s*1)' -Message "Photo carousel must feature slide counter"
        Assert-Match -InputString $indexContent -Pattern '(ChevronLeft|ChevronRight|chevron-left|chevron-right)' -Message "Carousel navigation must use vector arrows"
    }

    It "R1.6: Client role navigation bug is fixed (setClientTab('agendamentos') eliminated)" -Tier 1 -Milestone "M1" {
        Assert-NotMatch -InputString $indexContent -Pattern "setClientTab\(['`"]agendamentos['`"]\)" -Message "Defective call setClientTab('agendamentos') must be eliminated to prevent white screen"
        Assert-Match -InputString $indexContent -Pattern "setClientTab\(['`"]agendar['`"]\)" -Message "Client role switch must navigate to 'agendar'"
    }
}

# ==============================================================================
# SUITE 1.2: R2 Dark Mode & Clean Mode Theme System
# ==============================================================================
Describe "R2: Dark Mode & Clean Mode Theme System" {

    It "R2.1: valverds_theme state and localStorage synchronization contract" -Tier 1 -Milestone "M2" {
        Assert-Match -InputString $indexContent -Pattern "['`"]valverds_theme['`"]" -Message "Theme must use 'valverds_theme' localStorage key"
        Assert-Match -InputString $indexContent -Pattern "localStorage\.getItem\(['`"]valverds_theme['`"]\)" -Message "Theme must read from localStorage"
        Assert-Match -InputString $indexContent -Pattern "localStorage\.setItem\(['`"]valverds_theme['`"]" -Message "Theme must persist to localStorage"
    }

    It "R2.2: html.clean-mode CSS root class rules define editorial light theme" -Tier 1 -Milestone "M2" {
        Assert-Match -InputString $indexContent -Pattern "\.clean-mode" -Message "CSS must define .clean-mode rules"
        Assert-Match -InputString $indexContent -Pattern "(#F8F9FA|bg-gray-50)" -Message "Clean mode must specify editorial background #F8F9FA"
        Assert-Match -InputString $indexContent -Pattern "(#FFFFFF|bg-white)" -Message "Clean mode must specify pure white cards #FFFFFF"
    }

    It "R2.3: 1-Click Sun/Moon Theme Toggle is accessible across all 5 views" -Tier 1 -Milestone "M2" {
        Assert-Match -InputString $indexContent -Pattern '(toggleTheme|setTheme)' -Message "Theme toggle handler must be implemented"
        Assert-Match -InputString $indexContent -Pattern 'Sun' -Message "Sun icon component must be available for theme toggle"
        Assert-Match -InputString $indexContent -Pattern 'Moon' -Message "Moon icon component must be available for theme toggle"
    }
}

# ==============================================================================
# SUITE 1.3: R3 48-Slot Universal Schedule Grid & 5-Step Booking Flow
# ==============================================================================
Describe "R3: 48-Slot Schedule Grid & 5-Step Booking Flow" {

    It "R3.1: 48 30-minute universal slots (00:00 to 23:30) are defined" -Tier 1 -Milestone "M3" {
        Assert-Match -InputString $indexContent -Pattern 'ALL_48_TIME_SLOTS' -Message "ALL_48_TIME_SLOTS constant must be declared"
        Assert-Match -InputString $indexContent -Pattern "00:00" -Message "Schedule grid must start at 00:00"
        Assert-Match -InputString $indexContent -Pattern "23:30" -Message "Schedule grid must extend to 23:30"

        $oracleSlots = Get-All48TimeSlotsOracle
        Assert-Equal -Actual $oracleSlots.Count -Expected 48 -Message "Schedule oracle confirms exactly 48 blocks in a 24h cycle"
    }

    It "R3.2: Dynamic custom slot insertion and chronological deduplication" -Tier 1 -Milestone "M3" {
        Assert-Match -InputString $indexContent -Pattern '(customSlot|customTime|customSlots)' -Message "Custom slot mechanism must be present in scheduling logic"
        
        # Test merging logic against reference oracle
        $base = @("08:00", "08:30", "09:00")
        $custom = @("08:15", "08:30", "19:40")
        $merged = Get-MergedSlotsOracle -BaseSlots $base -CustomSlots $custom
        
        Assert-Equal -Actual $merged.Count -Expected 5 -Message "Duplicate 08:30 must be deduplicated"
        Assert-Equal -Actual $merged[1] -Expected "08:15" -Message "08:15 must be inserted chronologically between 08:00 and 08:30"
        Assert-Equal -Actual $merged[4] -Expected "19:40" -Message "19:40 must be sorted at the end"
    }

    It "R3.3: 5-step guided booking flow (Barber -> Service+Bar -> Day -> Time -> Client Info)" -Tier 1 -Milestone "M3" {
        Assert-Match -InputString $indexContent -Pattern '(bookingStep|step\s*===|Stepper)' -Message "5-step booking flow navigation state must exist"
        Assert-Match -InputString $indexContent -Pattern '(products_bar|items.*bar|extra.*bar)' -Message "Step 2 must incorporate Bar items"
        Assert-Match -InputString $indexContent -Pattern '(toast|Toast|toastNotification)' -Message "Confirmation toast notification must be provided upon booking"
    }

    It "R3.4: Client calendar respects strict privacy (no third-party customer names exposed)" -Tier 1 -Milestone "M3" {
        Assert-Match -InputString $indexContent -Pattern "calendario_geral" -Message "calendario_geral view must be present"
        Assert-Match -InputString $indexContent -Pattern '(vagas|livres|dispon|Ocupado)' -Message "Client view should display vacancies/occupancy without personal names"
    }
}

# ==============================================================================
# SUITE 1.4: R4 Executive Management, DRE & Neon PostgreSQL
# ==============================================================================
Describe "R4: Executive Management, DRE & Neon PostgreSQL" {

    It "R4.1: DRE mathematical formulas separate Services from Bar and calculate commissions" -Tier 1 -Milestone "M4" {
        Assert-Match -InputString $indexContent -Pattern 'revenueServices' -Message "DRE must track revenueServices"
        Assert-Match -InputString $indexContent -Pattern '(revenueBar|revenueBalcao)' -Message "DRE must track bar and counter revenue"
        Assert-Match -InputString $indexContent -Pattern '60' -Message "Luis commission rate must be 60%"
        Assert-Match -InputString $indexContent -Pattern '50' -Message "Yago commission rate must be 50%"
        Assert-Match -InputString $indexContent -Pattern 'netProfit' -Message "DRE must calculate net profit"
        Assert-Match -InputString $indexContent -Pattern 'marginPercent' -Message "DRE must calculate net margin percentage"
    }

    It "R4.2: Barber WhatsApp links (wa.me) and daily shift configuration" -Tier 1 -Milestone "M4" {
        Assert-Match -InputString $indexContent -Pattern 'wa\.me' -Message "Barber view must generate direct wa.me WhatsApp contact links"
        Assert-Match -InputString $indexContent -Pattern '(dailyBarberSettings|minha_escala|workSchedule)' -Message "Barber daily shift configuration must be present"
    }

    It "R4.3: Reception multi-chair view, barber CRUD, and inventory quick controls" -Tier 1 -Milestone "M4" {
        Assert-Match -InputString $indexContent -Pattern '(Recepcao|recepcao)' -Message "Reception view must exist"
        Assert-Match -InputString $indexContent -Pattern '(adjustStock|stock.*\+|stock.*-)' -Message "Quick inventory stock adjustments (+/-) must be available"
    }

    It "R4.4: Neon PostgreSQL environment configuration and schema definitions" -Tier 1 -Milestone "M4" {
        $envPath = Join-Path $ProjectRoot ".env"
        $schemaPath = Join-Path $ProjectRoot "database\schema.sql"
        $seedPath = Join-Path $ProjectRoot "database\seed.sql"

        Assert-FileExists -Path $schemaPath -MinBytes 500 -Message "database/schema.sql must exist"
        Assert-FileExists -Path $seedPath -MinBytes 200 -Message "database/seed.sql must exist"

        $schemaContent = [System.IO.File]::ReadAllText($schemaPath, [System.Text.Encoding]::UTF8)
        Assert-Match -InputString $schemaContent -Pattern "CREATE TABLE.*barbers" -Message "schema.sql must create barbers table"
        Assert-Match -InputString $schemaContent -Pattern "CREATE TABLE.*appointments" -Message "schema.sql must create appointments table"
        Assert-Match -InputString $schemaContent -Pattern "CREATE TABLE.*products" -Message "schema.sql must create products table"
        Assert-Match -InputString $schemaContent -Pattern "CREATE TABLE.*(financial_transactions|financial_records)" -Message "schema.sql must create financial transactions/records table"

        $seedContent = [System.IO.File]::ReadAllText($seedPath, [System.Text.Encoding]::UTF8)
        Assert-Match -InputString $seedContent -Pattern "Luis Valverde" -Message "seed.sql must insert Luis Valverde"
        Assert-Match -InputString $seedContent -Pattern "Yago Barber" -Message "seed.sql must insert Yago Barber"
        Assert-Match -InputString $seedContent -Pattern "60" -Message "Luis commission rate 60 must be seeded"
        Assert-Match -InputString $seedContent -Pattern "50" -Message "Yago commission rate 50 must be seeded"

        if (Test-Path $envPath) {
            $envContent = [System.IO.File]::ReadAllText($envPath, [System.Text.Encoding]::UTF8)
            Assert-Match -InputString $envContent -Pattern "DATABASE_URL=" -Message ".env must define DATABASE_URL"
            Assert-Match -InputString $envContent -Pattern "sa-east-1\.aws\.neon\.tech" -Message ".env must point to official Neon host in sa-east-1"
        }
    }
}

# End of test_tier1_feature_coverage.ps1
