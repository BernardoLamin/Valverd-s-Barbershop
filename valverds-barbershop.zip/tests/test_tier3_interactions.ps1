# test_tier3_interactions.ps1 — Tier 3: Cross-Feature Interactions Test Suite
# Tests interconnected subsystems: Bookings with bar items + Theme toggles + DRE revenue splits + State persistence
param(
    [string]$ProjectRoot = "C:\Users\blaminma\Downloads\valverds-barbershop"
)

. (Join-Path $PSScriptRoot "e2e_test_engine.ps1")
. (Join-Path $PSScriptRoot "helpers\schedule_oracle.ps1")
. (Join-Path $PSScriptRoot "helpers\dre_reference_oracle.ps1")
. (Join-Path $PSScriptRoot "helpers\edge_headless_runner.ps1")

$indexPath = Join-Path $ProjectRoot "index.html"
$indexContent = if (Test-Path $indexPath) { [System.IO.File]::ReadAllText($indexPath, [System.Text.Encoding]::UTF8) } else { "" }

Describe "Tier 3: Cross-Feature Multi-Subsystem Interactions" {

    It "T3.1: Booking with Bar Items + Theme Change + DRE Revenue & Commission Separation" -Tier 3 -Milestone "M4" {
        # Scenario:
        # 1. Customer books Haircut (R$ 60.00) + 2x Heineken (R$ 12.00 ea = R$ 24.00) with Luis Valverde (60% commission rate).
        # Total transaction = R$ 84.00.
        # Unit cost for Heineken = R$ 5.00 each (Total cost = R$ 10.00).
        # 2. System theme is switched to 'clean'.
        # 3. Dono DRE calculates:
        #    Gross Revenue: R$ 84.00
        #    Service Revenue: R$ 60.00
        #    Bar Revenue: R$ 24.00
        #    Luis Commission: 60% of R$ 60.00 = R$ 36.00 (MUST NOT BE 60% of R$ 84.00 which would be R$ 50.40)
        #    Supplies Cost: R$ 10.00
        #    Net Profit: 84.00 - 36.00 - 10.00 = R$ 38.00
        #    Net Margin: (38.00 / 84.00) * 100 = 45.2%

        $appts = @(
            [PSCustomObject]@{
                status = "concluido"
                barber = "Luis Valverde"
                day    = "Seg"
                items  = @(
                    [PSCustomObject]@{ name = "Corte Clássico Valverde"; price = 60.0; type = "service" },
                    [PSCustomObject]@{ name = "Cerveja Heineken"; price = 12.0; type = "bar" },
                    [PSCustomObject]@{ name = "Cerveja Heineken"; price = 12.0; type = "bar" }
                )
            }
        )

        $productCosts = @{
            "Cerveja Heineken" = 5.0
        }

        $rates = @{
            "Luis Valverde" = 0.60
            "Yago Barber"   = 0.50
        }

        $dre = Invoke-CalculateDREOracle -Appointments $appts -ProductCosts $productCosts -BarberCommissionRates $rates -FixedCosts 0.0

        Assert-Equal -Actual $dre.GrossRevenue -Expected 84.0 -Message "Gross revenue must be R$ 84.00"
        Assert-Equal -Actual $dre.RevenueServices -Expected 60.0 -Message "Service revenue must be strictly R$ 60.00"
        Assert-Equal -Actual $dre.RevenueBarTotal -Expected 24.0 -Message "Bar revenue must be strictly R$ 24.00"
        Assert-Equal -Actual $dre.CommissionsByBarber["Luis Valverde"] -Expected 36.0 -Message "Luis commission must be 60% of R$ 60.00 = R$ 36.00"
        Assert-NotEqual -Actual $dre.CommissionsByBarber["Luis Valverde"] -Expected 50.4 -Message "Luis commission must NOT be 60% of total (R$ 50.40)"
        Assert-Equal -Actual $dre.TotalSuppliesCost -Expected 10.0 -Message "Product costs must be 2 x R$ 5.00 = R$ 10.00"
        Assert-Equal -Actual $dre.NetProfit -Expected 38.0 -Message "Net profit must be R$ 38.00"
        Assert-ApproxEqual -Actual $dre.NetMarginPercent -Expected 45.2 -Tolerance 0.1 -Message "Net margin must be ~45.2%"
    }

    It "T3.2: Theme state persistence across role transitions (Site -> Cliente -> Barbeiro -> Recepção -> Dono)" -Tier 3 -Milestone "M2" {
        # Verify in index.html that clean-mode class toggle is global on document.documentElement
        # and not scoped to an individual role view.
        Assert-Match -InputString $indexContent -Pattern "(classList\.toggle\(['`"]clean-mode['`"]|classList\.add\(['`"]clean-mode['`"]\))" -Message "clean-mode class must be applied to document element"
        Assert-Match -InputString $indexContent -Pattern "localStorage\.setItem\(['`"]valverds_theme['`"]" -Message "Theme change must write to localStorage"

        # Contract assertion: The theme toggle must be in the universal header or accessible from every role
        Assert-Match -InputString $indexContent -Pattern "(toggleTheme|valverds_theme)" -Message "Theme management state must be present"
    }

    It "T3.3: Counter Sales + Appointment Bar Sales Consolidation in DRE" -Tier 3 -Milestone "M4" {
        # Scenario:
        # Appointment with Luis has R$ 30.00 bar items (service R$ 70.00).
        # Counter sale at reception has R$ 50.00 bar items.
        # Total Bar Revenue must equal R$ 80.00.
        # Barber commission on entire R$ 80.00 bar revenue must be R$ 0.00.
        $appts = @(
            [PSCustomObject]@{
                status = "concluido"
                barber = "Luis Valverde"
                items  = @(
                    [PSCustomObject]@{ name = "Corte & Barba VIP"; price = 70.0; type = "service" },
                    [PSCustomObject]@{ name = "Pomada Efeito Seco"; price = 30.0; type = "bar" }
                )
            }
        )
        $counterSales = @(
            [PSCustomObject]@{ item = "Cerveja Artesanal"; price = 25.0; qty = 2; total = 50.0 }
        )

        $dre = Invoke-CalculateDREOracle -Appointments $appts -CounterSales $counterSales -FixedCosts 0.0
        Assert-Equal -Actual $dre.GrossRevenue -Expected 150.0 -Message "Gross revenue should be 70 + 30 + 50 = 150.0"
        Assert-Equal -Actual $dre.RevenueServices -Expected 70.0 -Message "Service revenue must be 70.0"
        Assert-Equal -Actual $dre.RevenueAppointmentBar -Expected 30.0 -Message "Appointment bar revenue must be 30.0"
        Assert-Equal -Actual $dre.RevenueBalcao -Expected 50.0 -Message "Counter bar revenue must be 50.0"
        Assert-Equal -Actual $dre.RevenueBarTotal -Expected 80.0 -Message "Consolidated bar revenue must be 80.0"
        Assert-Equal -Actual $dre.TotalTeamCommissions -Expected 42.0 -Message "Commissions strictly on service: 60% of 70 = 42.0"
    }

    It "T3.4: Dynamic Shift Alteration Affects Booking Availability Matrix" -Tier 3 -Milestone "M3" {
        # Base 48 slots
        $allSlots = Get-All48TimeSlotsOracle

        # Barber shift from 11:00 to 18:00
        $shiftStart = "11:00"
        $shiftEnd = "18:00"
        $shiftSlots = $allSlots | Where-Object { $_ -ge $shiftStart -and $_ -lt $shiftEnd }

        Assert-Contains -Collection $shiftSlots -Item "11:00" -Message "11:00 must be in shift"
        Assert-Contains -Collection $shiftSlots -Item "17:30" -Message "17:30 must be in shift"
        Assert-False -Condition ($shiftSlots -contains "09:00") -Message "09:00 must NOT be in shift"
        Assert-False -Condition ($shiftSlots -contains "10:30") -Message "10:30 must NOT be in shift"
        Assert-False -Condition ($shiftSlots -contains "18:30") -Message "18:30 must NOT be in shift"

        # Now add custom late appointment slot at 19:40
        $customSlots = @("19:40")
        $finalAvailable = Get-MergedSlotsOracle -BaseSlots $shiftSlots -CustomSlots $customSlots

        Assert-Contains -Collection $finalAvailable -Item "19:40" -Message "19:40 must be incorporated into active availability"
        Assert-Equal -Actual $finalAvailable[$finalAvailable.Count - 1] -Expected "19:40" -Message "19:40 must be the last slot"
    }
}

# End of test_tier3_interactions.ps1
