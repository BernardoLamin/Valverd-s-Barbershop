# test_tier2_boundaries.ps1 — Tier 2: Boundary & Corner Cases Test Suite
# Tests extreme values, edge slots, format anomalies, zero revenue, and empty collections.
param(
    [string]$ProjectRoot = "C:\Users\blaminma\Downloads\valverds-barbershop"
)

. (Join-Path $PSScriptRoot "e2e_test_engine.ps1")
. (Join-Path $PSScriptRoot "helpers\schedule_oracle.ps1")
. (Join-Path $PSScriptRoot "helpers\dre_reference_oracle.ps1")
. (Join-Path $PSScriptRoot "helpers\edge_headless_runner.ps1")

# ==============================================================================
# SUITE 2.1: Schedule Boundary & Slot Edge Cases
# ==============================================================================
Describe "Tier 2: Schedule & Time Boundary Conditions" {

    It "T2.1: Boundary slots 00:00 and 23:30 exist at exact array extremes" -Tier 2 -Milestone "M3" {
        $slots = Get-All48TimeSlotsOracle
        Assert-Equal -Actual $slots.Count -Expected 48 -Message "Exactly 48 slots required"
        Assert-Equal -Actual $slots[0] -Expected "00:00" -Message "Slot 0 must be 00:00"
        Assert-Equal -Actual $slots[47] -Expected "23:30" -Message "Slot 47 must be 23:30"

        # Verify all slots strictly follow 30-min step
        for ($i = 0; $i -lt 47; $i++) {
            $currParts = $slots[$i].Split(':') | ForEach-Object { [int]$_ }
            $nextParts = $slots[$i + 1].Split(':') | ForEach-Object { [int]$_ }
            $currTotalMin = ($currParts[0] * 60) + $currParts[1]
            $nextTotalMin = ($nextParts[0] * 60) + $nextParts[1]
            Assert-Equal -Actual ($nextTotalMin - $currTotalMin) -Expected 30 -Message "Step between $($slots[$i]) and $($slots[$i+1]) must be exactly 30 minutes"
        }
    }

    It "T2.2: Time format validator strictly accepts HH:mm and rejects malformed inputs" -Tier 2 -Milestone "M3" {
        # Valid test vectors
        $validTimes = @("00:00", "08:15", "09:30", "12:00", "19:40", "23:30", "23:59")
        foreach ($vt in $validTimes) {
            $isValid = Test-ValidTimeFormatOracle -TimeStr $vt
            Assert-True -Condition $isValid -Message "Time '$vt' should be recognized as valid"
        }

        # Invalid test vectors (out-of-range hours, out-of-range minutes, letters, blanks, missing leading zeros)
        $invalidTimes = @("24:00", "25:00", "12:60", "8:15", "08:5", "08-15", "abc", "", "   ", "12:00:00", "-01:00")
        foreach ($it in $invalidTimes) {
            $isValid = Test-ValidTimeFormatOracle -TimeStr $it
            Assert-False -Condition $isValid -Message "Time '$it' must be rejected as invalid"
        }
    }

    It "T2.3: Idempotent deduplication when custom slot matches existing base slot" -Tier 2 -Milestone "M3" {
        $base = @("00:00", "09:00", "09:30", "10:00", "23:30")
        # Try adding 09:00 (exact match) and 09:00 with leading/trailing spaces
        $custom = @("09:00", " 09:00 ")
        $merged = Get-MergedSlotsOracle -BaseSlots $base -CustomSlots $custom

        Assert-Equal -Actual $merged.Count -Expected 5 -Message "Duplicate 09:00 must be collapsed"
        $count0900 = ($merged | Where-Object { $_ -eq "09:00" }).Count
        Assert-Equal -Actual $count0900 -Expected 1 -Message "09:00 must occur exactly once"
    }
}

# ==============================================================================
# SUITE 2.2: Financial & DRE Boundary Cases
# ==============================================================================
Describe "Tier 2: Financial & DRE Extreme Scenarios" {

    It "T2.4: Zero Gross Revenue edge case safely produces 0.0% margin without NaN or division by zero" -Tier 2 -Milestone "M4" {
        $dre = Invoke-CalculateDREOracle -Appointments @() -CounterSales @() -FixedCosts 150.0

        Assert-Equal -Actual $dre.GrossRevenue -Expected 0.0 -Message "Gross revenue should be 0.0"
        Assert-Equal -Actual $dre.TotalTeamCommissions -Expected 0.0 -Message "Commissions should be 0.0"
        Assert-Equal -Actual $dre.TotalSuppliesCost -Expected 0.0 -Message "Supplies cost should be 0.0"
        Assert-Equal -Actual $dre.NetProfit -Expected -150.0 -Message "Net profit should equal -fixedCosts"
        Assert-Equal -Actual $dre.NetMarginPercent -Expected 0.0 -Message "Net margin percent should safely be 0.0% (not NaN or Infinity)"
        Assert-False -Condition ([double]::IsNaN($dre.NetMarginPercent)) -Message "Net margin percent must not be NaN"
        Assert-False -Condition ([double]::IsInfinity($dre.NetMarginPercent)) -Message "Net margin percent must not be Infinity"
    }

    It "T2.5: 100% and 0% commission rates calculate correctly without overflow" -Tier 2 -Milestone "M4" {
        $appts = @(
            [PSCustomObject]@{ status = "concluido"; barber = "Luis Valverde"; price = 100.0 },
            [PSCustomObject]@{ status = "concluido"; barber = "Volunteer Barber"; price = 100.0 }
        )
        $rates = @{
            "Luis Valverde"    = 1.00 # 100% commission
            "Volunteer Barber" = 0.00 # 0% commission
        }

        $dre = Invoke-CalculateDREOracle -Appointments $appts -BarberCommissionRates $rates -FixedCosts 0.0
        Assert-Equal -Actual $dre.GrossRevenue -Expected 200.0 -Message "Gross revenue should be 200.0"
        Assert-Equal -Actual $dre.CommissionsByBarber["Luis Valverde"] -Expected 100.0 -Message "100% commission should yield exact service price"
        Assert-Equal -Actual $dre.CommissionsByBarber["Volunteer Barber"] -Expected 0.0 -Message "0% commission should yield 0.0"
        Assert-Equal -Actual $dre.TotalTeamCommissions -Expected 100.0 -Message "Total team commissions should be 100.0"
    }

    It "T2.6: Missing product cost gracefully applies default CMV ratio without error" -Tier 2 -Milestone "M4" {
        $sales = @(
            [PSCustomObject]@{ item = "Produto Sem Custo Cadastrado"; price = 80.0; qty = 1; total = 80.0 }
        )
        # Empty ProductCosts hashtable to test fallback ratio (45%)
        $dre = Invoke-CalculateDREOracle -CounterSales $sales -ProductCosts @{} -DefaultProductCostRatio 0.45

        Assert-Equal -Actual $dre.GrossRevenue -Expected 80.0 -Message "Gross revenue should be 80.0"
        # 45% of 80.0 = 36.0
        Assert-Equal -Actual $dre.TotalSuppliesCost -Expected 36.0 -Message "Fallback product cost should be 45% of sale price (36.0)"
        Assert-Equal -Actual $dre.NetProfit -Expected 44.0 -Message "Net profit should be 80.0 - 36.0 = 44.0"
    }

    It "T2.7: Appointment with only bar items (no haircut) generates 0% barber commission" -Tier 2 -Milestone "M4" {
        $appts = @(
            [PSCustomObject]@{
                status = "concluido"
                barber = "Luis Valverde"
                items  = @(
                    [PSCustomObject]@{ name = "Cerveja Heineken"; price = 15.0; type = "bar" },
                    [PSCustomObject]@{ name = "Café Espresso"; price = 0.0; type = "bar" }
                )
            }
        )

        $dre = Invoke-CalculateDREOracle -Appointments $appts
        Assert-Equal -Actual $dre.RevenueServices -Expected 0.0 -Message "Revenue from services must be 0.0"
        Assert-Equal -Actual $dre.RevenueBarTotal -Expected 15.0 -Message "Revenue from bar must be 15.0"
        Assert-Equal -Actual $dre.TotalTeamCommissions -Expected 0.0 -Message "Barber must receive 0 commission on bar-only appointment"
    }

    It "T2.8: High volume stress test (500 appointments) maintains penny accuracy" -Tier 2 -Milestone "M4" {
        $largeAppts = [System.Collections.Generic.List[PSCustomObject]]::new()
        for ($i = 0; $i -lt 500; $i++) {
            $b = if ($i % 2 -eq 0) { "Luis Valverde" } else { "Yago Barber" }
            $p = if ($i % 3 -eq 0) { 70.0 } elseif ($i % 3 -eq 1) { 50.0 } else { 90.0 }
            $largeAppts.Add([PSCustomObject]@{
                status = "concluido"
                barber = $b
                price  = $p
            })
        }

        $dre = Invoke-CalculateDREOracle -Appointments $largeAppts.ToArray() -FixedCosts 500.0
        Assert-True -Condition ($dre.GrossRevenue -gt 30000.0) -Message "High volume gross revenue should exceed R$ 30,000"
        Assert-True -Condition ($dre.NetProfit -gt 0.0) -Message "Net profit should remain positive"
        Assert-True -Condition ($dre.NetMarginPercent -gt 0.0 -and $dre.NetMarginPercent -le 100.0) -Message "Margin percent should be between 0% and 100%"
    }
}

# End of test_tier2_boundaries.ps1
