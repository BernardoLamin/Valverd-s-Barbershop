-- ==============================================================================
-- VALVERD'S BARBERSHOP — DADOS INICIAIS (SEED ATUALIZADO)
-- "Beard, hair and mustache" — Desde 2022
-- ==============================================================================

-- 1. USUÁRIOS
INSERT INTO users (id, name, email, password_hash, role, phone) VALUES
('a0000001-0000-0000-0000-000000000001', 'Carlos "Navalha" Valverd', 'carlos@valverds.com.br', '$2a$12$DonoHashValverds2022SecureKey', 'admin', '(11) 98765-4321'),
('a0000001-0000-0000-0000-000000000002', 'Matheus Ribeiro', 'matheus@valverds.com.br', '$2a$12$Barber2HashValverds2022SecureKey', 'barber', '(11) 98111-2233'),
('a0000001-0000-0000-0000-000000000003', 'Diego Silveira', 'diego@valverds.com.br', '$2a$12$Barber3HashValverds2022SecureKey', 'barber', '(11) 97333-4455'),
('a0000001-0000-0000-0000-000000000004', 'Lucas Brandão (VIP)', 'lucas.brandao@email.com', '$2a$12$ClientHashValverds2022SecureKey', 'client', '(11) 99881-2200');

-- 2. BARBEIROS
INSERT INTO barbers (id, user_id, nickname, specialties, contract_type, default_commission_rate, rating) VALUES
('b0000001-0000-0000-0000-000000000001', 'a0000001-0000-0000-0000-000000000001', 'Carlos Navalha', ARRAY['Cortes Clássicos', 'Fade Perfeito', 'Visagismo'], 'COMISSIONADO', 60.00, 4.98),
('b0000001-0000-0000-0000-000000000002', 'a0000001-0000-0000-0000-000000000002', 'Matheus Ribeiro', ARRAY['Barba Terapia', 'Platinado', 'Freestyle'], 'COMISSIONADO', 50.00, 4.92),
('b0000001-0000-0000-0000-000000000003', 'a0000001-0000-0000-0000-000000000003', 'Diego Silveira', ARRAY['Degradê Navalhado', 'Sobrancelha', 'Barba Modelada'], 'COMISSIONADO', 50.00, 4.88);

-- 3. SERVIÇOS
INSERT INTO services (id, name, description, duration_minutes, price, custom_commission_rate, category) VALUES
('s0000001-0000-0000-0000-000000000001', 'Corte Tradicional Classic', 'Corte clássico com acabamento na navalha', 40, 55.00, 50.00, 'Cabelo'),
('s0000001-0000-0000-0000-000000000002', 'Barba Terapia com Toalha Quente', 'Toalha quente com óleos essenciais e navalha afiada', 35, 45.00, 50.00, 'Barba'),
('s0000001-0000-0000-0000-000000000003', 'Combo Supreme (Corte + Barba)', 'A experiência completa: corte + barba terapia', 65, 90.00, 55.00, 'Combo'),
('s0000001-0000-0000-0000-000000000004', 'Design de Sobrancelha na Navalha', 'Alinhamento com navalhete', 15, 25.00, 50.00, 'Estética'),
('s0000001-0000-0000-0000-000000000005', 'Pigmentação de Barba & Camuflagem', 'Disfarce natural dos fios brancos', 45, 60.00, 50.00, 'Barba'),
('s0000001-0000-0000-0000-000000000006', 'Selagem / Alinhamento Capilar', 'Tratamento e redução de volume capilar', 60, 110.00, 45.00, 'Tratamento');

-- 4. CLIENTES
INSERT INTO clients (id, user_id, name, phone, email, preferences, loyalty_points, total_visits) VALUES
('c0000001-0000-0000-0000-000000000001', 'a0000001-0000-0000-0000-000000000004', 'Lucas Brandão', '(11) 99881-2200', 'lucas.brandao@email.com', 'Degradê na zero alta, acabamento em V atrás, costeleta quadrada.', 8, 14),
('c0000001-0000-0000-0000-000000000002', NULL, 'Gabriel Siqueira', '(11) 98555-1212', 'gabriel.s@email.com', 'Usa apenas tesoura no topo, pomada efeito seco matte.', 4, 6),
('c0000001-0000-0000-0000-000000000003', NULL, 'Rodrigo Alcantara', '(11) 97123-9988', 'rodrigo.al@email.com', 'Pele sensível no pescoço, aplicar loção pós-barba calmante.', 9, 22);

-- 5. ESTOQUE DE PRODUTOS (REVENDA E USO INTERNO)
INSERT INTO products (id, name, category, current_quantity, minimum_quantity, cost_price, sale_price) VALUES
('p0000001-0000-0000-0000-000000000001', 'Pomada Matte Efeito Seco 120g', 'resale', 18, 10, 22.00, 48.00),
('p0000001-0000-0000-0000-000000000002', 'Óleo Hidratante de Barba Amadeirado 30ml', 'resale', 4, 8, 18.00, 42.00),
('p0000001-0000-0000-0000-000000000003', 'Lâminas Platinum Derby (Caixa c/ 100)', 'internal_use', 3, 5, 35.00, 0.00),
('p0000001-0000-0000-0000-000000000004', 'Shampoo Anticaspa Valverd’s 250ml', 'resale', 12, 8, 19.00, 39.00),
('p0000001-0000-0000-0000-000000000005', 'Espuma / Gel de Barbear Fresh 1kg', 'internal_use', 2, 3, 42.00, 0.00),
('p0000001-0000-0000-0000-000000000006', 'Gola Higiênica Rolo (5 rolos)', 'internal_use', 6, 4, 28.00, 0.00);
