-- ==============================================================================
-- VALVERD'S BARBERSHOP — ESTRUTURA DO BANCO DE DADOS (PostgreSQL / Relacional)
-- "Beard, hair and mustache" — Desde 2022
-- ==============================================================================

-- Habilita extensão para UUID (se aplicável)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ------------------------------------------------------------------------------
-- 1. TABELA DE USUÁRIOS E AUTENTICAÇÃO (RBAC)
-- ------------------------------------------------------------------------------
CREATE TYPE user_role AS ENUM ('admin', 'manager', 'barber', 'receptionist', 'client');

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role user_role NOT NULL DEFAULT 'client',
    phone VARCHAR(20),
    avatar_url VARCHAR(255),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------------------------
-- 2. TABELA DE BARBEIROS (PROFISSIONAIS)
-- ------------------------------------------------------------------------------
CREATE TYPE contract_type_enum AS ENUM ('MEI', 'CLT', 'COMISSIONADO');

CREATE TABLE barbers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    nickname VARCHAR(50),
    specialties TEXT[], -- ex: {'Degradê Navalhado', 'Barboterapia', 'Pigmentação'}
    contract_type contract_type_enum NOT NULL DEFAULT 'COMISSIONADO',
    default_commission_rate NUMERIC(5, 2) NOT NULL DEFAULT 50.00, -- percentual (ex: 50%)
    rating NUMERIC(3, 2) DEFAULT 5.00,
    start_date DATE NOT NULL DEFAULT CURRENT_DATE,
    working_days JSONB DEFAULT '["seg", "ter", "qua", "qui", "sex", "sab"]'::jsonb,
    working_hours JSONB DEFAULT '{"start": "09:00", "end": "20:00", "break_start": "12:00", "break_end": "13:00"}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------------------------
-- 3. TABELA DE CLIENTES
-- ------------------------------------------------------------------------------
CREATE TABLE clients (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    name VARCHAR(150) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(150),
    birth_date DATE,
    preferences TEXT, -- ex: "Prefere lâmina descartável, café expresso, degradê número 1"
    loyalty_points INT DEFAULT 0, -- pontos acumulados
    total_visits INT DEFAULT 0,
    preferred_barber_id UUID REFERENCES barbers(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_clients_phone ON clients(phone);
CREATE INDEX idx_clients_name ON clients(name);

-- ------------------------------------------------------------------------------
-- 4. TABELA DE SERVIÇOS
-- ------------------------------------------------------------------------------
CREATE TABLE services (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    duration_minutes INT NOT NULL DEFAULT 30,
    price NUMERIC(10, 2) NOT NULL,
    custom_commission_rate NUMERIC(5, 2), -- Se nulo, usa a taxa padrão do barbeiro
    category VARCHAR(50) DEFAULT 'Cabelo', -- Cabelo, Barba, Combo, Estética
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------------------------
-- 5. TABELA DE AGENDAMENTOS
-- ------------------------------------------------------------------------------
CREATE TYPE appointment_status_enum AS ENUM (
    'scheduled',    -- Agendado
    'confirmed',    -- Confirmado
    'in_progress',  -- Em atendimento
    'completed',    -- Concluído (gerou receita)
    'cancelled',    -- Cancelado
    'no_show'       -- Não compareceu
);

CREATE TABLE appointments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    barber_id UUID NOT NULL REFERENCES barbers(id) ON DELETE RESTRICT,
    service_id UUID NOT NULL REFERENCES services(id) ON DELETE RESTRICT,
    appointment_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    status appointment_status_enum NOT NULL DEFAULT 'scheduled',
    notes TEXT,
    cancellation_reason TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Restrição de integridade para evitar sobreposições no mesmo barbeiro
    CONSTRAINT check_time_order CHECK (start_time < end_time)
);

CREATE INDEX idx_appointments_date_barber ON appointments(appointment_date, barber_id);
CREATE INDEX idx_appointments_status ON appointments(status);

-- ------------------------------------------------------------------------------
-- 6. TABELA DE TRANSAÇÕES FINANCEIRAS
-- ------------------------------------------------------------------------------
CREATE TYPE transaction_type_enum AS ENUM ('income', 'expense');
CREATE TYPE payment_method_enum AS ENUM ('pix', 'credit_card', 'debit_card', 'cash', 'voucher');

CREATE TABLE financial_transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    appointment_id UUID REFERENCES appointments(id) ON DELETE SET NULL,
    barber_id UUID REFERENCES barbers(id) ON DELETE SET NULL, -- para rateio de comissão
    type transaction_type_enum NOT NULL,
    category VARCHAR(80) NOT NULL, -- "Atendimento", "Comissão Barbeiro", "Aluguel", "Insumos", "Energia"
    amount NUMERIC(10, 2) NOT NULL,
    commission_amount NUMERIC(10, 2) DEFAULT 0.00,
    barbershop_net_amount NUMERIC(10, 2) NOT NULL, -- amount - commission_amount
    payment_method payment_method_enum NOT NULL DEFAULT 'pix',
    description VARCHAR(255),
    transaction_date DATE NOT NULL DEFAULT CURRENT_DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_fin_transactions_date ON financial_transactions(transaction_date);

-- ------------------------------------------------------------------------------
-- 7. TABELA DE FECHAMENTO DE CAIXA DIÁRIO
-- ------------------------------------------------------------------------------
CREATE TYPE cash_register_status_enum AS ENUM ('open', 'closed');

CREATE TABLE cash_registers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    register_date DATE NOT NULL DEFAULT CURRENT_DATE,
    opened_by_user_id UUID NOT NULL REFERENCES users(id),
    closed_by_user_id UUID REFERENCES users(id),
    opened_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    closed_at TIMESTAMP WITH TIME ZONE,
    opening_balance NUMERIC(10, 2) NOT NULL DEFAULT 0.00, -- Troco inicial
    closing_balance NUMERIC(10, 2), -- Valor contado no fechamento
    total_pix NUMERIC(10, 2) DEFAULT 0.00,
    total_credit NUMERIC(10, 2) DEFAULT 0.00,
    total_debit NUMERIC(10, 2) DEFAULT 0.00,
    total_cash NUMERIC(10, 2) DEFAULT 0.00,
    total_expenses NUMERIC(10, 2) DEFAULT 0.00,
    difference NUMERIC(10, 2) DEFAULT 0.00, -- Sobra ou quebra de caixa
    status cash_register_status_enum NOT NULL DEFAULT 'open',
    notes TEXT
);

-- ------------------------------------------------------------------------------
-- 8. TABELA DE ESTOQUE (PRODUTOS: USO INTERNO E REVENDA)
-- ------------------------------------------------------------------------------
CREATE TYPE product_category_enum AS ENUM ('internal_use', 'resale');

CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(150) NOT NULL,
    category product_category_enum NOT NULL, -- 'internal_use' (ex: lâminas, espuma) ou 'resale' (ex: pomada, óleo)
    current_quantity INT NOT NULL DEFAULT 0,
    minimum_quantity INT NOT NULL DEFAULT 5, -- Nível crítico para alerta
    cost_price NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
    sale_price NUMERIC(10, 2) DEFAULT 0.00, -- Preço de revenda
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE stock_movements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    movement_type VARCHAR(20) NOT NULL, -- 'IN' (Compra/Reposição), 'OUT_SERVICE' (Uso em corte), 'OUT_SALE' (Venda)
    quantity INT NOT NULL,
    appointment_id UUID REFERENCES appointments(id) ON DELETE SET NULL,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------------------------
-- 9. CONFIGURAÇÃO DE WHATSAPP (META CLOUD API / BSP)
-- ------------------------------------------------------------------------------
CREATE TABLE whatsapp_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    provider VARCHAR(50) DEFAULT 'meta_cloud_api', -- 'meta_cloud_api', 'z-api', 'twilio'
    phone_number_id VARCHAR(100),
    business_account_id VARCHAR(100),
    access_token_encrypted TEXT,
    is_active BOOLEAN DEFAULT FALSE,
    auto_confirmation BOOLEAN DEFAULT TRUE,
    reminder_24h BOOLEAN DEFAULT TRUE,
    reminder_1h BOOLEAN DEFAULT TRUE
);

CREATE TABLE whatsapp_templates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(80) NOT NULL,
    category VARCHAR(30) DEFAULT 'UTILITY',
    language VARCHAR(10) DEFAULT 'pt_BR',
    body_text TEXT NOT NULL,
    variables JSONB, -- ex: ["client_name", "barber_name", "date", "time", "service_name"]
    is_approved BOOLEAN DEFAULT TRUE
);
